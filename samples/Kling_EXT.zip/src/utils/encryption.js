// A simple encryption/decryption utility for protecting sensitive configuration
// This uses XOR encryption which is symmetric (same function for encrypt/decrypt)

/**
 * Encrypts a string using a passphrase with XOR operations
 * @param {string} text - The text to encrypt
 * @param {string} passphrase - The passphrase to use for encryption
 * @returns {string} - The encrypted text
 */
export function encrypt(text, passphrase) {
    let result = '';
    for (let i = 0; i < text.length; i++) {
      // Use modulo to cycle through passphrase characters
      const passphraseChar = passphrase.charCodeAt(i % passphrase.length);
      const textChar = text.charCodeAt(i);
      // XOR the characters and convert back to string
      result += String.fromCharCode(textChar ^ passphraseChar);
    }
    // Convert to base64 for safe storage
    return btoa(result);
  }
  
  /**
   * Decrypts a string that was encrypted with the encrypt function
   * @param {string} encryptedText - The encrypted text (base64 encoded)
   * @param {string} passphrase - The passphrase used for encryption
   * @returns {string} - The decrypted text
   */
  export function decrypt(encryptedText, passphrase) {
    // First decode from base64
    const encryptedString = atob(encryptedText);
    let result = '';
    
    for (let i = 0; i < encryptedString.length; i++) {
      // Use modulo to cycle through passphrase characters
      const passphraseChar = passphrase.charCodeAt(i % passphrase.length);
      const encryptedChar = encryptedString.charCodeAt(i);
      // XOR is symmetric, so same operation decrypts
      result += String.fromCharCode(encryptedChar ^ passphraseChar);
    }
    
    return result;
  }