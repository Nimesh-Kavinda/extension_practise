import { doc, getDoc, updateDoc, onSnapshot, runTransaction } from "firebase/firestore"
import { db, EXTENSION_ID, FREE_TRIAL_QUOTA } from "../firebase"

/**
 * Check a user's subscription status directly from Firestore
 * @param {string} uid - The user's ID
 * @param {string} extensionId - The extension ID to check (defaults to current extension)
 * @returns {Object} Subscription status information
 */
export const checkFirestoreSubscription = async (uid, extensionId = EXTENSION_ID) => {
  if (!uid) return { status: "no_subscription", plan: null }
  
  try {
    const userRef = doc(db, "users", uid)
    const userDoc = await getDoc(userRef)

    if (!userDoc.exists()) {
      return { status: "no_subscription", plan: null }
    }

    const userData = userDoc.data()
    const subscriptionData = userData.subscriptions?.[extensionId]

    if (!subscriptionData) {
      return { status: "no_subscription", plan: null }
    }

    // For trial subscriptions, check if they still have quota remaining AND the trial hasn't ended
    if (subscriptionData.status === "trial") {
      const remaining = subscriptionData.remaining || 0
      const isTrialEnded = subscriptionData.trialEnd ? new Date() > new Date(subscriptionData.trialEnd.toDate()) : false
      
      // Trial has ended OR no quota remaining
      if (isTrialEnded || remaining <= 0) {
        // Update the status to expired in the database if the trial has ended
        if (isTrialEnded && subscriptionData.status !== "expired") {
          try {
            await updateDoc(userRef, {
              [`subscriptions.${extensionId}.status`]: "expired"
            });
            console.log("Updated trial status to expired due to date expiration");
          } catch (error) {
            console.error("Error updating expired trial status:", error);
          }
        }
        
        return {
          status: "expired",
          plan: "trial",
          quota: subscriptionData.quota || FREE_TRIAL_QUOTA,
          used: subscriptionData.used || FREE_TRIAL_QUOTA,
          remaining: 0,
          trialEnd: subscriptionData.trialEnd ? subscriptionData.trialEnd.toDate() : null
        }
      }
      
      return {
        status: "trial",
        plan: "trial",
        quota: subscriptionData.quota || FREE_TRIAL_QUOTA,
        used: subscriptionData.used || 0,
        remaining: remaining,
        trialEnd: subscriptionData.trialEnd ? subscriptionData.trialEnd.toDate() : null
      }
    }
    
    // For paid subscriptions
    return {
      status: subscriptionData.status,
      plan: subscriptionData.plan,
      canceledAt: subscriptionData.canceledAt ? subscriptionData.canceledAt.toDate() : null,
      // Include end date if present
      ...(subscriptionData.endDate && { endDate: subscriptionData.endDate.toDate() })
    }
  } catch (error) {
    console.error("Error checking subscription:", error)
    return { status: "error", plan: null }
  }
}

/**
 * Set up a real-time listener for subscription changes
 * @param {string} uid - The user's ID 
 * @param {string} extensionId - The extension ID to monitor (defaults to current extension)
 * @param {Function} callback - Function to call with updated subscription data
 * @returns {Function} Unsubscribe function
 */
export const subscribeToSubscriptionChanges = (uid, extensionId = EXTENSION_ID, callback) => {
  if (!uid) return () => {}
  
  const userRef = doc(db, "users", uid)
  return onSnapshot(userRef, (doc) => {
    if (!doc.exists()) {
      callback({ status: "no_subscription", plan: null })
      return
    }
    
    const userData = doc.data()
    const subscriptionData = userData.subscriptions?.[extensionId]
    
    if (!subscriptionData) {
      callback({ status: "no_subscription", plan: null })
      return
    }
    
    // Process based on subscription type (trial or paid)
    if (subscriptionData.status === "trial") {
      const remaining = subscriptionData.remaining || 0
      const isTrialEnded = subscriptionData.trialEnd ? new Date() > new Date(subscriptionData.trialEnd.toDate()) : false
      
      // Trial has ended OR no quota remaining
      if (isTrialEnded || remaining <= 0) {
        // Update the status to expired in the database if trial has ended
        if (isTrialEnded && subscriptionData.status !== "expired") {
          updateDoc(userRef, {
            [`subscriptions.${extensionId}.status`]: "expired"
          }).then(() => {
            console.log("Updated trial status to expired due to date expiration");
          }).catch(error => {
            console.error("Error updating expired trial status:", error);
          });
        }
        
        callback({
          status: "expired",
          plan: "trial",
          quota: subscriptionData.quota || FREE_TRIAL_QUOTA,
          used: subscriptionData.used || FREE_TRIAL_QUOTA,
          remaining: 0,
          trialEnd: subscriptionData.trialEnd ? subscriptionData.trialEnd.toDate() : null
        })
        return
      }
      
      callback({
        status: "trial",
        plan: "trial",
        quota: subscriptionData.quota || FREE_TRIAL_QUOTA,
        used: subscriptionData.used || 0,
        remaining: remaining,
        trialEnd: subscriptionData.trialEnd ? subscriptionData.trialEnd.toDate() : null
      })
      return
    }
    
    // For paid subscriptions
    callback({
      status: subscriptionData.status,
      plan: subscriptionData.plan,
      canceledAt: subscriptionData.canceledAt ? subscriptionData.canceledAt.toDate() : null,
      // Include end date if present
      ...(subscriptionData.endDate && { endDate: subscriptionData.endDate.toDate() })
    })
  }, (error) => {
    console.error("Error in subscription listener:", error)
    callback({ status: "error", plan: null })
  })
}

/**
 * Update the usage count when quota is used
 * @param {string} uid - The user's ID
 * @param {number} count - Number of items used from quota
 * @param {string} extensionId - The extension ID to update (defaults to current extension)
 * @returns {Promise<Object>} Updated subscription data
 */
export const updateQuotaUsage = async (uid, count, extensionId = EXTENSION_ID) => {
  if (!uid || count <= 0) return null
  
  try {
    // Use a transaction to ensure data consistency
    return await runTransaction(db, async (transaction) => {
      const userRef = doc(db, "users", uid);
      const userDoc = await transaction.get(userRef);
      
      if (!userDoc.exists()) return null;
      
      const userData = userDoc.data();
      const subscriptionData = userData.subscriptions?.[extensionId];
      
      if (!subscriptionData || subscriptionData.status !== "trial") {
        return subscriptionData || null;
      }
      
      // Check if trial has ended based on date
      const isTrialEnded = subscriptionData.trialEnd ? new Date() > new Date(subscriptionData.trialEnd.toDate()) : false;
      
      // If trial already ended by date, just update the status if needed
      if (isTrialEnded && subscriptionData.status !== "expired") {
        transaction.update(userRef, {
          [`subscriptions.${extensionId}.status`]: "expired"
        });
        
        return {
          status: "expired",
          plan: "trial",
          quota: subscriptionData.quota || FREE_TRIAL_QUOTA,
          used: subscriptionData.used || 0,
          remaining: 0,
          trialEnd: subscriptionData.trialEnd ? subscriptionData.trialEnd.toDate() : null
        };
      }
      
      // Calculate new values
      const currentUsed = subscriptionData.used || 0;
      const quota = subscriptionData.quota || FREE_TRIAL_QUOTA;
      const updatedUsed = currentUsed + count;
      const updatedRemaining = Math.max(0, quota - updatedUsed);
      const newStatus = isTrialEnded || updatedRemaining <= 0 ? "expired" : "trial";
      
      // Use one transaction to update all fields
      transaction.update(userRef, {
        [`subscriptions.${extensionId}.used`]: updatedUsed,
        [`subscriptions.${extensionId}.remaining`]: updatedRemaining,
        [`subscriptions.${extensionId}.status`]: newStatus
      });
      
      // Return updated status object
      return {
        status: newStatus,
        plan: "trial",
        quota: quota,
        used: updatedUsed,
        remaining: updatedRemaining,
        trialEnd: subscriptionData.trialEnd ? subscriptionData.trialEnd.toDate() : null
      };
    });
  } catch (error) {
    console.error("Error updating quota usage:", error)
    return null
  }
}

/**
 * Create a checkout session for subscription purchase
 * @param {string} email - User's email
 * @param {string} plan - Selected plan (monthly, yearly, lifetime)
 * @param {string} extensionId - The extension ID to purchase for (defaults to current extension)
 * @returns {Promise<Object>} Session data with URL
 */
export const createCheckoutSession = async (email, plan, extensionId = EXTENSION_ID) => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SERVER_URL}/api/create-checkout-session`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: email,
        plan: plan,
        extensionId: extensionId,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to create checkout session")
    }

    return await response.json()
  } catch (error) {
    console.error("Error creating checkout session:", error)
    throw error
  }
}

/**
 * Create a customer portal session for managing subscriptions
 * @param {string} email - User's email
 * @param {string} extensionId - The extension ID to manage (defaults to current extension)
 * @returns {Promise<Object>} Session data with URL
 */
export const createCustomerPortalSession = async (email, extensionId = EXTENSION_ID) => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SERVER_URL}/api/create-customer-portal-session`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: email,
        extensionId: extensionId,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to create customer portal session")
    }

    return await response.json()
  } catch (error) {
    console.error("Error creating customer portal session:", error)
    throw error
  }
}