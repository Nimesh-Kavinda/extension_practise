// Step 1: Inject Text to Text area 

const editor = document.querySelector('.tiptap.ProseMirror');
editor.focus();
editor.innerHTML = 'Hello, this is injected text!';

// Trigger input event so any frameworks listening (e.g. ProseMirror) detect the change
editor.dispatchEvent(new Event('input', { bubbles: true }));

// Step 2: Click Genarate button

[...document.querySelectorAll('button')].find(btn => btn.textContent.trim().includes('Generate'))?.click();


// Step 3: Watch for the Processing or not 

let lastSeen = null;

const observer = new MutationObserver(() => {
  const current = document.querySelector('.progress-box.vertical-center');

  if (current && !lastSeen) {
    console.log('✅ Progress box appeared:', current);
    lastSeen = current;
  } else if (!current && lastSeen) {
    console.log('❌ Progress box disappeared');
    lastSeen = null;
  }
});

// Start observing DOM
observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Optional: immediately check current state on script load
const initial = document.querySelector('.progress-box.vertical-center');
if (initial) {
  console.log('✅ Progress box already present:', initial);
  lastSeen = initial;
}


// Step 4: Click Download button

const downloadButton = [...document.querySelectorAll('button')].find(btn => 
  btn.querySelector('use')?.getAttribute('xlink:href') === '#icon-download'
);

downloadButton?.click();



// Repeat

