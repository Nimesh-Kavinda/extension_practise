// Kling Video Generation Assistant Content Script

// IMPORTANT: Kling Video Generation UI Notes
// This content script automates video generation on Kling platform by:
// 1. Injecting text prompts into the text area
// 2. Clicking the Generate button
// 3. Monitoring generation progress
// 4. Downloading completed videos
//
// Key elements for Kling automation:
// - Text Input: '.tiptap.ProseMirror'
// - Generate Button: Button containing "Generate" text
// - Progress Box: '.progress-box.vertical-center'
// - Download Button: Button with '#icon-download' xlink:href

// Global auth state
let isUserLoggedIn = false; // Default to false as authentication is required
let subscriptionStatus = null; // Default to null until we confirm status
let userId = null;

// Get initial auth state from background script
chrome.runtime.sendMessage({ action: "getAuthState" }, (response) => {
  if (response) {
    isUserLoggedIn = response.isLoggedIn;
    subscriptionStatus = response.subscriptionStatus;
    // console.log(
    //   "Initial auth state:", 
    //   isUserLoggedIn ? "logged in" : "not logged in", 
    //   "Subscription:", subscriptionStatus
    // );
  }
});

// Kling specific variables
let isProcessing = false;
let currentPromptIndex = 0;
let prompts = [];
let settings = {
  autoDownload: true,
  delayBetweenPrompts: 5000,
  generationMode: "text",  // "text" or "image"
  baseImages: []  // Array of base images for Image to Video mode
};
let maxRetries = 3;
let currentRetries = 0;
// Remove Firefly-specific variables that don't apply to Kling
let isCurrentPromptProcessed = false; // Flag to prevent double-processing

// Authentication verification with retry mechanism
function verifyAuthenticationState() {
  return new Promise((resolve) => {
    let retryCount = 0;
    const maxRetries = 3;
    const retryDelay = 1000; // 1 second between retries
    
    function attemptAuthCheck() {
      chrome.runtime.sendMessage({ action: "getAuthState" }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("Auth state check failed:", chrome.runtime.lastError);
          
          if (retryCount < maxRetries) {
            retryCount++;
            setTimeout(attemptAuthCheck, retryDelay);
            return;
          }
          
          // If all retries failed, assume not authenticated
          resolve({
            isLoggedIn: false,
            subscriptionStatus: null,
            error: "Could not verify authentication state"
          });
          return;
        }
        
        if (response) {
          // Update local state
          isUserLoggedIn = response.isLoggedIn;
          subscriptionStatus = response.subscriptionStatus;
          
          console.log("Auth state verified:", {
            isLoggedIn: response.isLoggedIn,
            subscriptionStatus: response.subscriptionStatus
          });
          
          resolve(response);
        } else {
          if (retryCount < maxRetries) {
            retryCount++;
            setTimeout(attemptAuthCheck, retryDelay);
          } else {
            resolve({
              isLoggedIn: false,
              subscriptionStatus: null,
              error: "No response from background script"
            });
          }
        }
      });
    }
    
    attemptAuthCheck();
  });
}

// Listen for messages from the side panel
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  // Always send a response to keep the message channel from closing unexpectedly
  const defaultResponse = { received: true };
  
  if (message.action === 'startProcessing') {
    // AUTHENTICATION FIX: Always re-verify authentication state before starting
    verifyAuthenticationState().then((authState) => {
      if (!authState.isLoggedIn) {
        const errorMessage = authState.error || 'Authentication required. Please sign in first.';
        chrome.runtime.sendMessage({
          action: 'error',
          error: errorMessage
        });
        sendResponse({ ...defaultResponse, error: errorMessage });
        return;
      }
      
      // Authentication verified, proceed with processing
      if (!isProcessing) {
        prompts = message.prompts;
        settings = message.settings;
        isProcessing = true;
        currentPromptIndex = 0;
        
        // Start processing
        processNextPrompt();
        sendResponse({ ...defaultResponse, started: true });
      } else {
        sendResponse({ ...defaultResponse, error: "Already processing" });
      }
    }).catch((error) => {
      console.error("Auth verification failed:", error);
      chrome.runtime.sendMessage({
        action: 'error',
        error: 'Authentication verification failed. Please try again.'
      });
      sendResponse({ ...defaultResponse, error: "Authentication verification failed" });
    });
    
    return true; // Keep message channel open for async response
  } else if (message.action === 'stopProcessing') {
    isProcessing = false;
    hideOverlay(); // Make sure to hide overlay when stopping
    sendResponse(defaultResponse);
  } else if (message.action === 'checkKlingStatus') {
    // Check Kling platform status and send it back
    checkKlingStatus();
    sendResponse(defaultResponse);
  } else if (message.action === "authStateChanged") {
    // Update auth state
    isUserLoggedIn = message.isLoggedIn;
    subscriptionStatus = message.subscriptionStatus;
    userId = message.userId;
    
    console.log(
      "Auth state updated:", 
      isUserLoggedIn ? "logged in" : "logged out", 
      "Subscription:", subscriptionStatus,
      "User ID:", userId
    );
    
    sendResponse({ success: true });
  } else {
    // Default response for unhandled messages
    sendResponse(defaultResponse);
  }
});

// Add tab visibility listener for auth state refresh
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    // Tab became visible, refresh auth state
    setTimeout(() => {
      verifyAuthenticationState().then((authState) => {
        // Update UI or notify side panel of auth state if needed
        chrome.runtime.sendMessage({
          action: 'authStateRefreshed',
          authState: authState
        }).catch(() => {
          // Ignore errors if side panel isn't open
        });
      });
    }, 500); // Small delay to ensure page is fully visible
  }
});

// Add window focus listener for additional auth state refresh
window.addEventListener('focus', () => {
  setTimeout(() => {
    verifyAuthenticationState().then((authState) => {
      chrome.runtime.sendMessage({
        action: 'authStateRefreshed',
        authState: authState
      }).catch(() => {
        // Ignore errors if side panel isn't open
      });
    });
  }, 500);
});

// Create and show overlay
function showOverlay(message) {
  // Check if overlay already exists
  if (document.getElementById('firefly-assistant-overlay')) {
    updateOverlayMessage(message);
    return;
  }
  
  // Create overlay elements
  const overlay = document.createElement('div');
  overlay.id = 'firefly-assistant-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 10000;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: white;
    font-family: Arial, sans-serif;
  `;
  
  // Create message container
  const messageContainer = document.createElement('div');
  messageContainer.id = 'firefly-assistant-message';
  messageContainer.style.cssText = `
    background-color: #2d2d2d;
    padding: 20px;
    border-radius: 8px;
    max-width: 80%;
    text-align: center;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
  `;
  
  // Add loading spinner
  const spinner = document.createElement('div');
  spinner.style.cssText = `
    border: 5px solid #f3f3f3;
    border-top: 5px solid #3498db;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    margin: 0 auto 20px auto;
    animation: spin 2s linear infinite;
  `;
  
  // Add animation for spinner
  const style = document.createElement('style');
  style.textContent = `
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;
  document.head.appendChild(style);
  
  // Add message text
  const messageText = document.createElement('p');
  messageText.id = 'firefly-assistant-message-text';
  messageText.textContent = message || 'Processing...';
  messageText.style.cssText = `
    font-size: 16px;
    margin: 10px 0;
  `;
  
  // Add progress indicator
  const progress = document.createElement('p');
  progress.id = 'firefly-assistant-progress';
  progress.textContent = `Prompt: ${currentPromptIndex + 1}/${prompts.length}`;
  progress.style.cssText = `
    font-size: 14px;
    margin: 10px 0;
  `;
  
  // Add cancel button
  const cancelButton = document.createElement('button');
  cancelButton.textContent = 'Cancel Processing';
  cancelButton.style.cssText = `
    background-color: #e74c3c;
    border: none;
    color: white;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 14px;
    margin: 20px 2px;
    cursor: pointer;
    border-radius: 4px;
  `;
  
  cancelButton.addEventListener('click', () => {
    isProcessing = false;
    hideOverlay();
    chrome.runtime.sendMessage({
      action: 'updateStatus',
      status: 'Processing canceled by user'
    });
  });
  
  // Assemble the overlay
  messageContainer.appendChild(spinner);
  messageContainer.appendChild(messageText);
  messageContainer.appendChild(progress);
  messageContainer.appendChild(cancelButton);
  overlay.appendChild(messageContainer);
  
  // Add to document
  document.body.appendChild(overlay);
}

// Update the overlay message
function updateOverlayMessage(message, currentIndex) {
  const messageElement = document.getElementById('firefly-assistant-message-text');
  const progressElement = document.getElementById('firefly-assistant-progress');
  
  if (messageElement && message) {
    messageElement.textContent = message;
  }
  
  if (progressElement && currentIndex !== undefined) {
    progressElement.textContent = `Prompt: ${currentIndex + 1}/${prompts.length}`;
  }
}

// Hide and remove the overlay
function hideOverlay() {
  const overlay = document.getElementById('firefly-assistant-overlay');
  if (overlay) {
    document.body.removeChild(overlay);
  }
}

// Kling doesn't have fast mode - remove this function
function checkKlingStatus() {
  // Simple status check for Kling platform
  chrome.runtime.sendMessage({
    action: 'klingStatus',
    connected: true
  });
}

// Process the next prompt in the queue
function processNextPrompt() {
  // Reset the current prompt processing flag
  isCurrentPromptProcessed = false;
  
  // For image mode, check if we've processed all images
  const totalItems = settings.generationMode === "image" ? settings.baseImages.length : prompts.length;
  
  if (!isProcessing || currentPromptIndex >= totalItems) {
    // Processing completed or stopped
    isProcessing = false;
    updateProgress();
    hideOverlay(); // Hide overlay when done
    
    // Send a final success message
    chrome.runtime.sendMessage({
      action: 'updateStatus',
      status: settings.generationMode === "image" ? 'All images processed successfully!' : 'All prompts completed successfully!'
    });
    return;
  }

  // Show or update overlay at start of processing
  const currentPrompt = prompts[currentPromptIndex] || '';
  const promptPreview = currentPrompt.length > 30 ? currentPrompt.substring(0, 30) + '...' : currentPrompt;
  showOverlay(`Processing: "${promptPreview}"`);
  
  // Check quota status in storage before continuing - only for non-paid users
  chrome.storage.local.get('quotaStatus', (data) => {
    // Default to allowing processing if no data
    const quotaStatus = data.quotaStatus || { canContinue: true, isPaid: false };
    
    // Skip quota check for paid users (they always have quota)
    if (quotaStatus.isPaid) {
      // console.log("Paid user detected: Bypassing quota checks");
      // Continue processing without quota checks
      processPrompt();
      return;
    }
    
    // For trial users or others, check if they can continue
    if (!quotaStatus.canContinue) {
      // Stop processing if quota depleted
      isProcessing = false;
      hideOverlay(); // Hide overlay
      chrome.runtime.sendMessage({
        action: 'error',
        error: 'Your quota has been depleted. Please upgrade to continue.'
      });
      return;
    }
    
    // Continue with normal processing for users with quota
    processPrompt();
  });
  
  // Helper function to process the prompt after quota check
  function processPrompt() {
    const prompt = prompts[currentPromptIndex];
    
    // Update progress
    updateProgress();
    
    // Send status update
    const statusMessage = `Processing prompt: "${prompt && prompt.substring(0, 30)}${prompt && prompt.length > 30 ? '...' : ''}"`;
    updateOverlayMessage(statusMessage); // Update overlay message
    chrome.runtime.sendMessage({
      action: 'updateStatus',
      status: statusMessage
    });
    
    // For Kling, directly proceed with video generation
    if (generateVideo(prompt)) {
      setupVideoCompletionDetection();
      currentRetries = 0;
    } else {
      handleRetry();
    }
  }
}

// Send progress update to side panel
function updateProgress() {
  // For image mode, use image count; for text mode, use prompt count
  const totalItems = settings.generationMode === "image" ? settings.baseImages.length : prompts.length;
  const reportedIndex = Math.min(currentPromptIndex, totalItems);
  
  // Update overlay with progress
  if (isProcessing) {
    updateOverlayMessage(null, reportedIndex);
  }
  
  // Get current item description for display
  let currentItem = '';
  if (settings.generationMode === "image") {
    // For image mode, show image name or index
    if (settings.baseImages && reportedIndex < settings.baseImages.length) {
      currentItem = `Image: ${settings.baseImages[reportedIndex].name}`;
    }
  } else {
    // For text mode, show prompt text
    if (reportedIndex < prompts.length) {
      currentItem = prompts[reportedIndex];
    }
  }
  
  // Send progress update to side panel
  chrome.runtime.sendMessage({
    action: 'updateProgress',
    currentPrompt: currentItem,
    processed: reportedIndex,
    total: totalItems
  });
}

// Find elements in shadow DOM
function findInShadowDOM(selector, root = document.body) {
  let element = root.querySelector(selector);
  if (element) return element;
  
  const elements = root.querySelectorAll('*');
  for (const elem of elements) {
    if (elem.shadowRoot) {
      element = elem.shadowRoot.querySelector(selector);
      if (element) return element;
      
      element = findInShadowDOM(selector, elem.shadowRoot);
      if (element) return element;
    }
  }
  
  return null;
}

// Generate video with the given prompt using Kling automation
function generateVideo(text) {
  if (settings.generationMode === "image") {
    return generateImageToVideo(text);
  } else {
    return generateTextToVideo(text);
  }
}

// Generate Text to Video
function generateTextToVideo(text) {
  // Step 1: Find and inject text into the text area
  const editor = document.querySelector('.tiptap.ProseMirror');
  
  if (!editor) {
    console.error('Kling text editor not found');
    return false;
  }

  // Focus and set the text
  editor.focus();
  editor.innerHTML = text;
  
  // Trigger input event for frameworks to detect the change
  editor.dispatchEvent(new Event('input', { bubbles: true }));
  
  // Step 2: Find and click the Generate button
  setTimeout(() => {
    const generateButton = [...document.querySelectorAll('button')].find(btn =>
      btn.textContent.trim().includes('Generate')
    );
    
    if (generateButton) {
      generateButton.click();
      console.log('✅ Generate button clicked for Text to Video');
    } else {
      isProcessing = false;
      chrome.runtime.sendMessage({
        action: 'error',
        error: 'Generate button not found'
      });
      return false;
    }
  }, 500);
  
  return true;
}

// Generate Image to Video - FULL PRODUCTION MODE
async function generateImageToVideo(text) {
  try {
    // Step 1: Inject the current image if available
    if (settings.baseImages && settings.baseImages.length > 0 && currentPromptIndex < settings.baseImages.length) {
      const currentImage = settings.baseImages[currentPromptIndex];
      const base64Data = currentImage.data; // This should already include "data:image/...;base64,"

      console.log(`🔄 Image to Video: Starting injection for image ${currentPromptIndex + 1}/${settings.baseImages.length}: ${currentImage.name}`);
      
      // Use the exact script format that works for image injection
      const response = await fetch(base64Data);
      const blob = await response.blob();
      const file = new File([blob], currentImage.name || "upload-from-script.png", { type: blob.type });

      // Try to find file input
      const fileInput = document.querySelector('input[type="file"]');
      if (!fileInput) {
        console.error("❌ No file input found near upload icon.");
        return false;
      }

      // Use DataTransfer with exact syntax as working script
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;

      // Dispatch change event
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      console.log(`✅ Image ${currentPromptIndex + 1}/${settings.baseImages.length} injected successfully: ${file.name}`);

      // Wait for image processing completion by checking for the specific element
      console.log("⏳ Waiting for image to be processed by Kling...");
      updateOverlayMessage("Processing uploaded image...");
      
      await waitForImageProcessing();
      console.log("✅ Image processing completed - first-frame-narrow element detected");
    }

    // Step 2: Add text prompt if provided
    if (text && text.trim()) {
      const editor = document.querySelector('.tiptap.ProseMirror');
      if (editor) {
        editor.focus();
        editor.innerHTML = text;
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        console.log("✅ Enhancement prompt added:", text);
      }
    } else {
      console.log("ℹ️ No text prompt provided, proceeding with image-only generation");
    }

    // Step 3: Click Generate button - Wait 10 seconds for image upload completion
    updateOverlayMessage("Waiting for image upload to complete...");
    setTimeout(() => {
      const generateButton = [...document.querySelectorAll('button')].find(btn =>
        btn.textContent.trim().includes('Generate')
      );
      
      if (generateButton) {
        generateButton.click();
        console.log('✅ Generate button clicked for Image to Video (after 10-second delay)');
        updateOverlayMessage("Generate button clicked, creating video...");
      } else {
        isProcessing = false;
        chrome.runtime.sendMessage({
          action: 'error',
          error: 'Generate button not found'
        });
        return false;
      }
    }, 10000); // Changed from 7000ms to 10000ms (10 seconds)

    return true;
  } catch (error) {
    console.error('Error in Image to Video generation:', error);
    isProcessing = false;
    chrome.runtime.sendMessage({
      action: 'error',
      error: `Image to Video error: ${error.message}`
    });
    return false;
  }
}

// Wait for image processing completion by detecting the first-frame-narrow element
function waitForImageProcessing() {
  return new Promise((resolve, reject) => {
    const maxWaitTime = 30000; // Maximum 30 seconds
    const checkInterval = 500; // Check every 500ms
    let elapsedTime = 0;

    const checkForElement = () => {
      // Look for the specific element that indicates image processing is complete
      const firstFrameElement = document.querySelector('div[data-v-8fb1d515].first-frame-narrow') ||
                                document.querySelector('.first-frame-narrow');
      
      if (firstFrameElement) {
        console.log("✅ first-frame-narrow element found - image processing complete");
        resolve();
        return;
      }

      elapsedTime += checkInterval;
      if (elapsedTime >= maxWaitTime) {
        console.warn("⚠️ Timeout waiting for image processing - proceeding anyway");
        resolve(); // Don't reject, just proceed
        return;
      }

      // Continue checking
      setTimeout(checkForElement, checkInterval);
    };

    // Start checking
    checkForElement();
  });
}

// Detect when video generation is complete
function setupVideoCompletionDetection() {
  let lastSeen = null;
  
  const observer = new MutationObserver(() => {
    const current = document.querySelector('.progress-box.vertical-center');
    
    if (current && !lastSeen) {
      console.log('✅ Progress box appeared:', current);
      updateOverlayMessage("Generating video...");
      lastSeen = current;
    } else if (!current && lastSeen) {
      console.log('❌ Progress box disappeared - generation complete');
      updateOverlayMessage("Generation completed, processing video...");
      lastSeen = null;
      
      // Allow some time for the video to be available
      setTimeout(() => {
        captureVideoInfo();
        
        // Move to next prompt if not already processed
        if (!isCurrentPromptProcessed) {
          isCurrentPromptProcessed = true;
          moveToNextPrompt();
        }
      }, 2000);
    }
  });
  
  // Start observing DOM changes
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Check current state immediately
  const initial = document.querySelector('.progress-box.vertical-center');
  if (initial) {
    console.log('✅ Progress box already present:', initial);
    updateOverlayMessage("Generating video...");
    lastSeen = initial;
  }
}

// Helper function to handle retries
function handleRetry() {
  if (currentRetries < maxRetries) {
    currentRetries++;
    
    const retryMessage = `Retry ${currentRetries}/${maxRetries}: Waiting for Firefly interface...`;
    updateOverlayMessage(retryMessage);
    
    chrome.runtime.sendMessage({
      action: 'updateStatus',
      status: retryMessage
    });
    
    setTimeout(processNextPrompt, 3000);
  } else {
    // Hide overlay on error
    hideOverlay();
    
    chrome.runtime.sendMessage({
      action: 'error',
      error: 'Unable to find Firefly interface elements after multiple attempts. Make sure you are on the correct page.'
    });
    isProcessing = false;
  }
}

// Helper function to move to next prompt
function moveToNextPrompt() {
  // Safety check to prevent double-incrementing
  if (isCurrentPromptProcessed) {
    // Increment index for next prompt
    currentPromptIndex++;
    
    // Wait before processing the next prompt
    updateOverlayMessage(`Waiting ${settings.delayBetweenPrompts/1000} seconds before next prompt...`);
    setTimeout(() => {
      processNextPrompt();
    }, settings.delayBetweenPrompts);
  }
}

// Capture video information and download if needed
function captureVideoInfo() {
  updateOverlayMessage("Capturing video information...");
  
  try {
    // For image mode, handle differently
    if (settings.generationMode === "image") {
      const currentImage = settings.baseImages && settings.baseImages[currentPromptIndex]
        ? settings.baseImages[currentPromptIndex]
        : null;
      
      if (currentImage) {
        // Find the download button for Kling videos
        const downloadButton = [...document.querySelectorAll('button')].find(btn =>
          btn.querySelector('use')?.getAttribute('xlink:href') === '#icon-download'
        );
        
        if (downloadButton) {
          // If auto-download is enabled, click the download button
          if (settings.autoDownload) {
            downloadButton.click();
            console.log(`✅ Download button clicked for video from image: ${currentImage.name}`);
          }
          
          // Notify the user
          const statusMessage = `Video ready from image: ${currentImage.name}`;
          updateOverlayMessage(statusMessage);
          chrome.runtime.sendMessage({
            action: 'updateStatus',
            status: statusMessage
          });
        } else {
          console.warn("❌ Download button not found");
          updateOverlayMessage("Error: Download button not found");
        }
      }
      return;
    }
    
    // ORIGINAL CODE for text-to-video mode
    // Safety check - make sure we have valid prompts and index
    if (!prompts || currentPromptIndex >= prompts.length) {
      console.warn("❌ No valid prompt at current index.");
      updateOverlayMessage("Error: No valid prompt at current index.");
      return;
    }
    
    const currentPrompt = prompts[currentPromptIndex];
    
    // Find the download button for Kling videos
    const downloadButton = [...document.querySelectorAll('button')].find(btn =>
      btn.querySelector('use')?.getAttribute('xlink:href') === '#icon-download'
    );
    
    if (downloadButton) {
      // If auto-download is enabled, click the download button
      if (settings.autoDownload) {
        downloadButton.click();
        console.log('✅ Download button clicked for video');
      }
      
      // Safely truncate the prompt for display
      const promptPreview = currentPrompt ?
        (currentPrompt.length > 20 ? currentPrompt.substring(0, 20) + '...' : currentPrompt) :
        'unknown prompt';
      
      // Notify the user
      updateOverlayMessage(`Video ready for prompt "${promptPreview}"`);
      chrome.runtime.sendMessage({
        action: 'updateStatus',
        status: `Video ready for prompt "${promptPreview}"`
      });
    } else {
      console.warn("❌ Download button not found");
      updateOverlayMessage("Error: Download button not found");
    }
    
  } catch (error) {
    console.error("Error capturing video information:", error);
    updateOverlayMessage(`Error capturing video: ${error.message}`);
    chrome.runtime.sendMessage({
      action: 'error',
      error: `Error capturing video: ${error.message}`
    });
  }
}

// Format the current date for filename
function formatDateForFilename() {
  const now = new Date();
  return now.getFullYear() + 
    ('0' + (now.getMonth() + 1)).slice(-2) + 
    ('0' + now.getDate()).slice(-2) + '_' +
    ('0' + now.getHours()).slice(-2) + 
    ('0' + now.getMinutes()).slice(-2);
}

// Download an image from a blob URL
function downloadImage(blobUrl, imageName) {
  // Fetch the blob
  fetch(blobUrl)
    .then(response => response.blob())
    .then(blob => {
      // Create an object URL for the blob
      const url = URL.createObjectURL(blob);
      
      // Create a link element
      const a = document.createElement('a');
      a.href = url;
      a.download = `${imageName}.png`;
      
      // Append to the document, click it, and remove it
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      // Release the blob URL
      setTimeout(() => URL.revokeObjectURL(url), 100);
    })
    .catch(error => {
      console.error(`Error downloading image ${imageName}:`, error);
      updateOverlayMessage(`Error downloading image: ${error.message}`);
    });
}


// Check Kling status when content script is loaded
setTimeout(checkKlingStatus, 2000);

// Log that content script is loaded
console.log("Kling Video Generation Assistant content script loaded");