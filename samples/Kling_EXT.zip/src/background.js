// Background script for the Kling Video Generation Assistant

// Global auth and subscription state tracking
let isUserLoggedIn = false;
let subscriptionStatus = null; // Can be null, "active", "trial", or "expired"
let currentUserId = null;

// Load persisted auth state on startup
chrome.storage.local.get(['authState'], (result) => {
  if (result.authState) {
    isUserLoggedIn = result.authState.isLoggedIn || false;
    subscriptionStatus = result.authState.subscriptionStatus || null;
    currentUserId = result.authState.userId || null;
    
    console.log("Loaded persisted auth state:", {
      isLoggedIn: isUserLoggedIn,
      subscriptionStatus: subscriptionStatus,
      userId: currentUserId
    });
    
    // Broadcast to all existing content scripts
    setTimeout(() => {
      broadcastAuthState();
    }, 1000);
  }
});

// Function to persist auth state to storage
function persistAuthState() {
  const authState = {
    isLoggedIn: isUserLoggedIn,
    subscriptionStatus: subscriptionStatus,
    userId: currentUserId,
    lastUpdated: Date.now()
  };
  
  chrome.storage.local.set({ authState }, () => {
    console.log("Auth state persisted:", authState);
  });
}

// Initialize default settings on installation
chrome.runtime.onInstalled.addListener((details) => {
  console.log("Extension installed");
  
  // Initialize default settings
  chrome.storage.local.set({
    autoUpscale: false,
    autoDownload: true,
    delayBetweenPrompts: 5,
    createCSV: true,
    // Set authentication as required
    authRequired: true,
    // Initialize quota status
    quotaStatus: {
      isCheckingQuota: false,
      canContinue: true,
      lastChecked: Date.now()
    }
  });

  // Open welcome page when extension is first installed
  if (details.reason === "install") {
    // Replace with your actual welcome page URL
    const welcomeUrl = "https://app.klingai.com/global/";
    chrome.tabs.create({ url: welcomeUrl });
  }
});

// Set up side panel to open on action click
if (chrome.sidePanel) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => {
    console.error("Error setting panel behavior:", error);
  });
}

// Handle extension icon click - open side panel and navigate to Firefly
chrome.action.onClicked.addListener((tab) => {
  // Open the side panel
  if (chrome.sidePanel) {
    chrome.sidePanel.open({ tabId: tab.id }).catch((error) => {
      console.error("Error opening side panel:", error);
    });
  }
  
  // If not on Kling AI page, navigate to it
  if (!tab.url.includes('klingai.com')) {
    chrome.tabs.update(tab.id, { url: 'https://klingai.com' });
  }
});

// Message handling for authentication and functionality
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle Google sign-in request
  if (message.action === "signInWithGoogle") {
    // Use Chrome's identity API for OAuth
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError) {
        sendResponse({
          success: false,
          error: chrome.runtime.lastError.message,
        });
        return;
      }

      // Return the token to the requester
      sendResponse({
        success: true,
        token: token,
      });
    });
    return true; // Keep the message channel open for async response
  }
  
  // Handle auth state requests with reliability improvements
  else if (message.action === "getAuthState") {
    // Always provide the most current auth state
    const authResponse = { 
      isLoggedIn: isUserLoggedIn,
      subscriptionStatus: subscriptionStatus,
      userId: currentUserId,
      timestamp: Date.now()
    };
    
    console.log("Auth state requested, responding with:", authResponse);
    sendResponse(authResponse);
    return true;
  }
  
  // Handle auth/subscription state updates with persistence
  else if (message.action === "authStateChanged") {
    const oldLoggedInState = isUserLoggedIn;
    
    isUserLoggedIn = message.isLoggedIn;
    
    // Store user ID if provided
    if (message.userId) {
      currentUserId = message.userId;
    } else if (!message.isLoggedIn) {
      currentUserId = null;
    }
    
    // Update subscription status if provided
    if (message.subscriptionStatus !== undefined) {
      subscriptionStatus = message.subscriptionStatus;
    }
    
    console.log(
      "Auth/subscription state updated:", 
      isUserLoggedIn ? "logged in" : "logged out", 
      "Subscription:", subscriptionStatus,
      "User ID:", currentUserId
    );
    
    // Persist the updated state
    persistAuthState();
    
    // Broadcast to all tabs with content scripts
    broadcastAuthState();
    
    // If user just logged in, refresh quota status
    if (!oldLoggedInState && isUserLoggedIn) {
      // Reset quota status for newly logged in user
      chrome.storage.local.set({
        quotaStatus: {
          isCheckingQuota: false,
          canContinue: true,
          lastChecked: Date.now(),
          isPaid: subscriptionStatus === 'active'
        }
      });
    }
    
    sendResponse({ success: true });
    return true;
  }
  
  // Handle auth state refresh from content script
  else if (message.action === "authStateRefreshed") {
    // Content script is reporting a refreshed auth state
    // We can log this or take action if needed
    console.log("Auth state refreshed by content script:", message.authState);
    sendResponse({ received: true });
    return true;
  }
  
  // Handle direct quota check request
  else if (message.action === "getQuotaStatus") {
    // Simple synchronous response with current quota status
    chrome.storage.local.get('quotaStatus', (data) => {
      // Default quota status that allows continuing (especially for paid users)
      const defaultQuotaStatus = { 
        canContinue: true,
        isPaid: subscriptionStatus === 'active',
        status: "unknown"
      };
      
      const quotaStatus = data.quotaStatus || defaultQuotaStatus;
      
      // Update isPaid status based on current subscription
      if (subscriptionStatus === 'active') {
        quotaStatus.isPaid = true;
        quotaStatus.canContinue = true;
      }
      
      sendResponse(quotaStatus);
    });
    return true; // Keep channel open for async response
  }
  
  // Handle quota status update from dashboard
  else if (message.action === "updateQuotaStatus") {
    // Make sure we preserve the isPaid flag if it exists
    const updatedQuotaStatus = { 
      ...message.quotaStatus,
      lastChecked: Date.now(),
      // Ensure isPaid reflects current subscription status
      isPaid: subscriptionStatus === 'active' || message.quotaStatus.isPaid
    };
    
    chrome.storage.local.set({ 
      quotaStatus: updatedQuotaStatus
    }, () => {
      console.log("Updated quota status:", updatedQuotaStatus);
      sendResponse({ success: true });
    });
    return true; // Keep channel open for async response
  }
  
  // Forward messages between content script and side panel
  if (sender.tab) {
    // Message from content script, forward to side panel
    chrome.runtime.sendMessage(message)
      .catch(err => {
        // Ignore errors when side panel isn't open
        console.log("Could not forward message to side panel:", err);
      });
  } else {
    // Messages from side panel to content script
    if (message.action === 'startProcessing' || 
        message.action === 'stopProcessing' || 
        message.action === 'checkKlingStatus') {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0] && tabs[0].url.includes('klingai.com')) {
          chrome.tabs.sendMessage(tabs[0].id, message)
            .catch(err => {
              console.log("Could not send message to content script:", err);
            });
        } else if (message.action === 'startProcessing') {
          // If trying to start processing but not on Kling page, navigate there
          chrome.tabs.update(tabs[0].id, { url: 'https://klingai.com' });
        }
      });
    }
  }
  
  // Default response for other messages
  sendResponse({ received: true });
  return true;
});

// Function to broadcast auth and subscription state to all content scripts
function broadcastAuthState() {
  const authMessage = { 
    action: "authStateChanged", 
    isLoggedIn: isUserLoggedIn,
    subscriptionStatus: subscriptionStatus,
    userId: currentUserId,
    timestamp: Date.now()
  };
  
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      // Only send to tabs where content script is loaded
      if (tab.url && tab.url.includes('klingai.com')) {
        chrome.tabs.sendMessage(tab.id, authMessage).catch(err => {
          // Ignore errors from tabs where content script isn't loaded
          console.log("Could not send to tab:", tab.id, err);
        });
      }
    });
  });
}

// Add tab activation listener to refresh auth state
chrome.tabs.onActivated.addListener((activeInfo) => {
  // When user switches to a tab, broadcast current auth state
  setTimeout(() => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
      if (tab && tab.url && tab.url.includes('klingai.com')) {
        chrome.tabs.sendMessage(activeInfo.tabId, { 
          action: "authStateChanged", 
          isLoggedIn: isUserLoggedIn,
          subscriptionStatus: subscriptionStatus,
          userId: currentUserId,
          timestamp: Date.now()
        }).catch(err => {
          console.log("Could not refresh auth state for activated tab:", err);
        });
      }
    });
  }, 500);
});

// Add window focus listener
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId !== chrome.windows.WINDOW_ID_NONE) {
    // Window gained focus, broadcast auth state to active tab
    setTimeout(() => {
      chrome.tabs.query({active: true, windowId: windowId}, (tabs) => {
        if (tabs[0] && tabs[0].url && tabs[0].url.includes('klingai.com')) {
          chrome.tabs.sendMessage(tabs[0].id, { 
            action: "authStateChanged", 
            isLoggedIn: isUserLoggedIn,
            subscriptionStatus: subscriptionStatus,
            userId: currentUserId,
            timestamp: Date.now()
          }).catch(err => {
            console.log("Could not refresh auth state for focused window:", err);
          });
        }
      });
    }, 500);
  }
});

// Periodic auth state validation (every 5 minutes)
setInterval(() => {
  // Validate that our auth state is still accurate
  // This is a safeguard against state drift
  chrome.storage.local.get(['authState'], (result) => {
    if (result.authState) {
      const storedState = result.authState;
      const now = Date.now();
      
      // If stored state is more than 10 minutes old, consider refreshing it
      if (now - storedState.lastUpdated > 10 * 60 * 1000) {
        console.log("Auth state is old, consider refreshing");
        // Optionally trigger a refresh here
      }
    }
  });
}, 5 * 60 * 1000); // Every 5 minutes