import { initializeApp } from "firebase/app"
import { getAuth, signInWithCredential, GoogleAuthProvider } from "firebase/auth"
import { getFirestore, doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore"
import { decrypt } from "./utils/encryption.js"

// Initialize Firebase with encrypted configuration
let app, auth, db, googleProvider;

try {
  // Get encrypted config and passphrase
  const encryptedConfig = import.meta.env.VITE_ENCRYPTED_FIREBASE_CONFIG;
  const passphrase = import.meta.env.VITE_DECRYPT_PASSPHRASE;
  
  let firebaseConfig;
  
  // In development, we might still use the direct environment variables
  if (encryptedConfig && passphrase) {
    // Production mode with encrypted config
    try {
      // Decrypt the configuration
      const decryptedConfig = decrypt(encryptedConfig, passphrase);
      // Parse the JSON
      firebaseConfig = JSON.parse(decryptedConfig);
      console.log("Using decrypted Firebase configuration");
    } catch (decryptError) {
      console.error("Error decrypting Firebase configuration:", decryptError);
      throw decryptError;
    }
  } else {
    // Development mode with direct environment variables
    firebaseConfig = {
      apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
      authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
      projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
      storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
      appId: import.meta.env.VITE_FIREBASE_APP_ID,
    };
    console.log("Using direct Firebase configuration");
  }
  
  // Initialize Firebase
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  googleProvider = new GoogleAuthProvider();
} catch (error) {
  console.error("Error initializing Firebase:", error);
  // Provide dummy exports to prevent import errors
  app = null;
  auth = { signInWithCredential: () => Promise.reject(new Error("Firebase not initialized")) };
  db = { collection: () => ({ doc: () => ({}) }) };
  googleProvider = {};
}

export { app, auth, db, googleProvider };
export const EXTENSION_ID = "KlingGen" // Keep your extension identifier

// Number of free items for trial users
export const FREE_TRIAL_QUOTA = 30

// Helper function for Google sign-in using Chrome identity
export const signInWithChromeIdentity = async () => {
  // Check if Firebase is initialized
  if (!app) {
    return Promise.reject(new Error("Firebase not initialized"));
  }
  
  // Check if chrome is defined (running in a Chrome extension context)
  if (typeof chrome === "undefined" || !chrome.runtime) {
    return Promise.reject(new Error("Chrome runtime is not available. Are you running in a Chrome Extension?"))
  }

  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: "signInWithGoogle" }, async (response) => {
      if (response && response.success) {
        try {
          // Create a credential with the token
          const credential = GoogleAuthProvider.credential(null, response.token)

          // Sign in with the credential
          const result = await signInWithCredential(auth, credential)
          
          // Store user data with trial - using the current extension ID
          await storeUserData(result.user, EXTENSION_ID)
          
          resolve(result.user)
        } catch (error) {
          reject(error)
        }
      } else {
        reject(new Error(response?.error || "Failed to get auth token"))
      }
    })
  })
}

// Rest of your file remains the same
// Function for creating new user data during registration
export const createNewUserData = async (user, extensionId = EXTENSION_ID) => {
  if (!user || !user.uid) {
    throw new Error("Invalid user object")
  }
  
  try {
    console.log(`Creating new user data for: ${user.uid} (${user.email}) for extension: ${extensionId}`)
    const userRef = doc(db, "users", user.uid)
    
    // Check if user document already exists
    const userDoc = await getDoc(userRef)
    
    // Generate display name from email if not provided
    const displayName = user.displayName || (user.email ? user.email.split('@')[0] : "User")
    
    // Calculate the trial end date (3 days from now)
    const trialEndDate = new Date()
    trialEndDate.setDate(trialEndDate.getDate() + 3)
    
    if (!userDoc.exists()) {
      // New user, create entire document
      const userData = {
        displayName: displayName,
        email: user.email,
        photoURL: user.photoURL || null,
        createdAt: serverTimestamp(),
        subscriptions: {
          [extensionId]: {
            status: "trial",
            plan: "trial",
            quota: FREE_TRIAL_QUOTA,
            used: 0,
            remaining: FREE_TRIAL_QUOTA,
            createdAt: serverTimestamp(),
            endDate: trialEndDate,
            trialEnd: trialEndDate
          },
        },
      }
      
      // Write directly to Firestore
      await setDoc(userRef, userData)
      console.log("Successfully created new user data")
      return true
    } else {
      // User exists but check if they have data for this extension
      const userData = userDoc.data()
      
      // Initialize subscriptions object if it doesn't exist
      if (!userData.subscriptions) {
        userData.subscriptions = {}
      }
      
      // Add this extension's subscription if not present
      if (!userData.subscriptions[extensionId]) {
        console.log(`Adding subscription data for extension ${extensionId}`)
        
        await setDoc(
          userRef, 
          {
            subscriptions: {
              ...userData.subscriptions,
              [extensionId]: {
                status: "trial",
                plan: "trial",
                quota: FREE_TRIAL_QUOTA,
                used: 0,
                remaining: FREE_TRIAL_QUOTA,
                createdAt: serverTimestamp(),
                endDate: trialEndDate,
                trialEnd: trialEndDate
              }
            }
          },
          { merge: true }
        )
        
        console.log("Successfully added subscription data for new extension")
        return true
      }
      
      return true
    }
  } catch (error) {
    console.error("Error creating new user data:", error)
    throw error
  }
}

// Regular user data management function for existing users
export const storeUserData = async (user, extensionId = EXTENSION_ID) => {
  if (!user || !user.uid) {
    console.error("Invalid user object provided to storeUserData")
    return false
  }

  try {
    console.log(`Storing data for user: ${user.uid} (${user.email}) for extension: ${extensionId}`)
    const userRef = doc(db, "users", user.uid)
    
    // Make sure we can access the database
    let userDoc
    try {
      userDoc = await getDoc(userRef)
    } catch (dbError) {
      console.error("Error accessing Firestore:", dbError)
      return false
    }

    // Generate a display name from email if not provided
    const displayName = user.displayName || (user.email ? user.email.split('@')[0] : "User")

    if (!userDoc.exists()) {
      // New user, add trial with free quota
      console.log(`Creating new user document with ${FREE_TRIAL_QUOTA} free quota for ${extensionId}`)

      // Calculate the trial end date (3 days from now)
      const trialEndDate = new Date()
      trialEndDate.setDate(trialEndDate.getDate() + 3)

      const userData = {
        displayName: displayName,
        email: user.email,
        photoURL: user.photoURL || null,
        createdAt: serverTimestamp(),
        subscriptions: {
          [extensionId]: {
            status: "trial",
            plan: "trial",
            quota: FREE_TRIAL_QUOTA,
            used: 0,
            remaining: FREE_TRIAL_QUOTA,
            createdAt: serverTimestamp(),
            endDate: trialEndDate,
            trialEnd: trialEndDate
          },
        },
      }

      // Use try/catch specifically for the database write operation
      try {
        console.log("Writing new user data to Firestore...")
        await setDoc(userRef, userData)
        console.log("Successfully wrote new user data")
        return true
      } catch (writeError) {
        console.error("Error writing to Firestore:", writeError)
        return false
      }
    } else {
      // Existing user, update last login and add this extension if not present
      console.log("User document already exists, checking for extension data...")
      const userData = userDoc.data()
      
      // Initialize subscriptions object if it doesn't exist
      if (!userData.subscriptions) {
        userData.subscriptions = {}
      }
      
      // Add this extension's subscription if not present
      if (!userData.subscriptions[extensionId]) {
        console.log(`Adding new subscription data for extension ${extensionId} with ${FREE_TRIAL_QUOTA} free quota`)

        // Calculate the trial end date (3 days from now)
        const trialEndDate = new Date()
        trialEndDate.setDate(trialEndDate.getDate() + 3)

        // Use setDoc with merge to only update the specific field
        await setDoc(
          userRef,
          {
            lastLogin: serverTimestamp(),
            subscriptions: {
              ...userData.subscriptions,
              [extensionId]: {
                status: "trial",
                plan: "trial",
                quota: FREE_TRIAL_QUOTA,
                used: 0,
                remaining: FREE_TRIAL_QUOTA,
                createdAt: serverTimestamp(),
                endDate: trialEndDate,
                trialEnd: trialEndDate
              }
            }
          },
          { merge: true }
        )
        console.log("Successfully added extension subscription data")
        return true
      } else {
        // Extension data already exists, just update login time
        await setDoc(
          userRef,
          { lastLogin: serverTimestamp() },
          { merge: true }
        )
        console.log("User already has subscription data for this extension")
        return true
      }
    }
  } catch (error) {
    console.error("Unexpected error in storeUserData:", error)
    return false
  }
}