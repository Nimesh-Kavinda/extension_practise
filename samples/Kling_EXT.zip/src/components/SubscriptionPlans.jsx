"use client"

import { useState } from "react"
import { createCheckoutSession, createCustomerPortalSession } from "../utils/subscription"

const PLANS = [
  {
    id: "monthly",
    name: "Monthly",
    price: "$4.99",
    period: "month",
    features: ["Full access to all features", "Premium support", "Regular updates"],
    popular: false,
    color: "bg-white dark:bg-gray-800",
    accentColor: "text-[#00A5FF] dark:text-[#00D2FF]",
    buttonColor: "bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] hover:opacity-90",
  },
  {
    id: "yearly",
    name: "Yearly",
    price: "$29.99",
    period: "year",
    features: ["Everything in Monthly", "Priority support", "Early access to new features", "50% savings vs monthly"],
    popular: false,
    color: "bg-[#00A5FF]/10 dark:bg-[#00D2FF]/10",
    accentColor: "text-[#00A5FF] dark:text-[#00D2FF]",
    buttonColor: "bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] hover:opacity-90",
    savings: "Save 50%",
  },
  {
    id: "lifetime",
    name: "Lifetime",
    price: "$49.99",
    period: "one-time",
    features: ["Everything in Yearly", "Lifetime access", "All future updates", "No recurring payments"],
    popular: true,
    color: "bg-white dark:bg-gray-800",
    accentColor: "text-green-600 dark:text-green-400",
    buttonColor: "bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] hover:opacity-90",
  },
]

const SubscriptionPlans = ({ user, subscriptionStatus }) => {
  const [loading, setLoading] = useState(false)
  const [processingPlanId, setProcessingPlanId] = useState(null)
  const [error, setError] = useState(null)

  const handleSubscribe = async (planId) => {
    if (!user?.email) return

    setProcessingPlanId(planId)
    setLoading(true)
    setError(null)

    try {
      const response = await createCheckoutSession(user.email, planId)

      if (response.sessionUrl) {
        // Open Stripe checkout in a new tab
        window.open(response.sessionUrl, "_blank")
      } else {
        setError(response.error || "Failed to create checkout session")
      }
    } catch (error) {
      console.error("Error creating checkout session:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
      setProcessingPlanId(null)
    }
  }

  const handleManageSubscription = async () => {
    if (!user?.email) return

    setLoading(true)
    setError(null)

    try {
      const response = await createCustomerPortalSession(user.email)

      if (response.url) {
        window.open(response.url, "_blank")
      } else {
        setError(response.error || "Failed to create customer portal session")
      }
    } catch (error) {
      console.error("Error creating customer portal session:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  // If user has an active subscription, show subscription details
  if (subscriptionStatus && (subscriptionStatus.status === "active" || subscriptionStatus.status === "active_canceling")) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center p-3 bg-green-100 dark:bg-green-800/20 rounded-full mb-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6 text-green-600 dark:text-green-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            {subscriptionStatus.status === "active_canceling" ? "Active Subscription (Canceling)" : "Active Subscription"}
          </h2>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
            You have an active {subscriptionStatus.plan} subscription{subscriptionStatus.status === "active_canceling" ? " that will cancel at the end of the billing period" : ""}.
          </p>
          {subscriptionStatus.endDate && subscriptionStatus.plan !== "lifetime" && (
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              Next billing date: {new Date(subscriptionStatus.endDate).toLocaleDateString()}
            </p>
          )}
        </div>

        <div className="flex justify-center">
          <button
            onClick={handleManageSubscription}
            disabled={loading}
            className="px-5 py-2.5 text-sm bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] dark:focus:ring-offset-gray-800 transition-colors font-medium flex items-center"
          >
            {loading ? (
              <span className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-[#00A5FF] dark:border-[#00D2FF] mr-2"></div>
                Loading...
              </span>
            ) : (
              <>
                Manage Subscription
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 ml-2"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </>
            )}
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-400 rounded-xl text-sm">
            {error}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="rounded-xl">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Choose Your Plan</h2>
        <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">Unlock all features with a subscription</p>
      </div>

      {/* Trial quota status message */}
      {subscriptionStatus && subscriptionStatus.status === "trial" && (
        <div className="text-center mb-6 bg-red-50 dark:bg-gray-800 border border-red-100 dark:border-red-800/50 text-red-800 dark:text-red-300 p-4 rounded-xl text-sm">
          <p className="font-medium">
            {subscriptionStatus.used || 0} of {subscriptionStatus.quota || 100} free quota used
          </p>
          <p className="text-xs mt-1 text-red-700 dark:text-red-400">
            {subscriptionStatus.remaining || 0} remaining. Subscribe for unlimited!
          </p>
        </div>
      )}

      {/* Expired trial message */}
      {subscriptionStatus && subscriptionStatus.status === "expired" && subscriptionStatus.plan === "trial" && (
        <div className="text-center mb-6 bg-amber-50 dark:bg-amber-900/10 text-amber-800 dark:text-amber-300 p-4 rounded-xl text-sm">
          <p className="font-medium">You've used all {subscriptionStatus.quota || 100} free quota</p>
          <p className="text-xs mt-1">Subscribe now to continue!</p>
        </div>
      )}

      {/* Payment failed message */}
      {subscriptionStatus && subscriptionStatus.status === "payment_failed" && (
        <div className="text-center mb-6 bg-red-50 dark:bg-red-900/10 text-red-800 dark:text-red-300 p-4 rounded-xl text-sm border border-red-200 dark:border-red-800/50">
          <div className="flex items-center justify-center mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <p className="font-medium">Payment Failed</p>
          </div>
          <p className="text-xs">Your payment could not be processed. Please update your payment method or choose a new plan to continue.</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PLANS.map((plan) => (
          <div
            key={plan.id}
            className={`${plan.color} rounded-xl shadow-sm overflow-hidden transition-all duration-200 transform hover:scale-[1.02] hover:shadow-md
              ${plan.popular ? "ring-2 ring-[#00A5FF] dark:ring-[#00D2FF]" : "border border-gray-200 dark:border-gray-700"}`}
          >
            {plan.popular && (
              <div className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] text-white text-xs font-semibold py-1.5 text-center">
                MOST POPULAR
              </div>
            )}

            <div className="p-5">
              <div className="flex items-center mb-3">
                <div className="bg-gray-100 dark:bg-gray-700 rounded-full p-2 mr-3">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 text-[#00A5FF] dark:text-[#00D2FF]"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">{plan.name}</h3>
                  {plan.savings && (
                    <span className="text-xs bg-green-100 dark:bg-green-800/20 text-green-700 dark:text-green-400 px-2 py-0.5 rounded-full">
                      {plan.savings}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-baseline mb-4">
                <span className="text-2xl font-extrabold text-gray-900 dark:text-white">{plan.price}</span>
                <span className="ml-1 text-sm text-gray-500 dark:text-gray-400">/{plan.period}</span>
              </div>

              <div className="space-y-2 mb-5">
                {plan.features.map((feature, index) => (
                  <div key={index} className="flex items-start text-sm">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-green-500 dark:text-green-400 mr-2 mt-0.5 flex-shrink-0"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => handleSubscribe(plan.id)}
                disabled={loading && processingPlanId === plan.id}
                className={`w-full py-2.5 px-4 rounded-xl text-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] dark:focus:ring-offset-gray-800 transition-all ${
                  plan.buttonColor
                } ${loading && processingPlanId === plan.id ? "opacity-70" : ""} shadow-sm`}
              >
                {loading && processingPlanId === plan.id ? (
                  <span className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                    Processing...
                  </span>
                ) : (
                  <span className="flex items-center justify-center">
                    Get {plan.name}
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 ml-1.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </span>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-100 dark:bg-red-900/10 text-red-700 dark:text-red-400 rounded-xl text-sm">
          {error}
        </div>
      )}

      <div className="mt-6 text-center text-xs text-gray-500 dark:text-gray-400 flex items-center justify-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-3.5 w-3.5 mr-1.5"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
          />
        </svg>
        Secure payment processing by Stripe. Cancel anytime.
      </div>
    </div>
  )
}

export default SubscriptionPlans

