"use client"

import { useState, useEffect, useRef } from "react"
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
} from "firebase/auth"
import { auth, signInWithChromeIdentity, createNewUserData, storeUserData, EXTENSION_ID } from "../firebase"

// Function to validate if email belongs to allowed providers
const isAllowedEmailDomain = (email) => {
  if (!email) return false;

  // Extract domain from email
  const domain = email.split('@')[1]?.toLowerCase();
  if (!domain) return false;

  // List of allowed domains
  const allowedDomains = [
    // Google
    'gmail.com',
    'googlemail.com',
    
    // Microsoft
    'outlook.com',
    'hotmail.com',
    'live.com',
    'msn.com',
    
    // Apple
    'icloud.com',
    'me.com',
    'mac.com',
    
    // Yahoo
    'yahoo.com',
    'ymail.com'
  ];

  // Check if the domain is in our allowed list
  return allowedDomains.includes(domain);
};

// Login component for authentication with email/password and Google
const Login = () => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isRegister, setIsRegister] = useState(false)
  const [error, setError] = useState("")
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const [googleLoading, setGoogleLoading] = useState(false)
  const [showVerificationNeeded, setShowVerificationNeeded] = useState(false)
  const [verificationEmail, setVerificationEmail] = useState("")
  const [showForgotPassword, setShowForgotPassword] = useState(false)
  const [resetEmail, setResetEmail] = useState("")
  const [resetLoading, setResetLoading] = useState(false)
  const [showEmailAuth, setShowEmailAuth] = useState(false)
  const [formHeight, setFormHeight] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  // New state for handling existing accounts
  const [hasExistingAccount, setHasExistingAccount] = useState(false)

  // Ref for measuring form content
  const formRef = useRef(null)

  // For animation timing
  const TRANSITION_DURATION = 300 // in ms

  // Effect for measuring form height
  useEffect(() => {
    if (formRef.current) {
      setFormHeight(formRef.current.scrollHeight)
    }
  }, [isRegister])

  // Effect for handling form transition
  useEffect(() => {
    if (isTransitioning) {
      const timer = setTimeout(() => {
        setIsTransitioning(false)
      }, TRANSITION_DURATION)
      return () => clearTimeout(timer)
    }
  }, [isTransitioning])

  // Add a custom CSS class for Firefly animated background
  useEffect(() => {
    // Add CSS for animated background
    const style = document.createElement('style');
    style.textContent = `
      .firefly-animated-bg {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
        background: linear-gradient(
          -45deg,
          #6EFF00,
          #00C3A5,
          #00D2FF,
          #00A5FF,
          #C3FF00
        );
        background-size: 400% 400%;
        animation: firefly-gradient 15s ease infinite;
      }
      
      @keyframes firefly-gradient {
        0% {
          background-position: 0% 50%;
        }
        50% {
          background-position: 100% 50%;
        }
        100% {
          background-position: 0% 50%;
        }
      }
      
      .firefly-theme input:focus {
        box-shadow: 0 0 0 2px rgba(110, 255, 0, 0.3);
      }
    `;
    
    document.head.appendChild(style);
    document.documentElement.classList.add('firefly-theme');
    
    return () => {
      document.head.removeChild(style);
      document.documentElement.classList.remove('firefly-theme');
    }
  }, []);

  // Countdown timer state
  const [countdown, setCountdown] = useState(0)
  const [countdownActive, setCountdownActive] = useState(false)

  // Effect for countdown timer
  useEffect(() => {
    let timer
    if (countdownActive && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1)
      }, 1000)
    } else if (countdown === 0) {
      setCountdownActive(false)
    }

    return () => {
      if (timer) clearTimeout(timer)
    }
  }, [countdown, countdownActive])

  // Format seconds to mm:ss
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Handle Google Sign In using Chrome identity
  const handleGoogleSignIn = async () => {
    setError("")
    setMessage("")
    setGoogleLoading(true)

    try {
      await signInWithChromeIdentity()
      // Authentication state change will update the UI
    } catch (err) {
      setError(getErrorMessage(err.code) || err.message)
      console.error(err)
      // Show email/password option on Google signin failure
      setShowEmailAuth(true)
    } finally {
      setGoogleLoading(false)
    }
  }

  // Toggle between register and login with smooth transition
  const toggleAuthMode = () => {
    setIsTransitioning(true)
    setTimeout(() => {
      setIsRegister(!isRegister)
      setError("")
      setMessage("")
      setConfirmPassword("")
      setHasExistingAccount(false) // Reset existing account state when toggling
    }, TRANSITION_DURATION / 2) // Switch halfway through the transition
  }

  // Handle login/register with email validation
  const handleAuth = async (e) => {
    e.preventDefault()
    setError("")
    setMessage("")
    
    // Check if email is from allowed providers
    if (!isAllowedEmailDomain(email)) {
      setError("Please use an email from Google, Microsoft, Apple, or Yahoo. We don't support temporary email providers.")
      return
    }
    
    // Validate passwords match for registration
    if (isRegister && password !== confirmPassword) {
      setError("Passwords do not match. Please try again.")
      return
    }
    
    setLoading(true)

    try {
      if (isRegister) {
        console.log("Starting registration process...")

        try {
          // 1. Try to create the user account first
          const userCredential = await createUserWithEmailAndPassword(auth, email, password)
          console.log("User account created successfully:", userCredential.user.uid)

          // 2. Before anything else, immediately store the user data
          try {
            console.log("Storing user data immediately after account creation")
            // Store user data for this specific extension
            await createNewUserData(userCredential.user, EXTENSION_ID)
            console.log("User data stored successfully")
          } catch (storageError) {
            console.error("Failed to store user data:", storageError)
            setError("Warning: Account created but there was an issue setting up your user data.")
          }

          // 3. Now send verification email
          console.log("Sending verification email...")
          await sendEmailVerification(userCredential.user)

          // 4. Sign out the user manually
          console.log("Manual sign out after registration")
          await auth.signOut()

          // 5. Show verification screen
          setShowVerificationNeeded(true)
          setVerificationEmail(email)
          setMessage("Registration successful! Please check your email to verify your account before logging in.")

          // Start countdown timer
          setCountdown(60)
          setCountdownActive(true)
        } catch (err) {
          // Check specifically for email-already-in-use error
          if (err.code === "auth/email-already-in-use") {
            console.log("Email already in use, showing friendly message")
            setHasExistingAccount(true)
            setError("This email is already registered. You might have an account with one of our extensions.")
          } else {
            // For other errors, just throw normally
            throw err
          }
        }
      } else {
        // Standard login flow
        // Sign in the user
        const userCredential = await signInWithEmailAndPassword(auth, email, password)

        // Check if email is verified
        if (!userCredential.user.emailVerified) {
          // If not verified, sign out and show verification message
          await auth.signOut()
          setShowVerificationNeeded(true)
          setVerificationEmail(email)
          setError("Your email is not verified. Please verify your email before logging in.")

          // Start countdown timer (60 seconds)
          setCountdown(60)
          setCountdownActive(true)
        } else {
          // IMPORTANT: If they're verified, ensure this extension has subscription data
          // This happens even on normal login to handle cross-extension cases
          await storeUserData(userCredential.user, EXTENSION_ID)

          // Authentication state change will handle the UI update
          console.log("Login successful and data verified for this extension")
        }
      }
    } catch (err) {
      setError(getErrorMessage(err.code) || err.message)
      console.error("Authentication error:", err)
    } finally {
      setLoading(false)
    }
  }

  // Function to handle password reset request
  const handlePasswordReset = async (e) => {
    e.preventDefault()
    setError("")
    setMessage("")
    
    // Check if reset email is from allowed providers
    if (!isAllowedEmailDomain(resetEmail)) {
      setError("Please use an email from Google, Microsoft, Apple, or Yahoo. We don't support temporary email providers.")
      return
    }
    
    setResetLoading(true)

    try {
      await sendPasswordResetEmail(auth, resetEmail)
      setMessage("Password reset email sent! Check your inbox for instructions.")

      // Start countdown timer (60 seconds)
      setCountdown(60)
      setCountdownActive(true)
    } catch (err) {
      setError(getErrorMessage(err.code) || err.message)
      console.error("Password reset error:", err)
    } finally {
      setResetLoading(false)
    }
  }

  // Function to resend verification email
  const handleResendVerification = async () => {
    setLoading(true)
    setError("")
    setMessage("")

    try {
      // Sign in to get the user object (required to send verification email)
      const userCredential = await signInWithEmailAndPassword(auth, verificationEmail, password)

      // Send verification email
      await sendEmailVerification(userCredential.user)

      // Sign out since we only signed in to send the verification
      await auth.signOut()

      setMessage("Verification email sent! Please check your inbox.")

      // Start countdown timer (60 seconds)
      setCountdown(60)
      setCountdownActive(true)
    } catch (err) {
      setError(getErrorMessage(err.code) || err.message)
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  // Helper to get more user-friendly error messages
  const getErrorMessage = (errorCode) => {
    switch (errorCode) {
      case "auth/invalid-email":
        return "Invalid email address format."
      case "auth/user-disabled":
        return "This account has been disabled."
      case "auth/user-not-found":
        return "No account found with this email."
      case "auth/wrong-password":
        return "Incorrect password."
      case "auth/email-already-in-use":
        return "An account with this email already exists."
      case "auth/weak-password":
        return "Password is too weak. Please use at least 6 characters."
      case "auth/network-request-failed":
        return "Network error. Please check your connection."
      case "auth/too-many-requests":
        return "Too many unsuccessful login attempts. Please try again later."
      case "auth/popup-closed-by-user":
        return "Sign in was cancelled. Please try again."
      case "auth/popup-blocked":
        return "Sign in popup was blocked by your browser. Please allow popups for this site."
      case "auth/cancelled-popup-request":
        return "The sign in process was cancelled. Please try again."
      case "auth/internal-error":
        return "An internal authentication error occurred. Please try again."
      default:
        return null
    }
  }

  // Reset the verification flow
  const handleBackToLogin = () => {
    setShowVerificationNeeded(false)
    setShowForgotPassword(false)
    setVerificationEmail("")
    setResetEmail("")
    setError("")
    setMessage("")
    setCountdownActive(false)
    setCountdown(0)
    setHasExistingAccount(false)
  }

  // Handle switching to login when user has existing account
  const handleSwitchToLogin = () => {
    setIsRegister(false)
    setHasExistingAccount(false)
    setError("")
  }

  // Show forgot password screen
  if (showForgotPassword) {
    return (
      <>
        <div className="firefly-animated-bg"></div>
        <div className="w-full max-w-md mx-auto relative z-10">
          {/* Simplified header */}
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">KlingGen</h1>
            <p className="text-gray-700 dark:text-white/80 text-sm">Kling AI Video Generator</p>
          </div>
          
          <div className="bg-white/70 dark:bg-black/70 backdrop-blur-md rounded-xl border border-white/20 dark:border-gray-700/30 shadow-lg overflow-hidden transition-all duration-300">
            {/* Header with gradient */}
            <div className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] p-6 text-white relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-24 h-24 rounded-full bg-white/10 backdrop-blur-sm"></div>
              <div className="absolute -bottom-10 -left-10 w-20 h-20 rounded-full bg-black/10 backdrop-blur-sm"></div>
              <h2 className="text-xl font-bold text-center relative z-10">Reset Your Password</h2>
            </div>

            <div className="p-6">
              <div className="mb-6 text-center">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Forgot Your Password?</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-5">
                  Enter your email address and we'll send you a link to reset your password.
                </p>

                {error && (
                  <div className="flex items-start rounded-lg overflow-hidden mb-4 bg-red-50/80 dark:bg-red-900/20 backdrop-blur-sm border border-red-200 dark:border-red-800/30 text-red-600 dark:text-red-400 p-3 text-sm">
                    {error}
                  </div>
                )}

                {message && (
                  <div className="flex items-start rounded-lg overflow-hidden mb-4 bg-green-50/80 dark:bg-green-900/20 backdrop-blur-sm border border-green-200 dark:border-green-800/30 text-green-600 dark:text-green-400 p-3 text-sm">
                    {message}
                  </div>
                )}

                <form onSubmit={handlePasswordReset} className="mb-4">
                  <div className="relative mb-4">
                    <input
                      type="email"
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      required
                      className="w-full px-3 py-2.5 border border-gray-300/70 dark:border-gray-600/50 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#6EFF00] focus:border-[#6EFF00] dark:text-white transition-all duration-200"
                      placeholder="your@email.com"
                    />
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 text-left">
                      We only accept emails from Google, Microsoft, Apple, and Yahoo.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={resetLoading || countdownActive}
                    className="w-full mb-3 py-2.5 px-4 rounded-lg shadow-lg text-sm font-medium text-white bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center"
                  >
                    {resetLoading
                      ? "Sending..."
                      : countdownActive
                        ? `Resend in ${formatTime(countdown)}`
                        : "Send Reset Link"}
                  </button>
                </form>

                <button
                  onClick={handleBackToLogin}
                  className="w-full py-2.5 px-4 border border-gray-300/70 dark:border-gray-600/50 rounded-lg shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm hover:bg-gray-50 dark:hover:bg-gray-700/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] transition-all duration-200"
                >
                  Back to Login
                </button>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }

  // Show the verification needed screen
  if (showVerificationNeeded) {
    return (
      <>
        <div className="firefly-animated-bg"></div>
        <div className="w-full max-w-md mx-auto relative z-10">
          {/* Simplified header */}
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">KlingGen</h1>
            <p className="text-gray-700 dark:text-white/80 text-sm">Kling AI Video Generator</p>
          </div>
          
          <div className="bg-white/70 dark:bg-black/70 backdrop-blur-md rounded-xl border border-white/20 dark:border-gray-700/30 shadow-lg overflow-hidden transition-all duration-300">
            {/* Header with gradient */}
            <div className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] p-6 text-white relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-24 h-24 rounded-full bg-white/10 backdrop-blur-sm"></div>
              <div className="absolute -bottom-10 -left-10 w-20 h-20 rounded-full bg-black/10 backdrop-blur-sm"></div>
              <h2 className="text-xl font-bold text-center relative z-10">Email Verification</h2>
            </div>

            <div className="p-6">
              <div className="mb-6 text-center">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Check Your Inbox</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-3">We've sent a verification email to:</p>
                <div className="bg-gray-100/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg border border-gray-200/70 dark:border-gray-700/30 px-4 py-3 mb-4">
                  <p className="font-medium text-gray-800 dark:text-white break-all">{verificationEmail}</p>
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                  Click the verification link in the email to activate your account. You won't be able to log in until
                  your email is verified.
                </p>

                {error && (
                  <div className="bg-red-50/80 dark:bg-red-900/20 backdrop-blur-sm border border-red-200 dark:border-red-800/30 p-3 text-sm text-red-600 dark:text-red-400 rounded-lg mb-4">
                    {error}
                  </div>
                )}

                {message && (
                  <div className="bg-green-50/80 dark:bg-green-900/20 backdrop-blur-sm border border-green-200 dark:border-green-800/30 p-3 text-sm text-green-600 dark:text-green-400 rounded-lg mb-4">
                    {message}
                  </div>
                )}

                <button
                  onClick={handleResendVerification}
                  disabled={loading || countdownActive}
                  className="w-full mb-3 py-2.5 px-4 rounded-lg shadow-lg text-sm font-medium text-white bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {loading
                    ? "Sending..."
                    : countdownActive
                      ? `Resend in ${formatTime(countdown)}`
                      : "Resend Verification Email"}
                </button>

                <button
                  onClick={handleBackToLogin}
                  className="w-full py-2.5 px-4 border border-gray-300/70 dark:border-gray-600/50 rounded-lg shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm hover:bg-gray-50 dark:hover:bg-gray-700/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] transition-all duration-200"
                >
                  Back to Login
                </button>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }

  // Standard login/register form
  return (
    <>
      <div className="firefly-animated-bg"></div>
      <div className="w-full max-w-md mx-auto relative z-10">
        {/* Simplified header */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">KlingGen</h1>
          <p className="text-gray-700 dark:text-white/80 text-sm">Kling AI Video Generator</p>
        </div>
        
        <div className="bg-white/70 dark:bg-black/70 backdrop-blur-md rounded-xl border border-white/20 dark:border-gray-700/30 shadow-lg overflow-hidden transition-all duration-300">
          {/* Header with gradient */}
          <div className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] p-6 text-white relative overflow-hidden">
            <div className="absolute -top-10 -right-10 w-24 h-24 rounded-full bg-white/10 backdrop-blur-sm"></div>
            <div className="absolute -bottom-10 -left-10 w-20 h-20 rounded-full bg-black/10 backdrop-blur-sm"></div>
            <h2 className="text-xl font-bold text-center relative z-10">{isRegister ? "Create Account" : "Welcome Back"}</h2>
            <p className="text-center text-white/80 text-sm mt-1 relative z-10">
              {isRegister ? "Sign up to get started" : "Sign in to your account"}
            </p>
          </div>

          <div className="p-6">
            {message && (
              <div className="flex items-center gap-2 mb-4 p-3 bg-green-50/80 dark:bg-green-900/20 backdrop-blur-sm border border-green-200 dark:border-green-800/30 text-green-700 dark:text-green-300 text-sm rounded-lg">
                <span>{message}</span>
              </div>
            )}

            {/* Existing Account Notice */}
            {isRegister && hasExistingAccount && (
              <div className="mb-4 p-4 border border-red-500/30 dark:border-red-500/20 bg-red-500/10 dark:bg-red-500/5 backdrop-blur-sm text-red-600 dark:text-red-400 rounded-lg">
                <h3 className="text-sm font-semibold mb-1 flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-2"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                    />
                  </svg>
                  Account Already Exists
                </h3>
                <p className="text-sm">
                  This email is already registered. You might have an account with one of our extensions.
                </p>
                <button
                  onClick={handleSwitchToLogin}
                  className="mt-2 text-xs font-medium text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 focus:outline-none transition-colors"
                >
                  Switch to Login &rarr;
                </button>
              </div>
            )}

            {error && !hasExistingAccount && (
              <div className="mb-4 p-3 bg-red-50/80 dark:bg-red-900/20 backdrop-blur-sm border border-red-200 dark:border-red-800/30 text-red-600 dark:text-red-400 text-sm rounded-lg">
                {error}
              </div>
            )}

            {/* Show Google Sign-In button first */}
            <div className="mb-4">
              <button
                onClick={handleGoogleSignIn}
                disabled={googleLoading}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-white dark:bg-white/10 backdrop-blur-sm border border-gray-300 dark:border-gray-700/50 rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] transition-all duration-200 text-sm font-medium text-gray-700 dark:text-white/90 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {googleLoading ? (
                  "Connecting..."
                ) : (
                  <>
                    <svg width="18" height="18" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
                      <path
                        fill="#FFC107"
                        d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"
                      />
                      <path
                        fill="#FF3D00"
                        d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"
                      />
                      <path
                        fill="#4CAF50"
                        d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"
                      />
                      <path
                        fill="#1976D2"
                        d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"
                      />
                    </svg>
                    Continue with Google
                  </>
                )}
              </button>
            </div>

            {/* Email/Password divider */}
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300 dark:border-gray-700"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400">
                  Or continue with email
                </span>
              </div>
            </div>

            {/* Email/Password Form */}
            <div
              ref={formRef}
              className={`overflow-hidden transition-all duration-${TRANSITION_DURATION} ease-in-out`}
              style={{ height: isTransitioning ? formHeight + "px" : "auto" }}
            >
              <form onSubmit={handleAuth} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Email Address
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-gray-300/70 dark:border-gray-600/50 rounded-lg shadow-sm bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#00A5FF] focus:border-[#00A5FF] dark:text-white transition-all duration-200"
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Password
                    </label>
                    {!isRegister && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowForgotPassword(true)
                          setResetEmail(email)
                        }}
                        className="text-xs font-medium text-[#00A5FF] dark:text-[#00D2FF] hover:text-[#00D2FF] dark:hover:text-[#00A5FF] focus:outline-none transition-colors"
                      >
                        Forgot Password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="w-full px-3 py-2 border border-gray-300/70 dark:border-gray-600/50 rounded-lg shadow-sm bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#00A5FF] focus:border-[#00A5FF] dark:text-white transition-all duration-200 pr-10"
                      placeholder="••••••••"
                      minLength={6}
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 flex items-center px-3 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none transition-colors"
                      onClick={() => setShowPassword(!showPassword)}
                      tabIndex="-1"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clipRule="evenodd" />
                          <path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.065 7 9.542 7 .847 0 1.669-.105 2.454-.303z" />
                        </svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                          <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </button>
                  </div>
                  {isRegister && (
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      Password must be at least 6 characters
                    </p>
                  )}
                </div>

                {/* Confirm Password Field - Only shown during registration */}
                {isRegister && (
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Confirm Password
                    </label>
                    <div className="relative">
                      <input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        className={`w-full px-3 py-2 border ${
                          confirmPassword && password !== confirmPassword
                            ? "border-red-300 dark:border-red-600 focus:ring-red-500 focus:border-red-500"
                            : "border-gray-300/70 dark:border-gray-600/50 focus:ring-[#00A5FF] focus:border-[#00A5FF]"
                        } rounded-lg shadow-sm bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm placeholder-gray-400 focus:outline-none focus:ring-2 dark:text-white transition-all duration-200 pr-10`}
                        placeholder="••••••••"
                        minLength={6}
                      />
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 flex items-center px-3 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none transition-colors"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        tabIndex="-1"
                        aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                      >
                        {showConfirmPassword ? (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clipRule="evenodd" />
                            <path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.065 7 9.542 7 .847 0 1.669-.105 2.454-.303z" />
                          </svg>
                        ) : (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                            <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                          </svg>
                        )}
                      </button>
                    </div>
                    {confirmPassword && password !== confirmPassword && (
                      <p className="mt-1 text-xs text-red-500 dark:text-red-400">
                        Passwords do not match
                      </p>
                    )}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading || (isRegister && password !== confirmPassword && confirmPassword !== "")}
                  className="w-full py-2.5 px-4 rounded-lg shadow-lg text-sm font-medium text-white bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#00A5FF] transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {loading ? (
                    "Processing..."
                  ) : isRegister ? (
                    "Create Account"
                  ) : (
                    "Sign In"
                  )}
                </button>
              </form>
            </div>

            {/* Toggle between login/register */}
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {isRegister ? "Already have an account? " : "Don't have an account? "}
                <button
                  type="button"
                  onClick={toggleAuthMode}
                  className="font-medium text-[#00A5FF] dark:text-[#00D2FF] hover:text-[#00D2FF] dark:hover:text-[#00A5FF] focus:outline-none transition-colors"
                >
                  {isRegister ? "Sign in instead" : "Create account"}
                </button>
              </p>
            </div>
          </div>
        </div>

        {/* Terms and conditions footer */}
        <p className="mt-4 text-xs text-center text-gray-500 dark:text-gray-400">
          By continuing, you agree to our{" "}
          <a
            href="https://oxymaicorp.com/terms-of-service"
            target="_blank"
            rel="noreferrer"
            className="underline hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
          >
            Terms of Service
          </a>{" "}
          and{" "}
          <a
            href="https://oxymaicorp.com/privacy-policy"
            target="_blank"
            rel="noreferrer"
            className="underline hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
          >
            Privacy Policy
          </a>
        </p>
      </div>
    </>
  )
}

export default Login