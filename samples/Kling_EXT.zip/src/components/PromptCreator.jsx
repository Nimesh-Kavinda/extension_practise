"use client"

import { useState, useEffect, useRef } from "react"

const PromptCreator = ({ onBack }) => {
  // Core state
  const [apiKey, setApiKey] = useState("")
  const [promptType, setPromptType] = useState("creative")
  const [promptLength, setPromptLength] = useState("medium")
  const [numberOfPrompts, setNumberOfPrompts] = useState(10)
  const [customTheme, setCustomTheme] = useState("")
  const [creativity, setCreativity] = useState(0.9)

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false)
  const [progress, setProgress] = useState(0)
  const [collected, setCollected] = useState(0)
  const [attempt, setAttempt] = useState(0)
  const [prompts, setPrompts] = useState([])

  // UI state
  const [showApiKey, setShowApiKey] = useState(false)
  const [status, setStatus] = useState({ text: "", type: "" })
  const [showAdvanced, setShowAdvanced] = useState(false)

  // Advanced options - Video specific
  const [includeStyle, setIncludeStyle] = useState(true)
  const [includeLighting, setIncludeLighting] = useState(true)
  const [includeMood, setIncludeMood] = useState(true)
  const [includeColors, setIncludeColors] = useState(true)
  const [includeMovement, setIncludeMovement] = useState(true)
  const [includeCameraWork, setIncludeCameraWork] = useState(true)
  const [mustInclude, setMustInclude] = useState("")
  const [exclude, setExclude] = useState("")
  const [videoStory, setVideoStory] = useState("")

  // Refs for cleanup
  const abortRef = useRef(null)
  const timeoutRef = useRef(null)

  // Constants
  const PROMPT_TYPES = [
    { id: "creative", name: "Creative Videos", desc: "Artistic and imaginative video prompts", icon: "🎬" },
    { id: "realistic", name: "Realistic Scenes", desc: "Photorealistic video scene prompts", icon: "🎥" },
    { id: "abstract", name: "Abstract Motion", desc: "Abstract and conceptual video prompts", icon: "🌀" },
    { id: "character", name: "Character Actions", desc: "Character and portrait video prompts", icon: "🎭" },
    { id: "landscape", name: "Nature & Scenery", desc: "Landscape and environment video prompts", icon: "🌄" }
  ]

  const LENGTH_OPTIONS = [
    { id: "short", name: "Short", desc: "5-15 words", tokens: 20 },
    { id: "medium", name: "Medium", desc: "15-30 words", tokens: 40 },
    { id: "long", name: "Long", desc: "30-50 words", tokens: 70 },
    { id: "detailed", name: "Very Detailed", desc: "50+ words", tokens: 100 }
  ]

  const MAX_ATTEMPTS = 5

  // Load API key from storage
  useEffect(() => {
    const saved = localStorage.getItem('gemini_api_key')
    if (saved) setApiKey(saved)
  }, [])

  // Save API key to storage
  useEffect(() => {
    if (apiKey.trim()) localStorage.setItem('gemini_api_key', apiKey)
  }, [apiKey])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (abortRef.current) abortRef.current.abort()
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
    }
  }, [])

  // Show status message (matching FireflyDashboard pattern)
  const showStatus = (message, type, duration = 5000) => {
    setStatus({ text: message, type })
    if (type !== "error") {
      timeoutRef.current = setTimeout(() => {
        setStatus((prevStatus) => (prevStatus.text === message ? { text: "", type: "" } : prevStatus))
      }, duration)
    }
  }

  // Reset generation state
  const resetGeneration = () => {
    setIsGenerating(false)
    setProgress(0)
    setCollected(0)
    setAttempt(0)
    if (abortRef.current) abortRef.current.abort()
  }

  // Build system prompt
  const buildPrompt = (type, length, remaining, existing) => {
    const promptType = PROMPT_TYPES.find(t => t.id === type)
    const lengthOpt = LENGTH_OPTIONS.find(l => l.id === length)

    let prompt = `Generate ${remaining} unique video generation prompts for ${promptType.desc.toLowerCase()}.

Requirements:
- ${lengthOpt.desc} each
- ${promptType.name.toLowerCase()} style
- Focus on motion, movement, and temporal elements
- Include camera angles, transitions, and video dynamics
- Optimized for AI video generation with clear action descriptions`

    // Add advanced options - Video specific
    const details = []
    if (includeStyle) details.push("visual style and aesthetics")
    if (includeLighting) details.push("lighting and cinematography")
    if (includeMood) details.push("mood and atmosphere")
    if (includeColors) details.push("color palette and tone")
    if (includeMovement) details.push("movement and motion dynamics")
    if (includeCameraWork) details.push("camera angles and transitions")
    
    if (details.length) prompt += `\n- Include: ${details.join(", ")}`
    if (customTheme) prompt += `\n- Theme: ${customTheme}`
    if (videoStory) prompt += `\n- Base the prompts on this video concept: ${videoStory}`
    if (mustInclude) prompt += `\n- Must include: ${mustInclude}`
    if (exclude) prompt += `\n- Avoid: ${exclude}`

    // Prevent duplicates
    if (existing.length) {
      prompt += `\n- Different from: ${existing.slice(0, 5).map(p => `"${p}"`).join(", ")}`
    }

    prompt += `\n\nReturn ONLY prompts, one per line, no numbering. Generate exactly ${remaining} prompts.`
    return prompt
  }

  // Make API call
  const callAPI = async (prompt, attemptNum) => {
    abortRef.current = new AbortController()
    
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: abortRef.current.signal,
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: Math.min(creativity + (attemptNum * 0.05), 1.0),
            topK: 40,
            topP: 0.95,
            maxOutputTokens: Math.min(numberOfPrompts * LENGTH_OPTIONS.find(l => l.id === promptLength).tokens + 200, 8192)
          }
        })
      }
    )

    if (!response.ok) {
      const error = await response.json().catch(() => ({}))
      throw new Error(error.error?.message || `API failed: ${response.status}`)
    }

    const data = await response.json()
    if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
      throw new Error("No content generated")
    }

    return data.candidates[0].content.parts[0].text
  }

  // Parse API response
  const parsePrompts = (text, existing) => {
    return text
      .split('\n')
      .map(p => p.trim())
      .filter(p => p.length > 10 && !p.match(/^\d+[.)]/))
      .filter(p => !existing.includes(p))
      .slice(0, numberOfPrompts - existing.length)
  }

  // Main generation function
  const generatePrompts = async () => {
    // Validation
    if (!apiKey.trim()) {
      showStatus("Please enter your Gemini API key", "error")
      return
    }
    if (numberOfPrompts < 1 || numberOfPrompts > 100) {
      showStatus("Number must be between 1-100", "error")
      return
    }

    // Initialize
    setIsGenerating(true)
    setProgress(0)
    setCollected(0)
    setAttempt(1)
    setPrompts([])
    
    let allPrompts = []
    let currentAttempt = 1

    try {
      while (allPrompts.length < numberOfPrompts && currentAttempt <= MAX_ATTEMPTS) {
        const remaining = numberOfPrompts - allPrompts.length

        // Update UI
        setAttempt(currentAttempt)
        setCollected(allPrompts.length)
        setProgress((allPrompts.length / numberOfPrompts) * 100)

        const statusMsg = currentAttempt === 1 
          ? "Generating prompts..." 
          : `Attempt ${currentAttempt} - Collected ${allPrompts.length}/${numberOfPrompts}`
        showStatus(statusMsg, "info")

        // Build prompt and call API
        const systemPrompt = buildPrompt(promptType, promptLength, remaining, allPrompts)
        const responseText = await callAPI(systemPrompt, currentAttempt)
        const newPrompts = parsePrompts(responseText, allPrompts)

        if (newPrompts.length === 0) {
          throw new Error("No valid prompts generated")
        }

        // Update prompts
        allPrompts = [...allPrompts, ...newPrompts]
        setCollected(allPrompts.length)
        setProgress((allPrompts.length / numberOfPrompts) * 100)

        // Small delay between attempts
        if (allPrompts.length < numberOfPrompts) {
          await new Promise(resolve => setTimeout(resolve, 1000))
        }

        currentAttempt++
      }

      // Success
      if (allPrompts.length >= numberOfPrompts) {
        const final = allPrompts.slice(0, numberOfPrompts)
        setPrompts(final)
        setProgress(100)
        showStatus(`Generated ${final.length} prompts successfully!`, "success")
        
        // Reset loading state after UI updates
        setTimeout(resetGeneration, 200)
      } else {
        throw new Error(`Only generated ${allPrompts.length}/${numberOfPrompts} after ${MAX_ATTEMPTS} attempts`)
      }

    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error("Generation failed:", error)
        showStatus(`Error: ${error.message}`, "error")
      }
      resetGeneration()
    }
  }

  // Download prompts (clean text file with only prompts)
  const downloadPrompts = () => {
    if (!prompts.length) return
    
    const timestamp = new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')
    
    // Create clean text file with only prompts, one per line
    const content = prompts.join('\n')

    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `video-prompts-${promptType}-${timestamp}.txt`
    a.click()
    URL.revokeObjectURL(url)
    
    showStatus("Downloaded successfully!", "success", 2000)
  }

  // Copy to clipboard
  const copyPrompts = async () => {
    if (!prompts.length) return
    try {
      await navigator.clipboard.writeText(prompts.join('\n'))
      showStatus("Copied to clipboard!", "success", 2000)
    } catch {
      showStatus("Failed to copy", "error")
    }
  }

  const clearApiKey = () => {
    setApiKey("")
    localStorage.removeItem('gemini_api_key')
    showStatus("API key cleared", "info", 2000)
  }

  return (
    <div className="flex flex-col bg-gradient-to-br from-white to-gray-50 dark:from-gray-800 dark:to-gray-900 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700 transition-all duration-300">
      {/* Header matching FireflyDashboard exactly */}
      <div className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] p-3 sm:p-4 text-white">
        <div className="flex flex-col space-y-3 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
          <div className="flex items-center space-x-2 min-w-0">
            <button
              onClick={onBack}
              className="p-2.5 bg-white/20 hover:bg-white/30 rounded-xl transition-all duration-200 mr-2 border border-white/20 hover:border-white/40 shadow-sm hover:shadow-md transform hover:scale-105 active:scale-95"
              title="Back to Dashboard"
            >
              <svg className="h-5 w-5 text-white drop-shadow-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <h2 className="text-base sm:text-lg font-semibold truncate">AI Video Prompt Creator</h2>
          </div>
          <div className="flex items-center justify-between sm:justify-end space-x-2 sm:space-x-3">
            <div className="px-2 py-0.5 rounded-full text-xs font-medium flex items-center flex-shrink-0 bg-green-500/20 text-white">
              <div className="w-2 h-2 rounded-full mr-1.5 bg-green-400 animate-pulse"></div>
              <span className="hidden xs:inline">Ready</span>
              <span className="xs:hidden">ON</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Status message matching FireflyDashboard */}
        {status.text && (
          <div 
            className={`mb-4 p-3 rounded-lg text-sm border backdrop-blur-sm shadow-sm ${
              status.type === "success" 
                ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800/30 text-green-700 dark:text-green-400' 
                : status.type === "error" 
                  ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800/30 text-red-700 dark:text-red-400' 
                  : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30 text-blue-700 dark:text-blue-400'
            } animate-fadeIn`}
          >
            {status.text}
          </div>
        )}

        {/* API Key Section */}
        <div className="mb-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700 transition-all hover:shadow-md">
          <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-700">
            <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#00A5FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-6 6c-1.105 0-2.035-.85-2.148-1.938C11.477 13.055 10.744 13 10 13c-3.314 0-6-2.686-6-6s2.686-6 6-6c1.105 0 2 .895 2 2 0 1.105.895 2 2 2z" />
              </svg>
              API Configuration
            </h3>
            {apiKey && (
              <button onClick={clearApiKey} className="text-xs text-[#00A5FF] dark:text-[#00D2FF] font-medium px-2 py-0.5 bg-[#00A5FF]/10 dark:bg-[#00D2FF]/20 rounded-full hover:bg-[#00A5FF]/20 dark:hover:bg-[#00D2FF]/30 transition-colors">
                Clear
              </button>
            )}
          </div>
          
          <div className="p-4">
            <div className="mb-3">
              <div className="relative">
                <input
                  type={showApiKey ? "text" : "password"}
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your Gemini API key..."
                  className="w-full px-4 py-3 pr-10 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#00A5FF] focus:border-transparent transition-colors text-sm"
                />
                <button
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                >
                  {showApiKey ? (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
                    </svg>
                  ) : (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  )}
                </button>
                {apiKey && <div className="absolute right-12 top-1/2 -translate-y-1/2 text-green-500 text-sm">✓</div>}
              </div>
            </div>
            
            <div className="p-3 bg-[#00A5FF]/10 dark:bg-[#00D2FF]/20 rounded-lg border border-[#00A5FF]/20 dark:border-[#00D2FF]/30">
              <p className="text-sm text-[#00A5FF] dark:text-[#00D2FF]">
                Get your free API key at <a href="https://makersuite.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="underline font-medium hover:text-[#00D2FF] dark:hover:text-[#00A5FF] transition-colors">Google AI Studio</a>
              </p>
            </div>
          </div>
        </div>

        {/* Configuration Section */}
        <div className="mb-4 p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 transition-all hover:shadow-md">
          <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#00A5FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Settings
          </h3>

          <div className="space-y-4">
            {/* Prompt Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Style</label>
              <div className="grid gap-2">
                {PROMPT_TYPES.map(type => (
                  <button
                    key={type.id}
                    onClick={() => setPromptType(type.id)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      promptType === type.id
                        ? 'border-[#00A5FF] bg-[#00A5FF] text-white'
                        : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500 bg-white dark:bg-gray-700'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-lg">{type.icon}</span>
                      <div className="min-w-0 flex-1">
                        <div className={`font-medium text-sm truncate ${promptType === type.id ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                          {type.name}
                        </div>
                        <div className={`text-xs truncate ${promptType === type.id ? 'text-white/80' : 'text-gray-500'}`}>
                          {type.desc}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Length */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Length</label>
              <div className="grid grid-cols-2 gap-2">
                {LENGTH_OPTIONS.map(length => (
                  <button
                    key={length.id}
                    onClick={() => setPromptLength(length.id)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      promptLength === length.id
                        ? 'border-[#00A5FF] bg-[#00A5FF] text-white'
                        : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500 bg-white dark:bg-gray-700'
                    }`}
                  >
                    <div className={`font-medium text-sm ${promptLength === length.id ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                      {length.name}
                    </div>
                    <div className={`text-xs ${promptLength === length.id ? 'text-white/80' : 'text-gray-500'}`}>
                      {length.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Number of Prompts */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Count</label>
                <span className="text-sm font-medium px-2 py-0.5 rounded-full bg-[#00A5FF]/10 dark:bg-[#00D2FF]/20 text-[#00A5FF] dark:text-[#00D2FF]">
                  {numberOfPrompts} prompts
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <span className="text-xs text-gray-500 dark:text-gray-400">1</span>
                <div className="relative flex-1 h-7">
                  <input
                    type="range"
                    className="absolute w-full h-1 top-3 bg-gray-300 dark:bg-gray-600 rounded-full appearance-none cursor-pointer"
                    min="1"
                    max="100"
                    value={numberOfPrompts}
                    onChange={(e) => setNumberOfPrompts(parseInt(e.target.value))}
                    style={{
                      background: `linear-gradient(to right,
                        rgb(0, 165, 255) 0%,
                        rgb(0, 165, 255) ${(numberOfPrompts - 1) * (100 / 99)}%,
                        rgb(209, 213, 219) ${(numberOfPrompts - 1) * (100 / 99)}%,
                        rgb(209, 213, 219) 100%)`,
                    }}
                  />
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">100</span>
              </div>
            </div>

            {/* Video Story Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Video Story/Concept
                <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">(Describe your vision)</span>
              </label>
              <textarea
                value={videoStory}
                onChange={(e) => setVideoStory(e.target.value)}
                placeholder="Describe your video story, concept, or specific scenes you want to create. For example: 'A peaceful morning in a coffee shop with soft sunlight streaming through windows, customers reading books, barista making coffee with steam rising..'"
                className="w-full px-3 py-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#00A5FF] focus:border-transparent text-sm transition-colors resize-none"
                rows={4}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                The AI will create variations based on your story description
              </p>
            </div>

            {/* Theme */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Theme (Optional)</label>
              <input
                type="text"
                value={customTheme}
                onChange={(e) => setCustomTheme(e.target.value)}
                placeholder="e.g., cyberpunk, nature, minimalist..."
                className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#00A5FF] focus:border-transparent text-sm transition-colors"
              />
            </div>

            {/* Creativity */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Creativity</label>
                <span className="text-sm font-medium px-2 py-0.5 rounded-full bg-[#00A5FF]/10 dark:bg-[#00D2FF]/20 text-[#00A5FF] dark:text-[#00D2FF]">
                  {Math.round(creativity * 100)}%
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <span className="text-xs text-gray-500 dark:text-gray-400">Low</span>
                <div className="relative flex-1 h-7">
                  <input
                    type="range"
                    className="absolute w-full h-1 top-3 bg-gray-300 dark:bg-gray-600 rounded-full appearance-none cursor-pointer"
                    min="0.1"
                    max="1.0"
                    step="0.1"
                    value={creativity}
                    onChange={(e) => setCreativity(parseFloat(e.target.value))}
                    style={{
                      background: `linear-gradient(to right,
                        rgb(0, 165, 255) 0%,
                        rgb(0, 165, 255) ${(creativity - 0.1) * (100 / 0.9)}%,
                        rgb(209, 213, 219) ${(creativity - 0.1) * (100 / 0.9)}%,
                        rgb(209, 213, 219) 100%)`,
                    }}
                  />
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">High</span>
              </div>
            </div>

            {/* Advanced Options */}
            <div>
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center space-x-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-[#00A5FF] dark:hover:text-[#00D2FF] transition-colors px-2 py-1 rounded hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <svg className={`w-4 h-4 transition-transform ${showAdvanced ? 'rotate-90' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
                <span>Advanced Options</span>
              </button>

              {showAdvanced && (
                <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-900/30 rounded-lg border border-gray-100 dark:border-gray-700 space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Video Elements to Include:</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { key: 'style', label: 'Visual Style', value: includeStyle, setter: setIncludeStyle },
                        { key: 'lighting', label: 'Cinematography', value: includeLighting, setter: setIncludeLighting },
                        { key: 'mood', label: 'Atmosphere', value: includeMood, setter: setIncludeMood },
                        { key: 'colors', label: 'Color Tone', value: includeColors, setter: setIncludeColors },
                        { key: 'movement', label: 'Movement', value: includeMovement, setter: setIncludeMovement },
                        { key: 'camera', label: 'Camera Work', value: includeCameraWork, setter: setIncludeCameraWork }
                      ].map(option => (
                        <label key={option.key} className="flex items-center space-x-2 p-2 bg-white dark:bg-gray-800 rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors border border-gray-200 dark:border-gray-600">
                          <input
                            type="checkbox"
                            checked={option.value}
                            onChange={(e) => option.setter(e.target.checked)}
                            className="w-4 h-4 text-[#00A5FF] rounded focus:ring-[#00A5FF]"
                          />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{option.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Must Include</label>
                    <input
                      type="text"
                      value={mustInclude}
                      onChange={(e) => setMustInclude(e.target.value)}
                      placeholder="e.g., smooth camera pans, dynamic movement, close-up shots"
                      className="w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-[#00A5FF] text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Exclude</label>
                    <input
                      type="text"
                      value={exclude}
                      onChange={(e) => setExclude(e.target.value)}
                      placeholder="e.g., static shots, shaky camera, abrupt cuts"
                      className="w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded focus:ring-2 focus:ring-[#00A5FF] text-sm"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Generate Button with Progress */}
        <div className="mb-4">
          <button
            onClick={generatePrompts}
            disabled={!apiKey.trim() || isGenerating}
            className="w-full py-3 rounded-lg bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] text-white font-medium shadow-sm hover:shadow-md transition-all transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 disabled:shadow-none flex items-center justify-center relative overflow-hidden"
          >
            {/* Progress Bar */}
            {isGenerating && (
              <div
                className="absolute inset-0 bg-gradient-to-r from-blue-600 via-blue-500 to-blue-600 transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              >
                {/* Shimmer effect */}
                <div className="absolute inset-0 overflow-hidden">
                  <div className="h-full w-24 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12 animate-wave"></div>
                </div>
              </div>
            )}

            {/* Button Content */}
            <div className="relative z-10 flex items-center space-x-2">
              {isGenerating ? (
                <>
                  <svg className="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  <div className="text-center">
                    <div className="text-sm font-medium">
                      {progress === 100 ? 'Finalizing...' : 
                       attempt > 1 ? `Collecting... (${collected}/${numberOfPrompts})` : 
                       'Generating...'}
                    </div>
                    <div className="text-xs opacity-90">
                      {Math.round(progress)}% • {attempt > 1 ? `Attempt ${attempt}` : 'Processing'}
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  <span>Generate {numberOfPrompts} Video Prompts</span>
                </>
              )}
            </div>
          </button>
        </div>

        {/* Results Section */}
        {prompts.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700 transition-all hover:shadow-md">
            <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-700">
              <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#00A5FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Generated Prompts
              </h3>
              <span className="text-xs text-[#00A5FF] dark:text-[#00D2FF] font-medium px-2 py-0.5 bg-[#00A5FF]/10 dark:bg-[#00D2FF]/20 rounded-full">
                {prompts.length} prompts
              </span>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-3 gap-2 mb-3">
                <button
                  onClick={copyPrompts}
                  className="py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm font-medium transition-colors flex items-center justify-center space-x-1"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  <span>Copy</span>
                </button>
                <button
                  onClick={downloadPrompts}
                  className="py-2 px-3 bg-green-600 hover:bg-green-700 text-white rounded text-sm font-medium transition-colors flex items-center justify-center space-x-1"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span>Save</span>
                </button>
                <button
                  onClick={() => setPrompts([])}
                  className="py-2 px-3 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600 rounded text-sm font-medium transition-colors"
                >
                  Clear
                </button>
              </div>

              <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden max-h-48 shadow-inner bg-gray-50 dark:bg-gray-900/30">
                <div className="overflow-y-auto max-h-48 custom-kling-scrollbar">
                  {prompts.map((prompt, index) => (
                    <div
                      key={index}
                      className="px-3 py-2 text-sm border-b border-gray-100 dark:border-gray-800 last:border-0 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors group"
                    >
                      <div className="flex items-start space-x-2">
                        <span className="font-medium text-[#00A5FF] dark:text-[#00D2FF] flex-shrink-0 text-xs mt-0.5">{index + 1}.</span>
                        <p className="text-gray-800 dark:text-gray-300 leading-relaxed flex-1">{prompt}</p>
                        <button
                          onClick={() => navigator.clipboard.writeText(prompt)}
                          className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-all flex-shrink-0 mt-0.5"
                          title="Copy prompt"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Matching Styles from FireflyDashboard */}
      <style jsx>{`
        @keyframes wave {
          0% {
            transform: translateX(-100%) skewX(12deg);
          }
          100% {
            transform: translateX(200%) skewX(12deg);
          }
        }
        
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        .animate-wave {
          animation: wave 2s ease-in-out infinite;
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-in-out;
        }
        
        .skew-x-12 {
          transform: skewX(12deg);
        }
        
        /* Range input styling */
        input[type=range]::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: white;
          box-shadow: 0 1px 3px rgba(0,0,0,0.2);
          cursor: pointer;
          transition: all 0.15s ease;
        }
        input[type=range]::-webkit-slider-thumb:hover {
          box-shadow: 0 2px 4px rgba(0,0,0,0.3);
          transform: scale(1.1);
        }
        input[type=range]::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: white;
          box-shadow: 0 1px 3px rgba(0,0,0,0.2);
          cursor: pointer;
          border: none;
          transition: all 0.15s ease;
        }
        
        /* Custom Kling Scrollbar - Matching KlingDashboard */
        .custom-kling-scrollbar {
          scrollbar-width: thin;
          scrollbar-color: #00A5FF #e0f7fa;
        }
        
        .dark .custom-kling-scrollbar {
          scrollbar-color: #00D2FF #374151;
        }
        
        .custom-kling-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        
        .custom-kling-scrollbar::-webkit-scrollbar-track {
          background: linear-gradient(180deg, #e0f7fa 0%, #b2ebf2 100%);
          border-radius: 10px;
          box-shadow: inset 0 0 3px rgba(0, 165, 255, 0.1);
        }
        
        .custom-kling-scrollbar::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #00A5FF 0%, #00D2FF 50%, #00C3A5 100%);
          border-radius: 10px;
          box-shadow:
            inset 0 1px 0px rgba(0, 210, 255, 0.5),
            inset 0 -1px 0px rgba(0, 165, 255, 0.5),
            0 0 4px rgba(0, 195, 165, 0.3);
          transition: all 0.3s ease;
        }
        
        .custom-kling-scrollbar::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #00D2FF 0%, #00C3A5 50%, #6EFF00 100%);
          box-shadow:
            inset 0 1px 0px rgba(0, 210, 255, 0.7),
            inset 0 -1px 0px rgba(0, 165, 255, 0.7),
            0 0 8px rgba(0, 195, 165, 0.5);
          transform: scale(1.05);
        }
        
        .dark .custom-kling-scrollbar::-webkit-scrollbar-track {
          background: linear-gradient(180deg, #374151 0%, #4b5563 100%);
          box-shadow: inset 0 0 3px rgba(0, 210, 255, 0.1);
        }
        
        .dark .custom-kling-scrollbar::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #00D2FF 0%, #00A5FF 50%, #00C3A5 100%);
          box-shadow:
            inset 0 1px 0px rgba(0, 210, 255, 0.4),
            inset 0 -1px 0px rgba(0, 165, 255, 0.6),
            0 0 4px rgba(0, 210, 255, 0.4);
        }
      `}</style>
    </div>
  )
}

export default PromptCreator