"use client"

import { useState, useEffect } from "react"
import { doc, getDoc } from "firebase/firestore"
import { db, EXTENSION_ID } from "../firebase"
import QuotaIndicator from "./QuotaIndicator"
import SubscriptionPlans from "./SubscriptionPlans"
import KlingDashboard from "./KlingDashboard"

const UserDashboard = ({ 
  user, 
  darkMode, 
  toggleDarkMode,
  subscriptionStatus, 
  showUserProfileModal,
  setShowUserProfileModal,
  showSubscriptionModal,
  setShowSubscriptionModal,
  activeTab,
  setActiveTab,
  onLogout
}) => {
  const [notifications, setNotifications] = useState([])
  const [allExtensionSubscriptions, setAllExtensionSubscriptions] = useState([])
  const [extensionNames, setExtensionNames] = useState({})

  // Extension name mapping (update this with your actual extension names)
  useEffect(() => {
    // This would ideally come from a config file or database
    setExtensionNames({
      AdobeFirefly: "Adobe Firefly Assistant",
      ExtensionB: "Extension B",
      ExtensionC: "Extension C",
      // Add your actual extension IDs and names here
    })
  }, [])

  // Fetch all user subscriptions on profile view
  useEffect(() => {
    if (showUserProfileModal && user?.uid) {
      fetchAllUserSubscriptions(user.uid)
    }
  }, [showUserProfileModal, user])

  // Function to fetch all user subscriptions
  const fetchAllUserSubscriptions = async (uid) => {
    try {
      const userRef = doc(db, "users", uid)
      const userDoc = await getDoc(userRef)

      if (!userDoc.exists()) {
        return
      }

      const userData = userDoc.data()

      if (userData.subscriptions) {
        // Convert the subscriptions object to an array with extension IDs
        const subscriptionsArray = Object.entries(userData.subscriptions).map(([extensionId, data]) => ({
          extensionId,
          extensionName: extensionNames[extensionId] || extensionId,
          status: data.status,
          plan: data.plan,
          isCurrentExtension: extensionId === EXTENSION_ID,
          // Add other relevant fields
          ...(data.remaining !== undefined && { remaining: data.remaining }),
          ...(data.quota !== undefined && { quota: data.quota }),
          ...(data.trialEnd && { trialEnd: data.trialEnd.toDate() }),
        }))

        setAllExtensionSubscriptions(subscriptionsArray)
      }
    } catch (error) {
      console.error("Error fetching user subscriptions:", error)
    }
  }


  // Get user display name (prefer display name, fall back to email)
  const displayName = user?.displayName || user?.email?.split("@")[0] || "User"

  // Format firestore date string
  const formatFirestoreDate = (dateString) => {
    if (!dateString) return "Unknown"

    try {
      // Attempt to parse the date string
      const date = new Date(dateString)
      if (isNaN(date.getTime())) {
        // If it's not a valid date object, try to extract date from string format
        const matches = dateString.match(/([A-Za-z]+ \d+, \d{4})/)
        return matches ? matches[1] : dateString
      }
      return date.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })
    } catch (e) {
      return dateString // Return the original string if parsing fails
    }
  }

  // Add notification
  const addNotification = (message, isError = false) => {
    const isDuplicate = notifications.some((n) => n.message === message)
    if (isDuplicate) return

    const id = Date.now()
    setNotifications((prev) => [...prev, { id, message, isError }])
    setTimeout(() => {
      setNotifications((prev) => prev.filter((notification) => notification.id !== id))
    }, 3000)
  }

  // Subscription status badge component
  const SubscriptionBadge = ({ status, plan, small = false, onClick }) => {
    if (!status) return null

    const statusConfig = {
      active: {
        bgClass: "bg-gradient-to-r from-[#6EFF00] to-[#C3FF00] border border-[#6EFF00]",
        textClass: "text-black",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        ),
        text: `Pro`,
      },
      active_canceling: {
        bgClass: "bg-gradient-to-r from-[#C3FF00] to-[#00C3A5] border border-[#C3FF00]",
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        ),
        text: `Pro (Canceling)`,
      },
      trial: {
        bgClass: "bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] border border-[#00A5FF]",
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        ),
        text: `Trial`,
      },
      expired: {
        bgClass: "bg-gradient-to-r from-yellow-400 to-yellow-500 border border-yellow-300",
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
            />
          </svg>
        ),
        text: "Expired",
      },
      payment_failed: {
        bgClass: "bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] border border-[#00A5FF]",
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
            />
          </svg>
        ),
        text: "Payment Failed",
      },
      default: {
        bgClass: "bg-gradient-to-r from-gray-400 to-gray-500 border border-gray-300",
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        ),
        text: "Unknown",
      },
    }

    const config = statusConfig[status] || statusConfig.default
    const sizeClasses = small ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-xs"

    return (
      <button
        onClick={onClick}
        className={`inline-flex items-center ${sizeClasses} rounded-full font-medium cursor-pointer transition-colors hover:opacity-90 shadow-sm backdrop-blur-sm ${config.bgClass} ${config.textClass}`}
      >
        {config.icon}
        {config.text}
      </button>
    )
  }

  // User Avatar Component
  const UserAvatar = ({ onClick, size = "medium" }) => {
    const sizeClasses = {
      small: "h-8 w-8",
      medium: "h-10 w-10",
      large: "h-16 w-16",
    }
    const sizeClass = sizeClasses[size] || sizeClasses.medium

    return (
      <button
        onClick={onClick}
        className={`rounded-full transition-transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-[#6EFF00] ${onClick ? "cursor-pointer" : ""}`}
      >
        {user.photoURL ? (
          <img
            src={user.photoURL || "/placeholder.svg"}
            alt="Profile"
            className={`${sizeClass} rounded-full border-2 border-[#6EFF00]/30 dark:border-[#6EFF00]/50 object-cover`}
          />
        ) : (
          <div
            className={`${sizeClass} rounded-full bg-gradient-to-r from-[#6EFF00] to-[#C3FF00] text-black flex items-center justify-center font-semibold`}
          >
            {user.email.charAt(0).toUpperCase()}
          </div>
        )}
      </button>
    )
  }

  // Multi-Extension Subscription List Component
  const MultiExtensionSubscriptionList = ({ subscriptions }) => {
    if (!subscriptions || subscriptions.length <= 1) {
      return null
    }

    return (
      <div className="mt-4 border-t border-gray-200 dark:border-gray-700 pt-4">
        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Your Extensions</h4>
        <div className="space-y-3">
          {subscriptions.map((sub) => (
            <div
              key={sub.extensionId}
              className={`p-3 rounded-lg border ${sub.isCurrentExtension ? "border-[#6EFF00]/30 dark:border-[#6EFF00]/50 bg-[#6EFF00]/5 dark:bg-[#6EFF00]/10" : "border-gray-200 dark:border-gray-700"}`}
            >
              <div className="flex justify-between items-center">
                <div>
                  <div className="font-medium text-sm text-gray-800 dark:text-white">
                    {sub.extensionName}
                    {sub.isCurrentExtension && (
                      <span className="ml-2 text-xs text-[#6EFF00] dark:text-[#6EFF00]">(Current)</span>
                    )}
                  </div>
                  <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    {sub.status === "trial" && sub.remaining !== undefined && (
                      <span>
                        {sub.remaining} of {sub.quota} quota remaining
                      </span>
                    )}
                    {sub.status === "trial" && sub.trialEnd && (
                      <span className="ml-2">• Expires {new Date(sub.trialEnd).toLocaleDateString()}</span>
                    )}
                    {(sub.status === "active" || sub.status === "active_canceling") && sub.plan && <span>{sub.plan} plan</span>}
                  </div>
                </div>
                <SubscriptionBadge
                  status={sub.status}
                  plan={sub.plan}
                  small={true}
                  onClick={() => setShowSubscriptionModal(true)}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // User Profile Modal
  const UserProfileModal = () => {
    if (!showUserProfileModal) return null

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
        <div
          id="userProfileModal"
          className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
        >
          <div className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] p-6 flex flex-col items-center text-white relative">
            <button
              onClick={() => setShowUserProfileModal(false)}
              className="absolute top-3 right-3 text-white hover:text-gray-200 rounded-full p-1 hover:bg-[#00A5FF]/50 transition-colors"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <UserAvatar size="large" />
            <h2 className="text-xl font-bold mt-3">{user.displayName || "User"}</h2>
            <p className="text-sm text-white/90">{user.email}</p>
          </div>

          <div className="p-6">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Account Information</h3>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">User ID:</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white truncate max-w-[180px]">
                  {user.uid}
                </span>
              </div>

              {user.providerData && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Login Method:</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {user.providerData[0]?.providerId === "google.com" ? "Google" : "Email/Password"}
                  </span>
                </div>
              )}

              {user.metadata && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Account Created:</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {formatFirestoreDate(user.metadata.creationTime)}
                  </span>
                </div>
              )}

              {subscriptionStatus && (
                <>
                  <div className="border-t border-gray-200 dark:border-gray-700 my-3"></div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Subscription:</span>
                    <span className="text-sm font-medium">
                      <SubscriptionBadge
                        status={subscriptionStatus.status}
                        plan={subscriptionStatus.plan}
                        onClick={() => setShowSubscriptionModal(true)}
                      />
                    </span>
                  </div>

                  {subscriptionStatus.status === "trial" && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Usage:</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {subscriptionStatus.remaining} / {subscriptionStatus.quota} remaining
                      </span>
                    </div>
                  )}

                  {(subscriptionStatus.status === "active" || subscriptionStatus.status === "active_canceling") && subscriptionStatus.plan && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Plan:</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {subscriptionStatus.plan}
                      </span>
                    </div>
                  )}
                </>
              )}

              {/* Display all extension subscriptions */}
              {allExtensionSubscriptions.length > 1 && (
                <MultiExtensionSubscriptionList subscriptions={allExtensionSubscriptions} />
              )}

              {/* Dark Mode Toggle */}
              <div className="border-t border-gray-200 dark:border-gray-700 my-3"></div>

              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Theme:</span>
                <button
                  onClick={toggleDarkMode}
                  className="p-1.5 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  {darkMode ? (
                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-1.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
                        />
                      </svg>
                      <span className="text-xs">Light Mode</span>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4 mr-1.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
                        />
                      </svg>
                      <span className="text-xs">Dark Mode</span>
                    </div>
                  )}
                </button>
              </div>
            </div>

            <div className="mt-6">
              <button
                onClick={onLogout}
                className="w-full py-2.5 bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] text-white rounded-xl font-medium text-sm hover:opacity-90 transition-opacity flex items-center justify-center"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 mr-2"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                  />
                </svg>
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Subscription Modal Component
  const SubscriptionModal = () => {
    if (!showSubscriptionModal) return null

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-auto">
          <div className="flex justify-between items-center p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">Subscription Plans</h2>
            <button
              onClick={() => setShowSubscriptionModal(false)}
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 rounded-full p-1 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="p-6">
            <SubscriptionPlans user={user} subscriptionStatus={subscriptionStatus} />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col bg-gray-50 dark:bg-gray-900 w-full">
      {/* Main Content Area */}
      <div className="flex-1">
        {/* Quota Indicator for trial users - only show container if quota should be visible */}
        {subscriptionStatus && subscriptionStatus.status === "trial" && (() => {
          const used = subscriptionStatus.used || 0;
          const quota = subscriptionStatus.quota || 100;
          const remaining = subscriptionStatus.remaining || 0;
          const percentageRemaining = 100 - Math.min(100, Math.round((used / quota) * 100));
          const shouldShowQuotaDetails = percentageRemaining < 20 || remaining <= 0;
          
          return shouldShowQuotaDetails ? (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-red-100 dark:border-red-900/30 p-4 m-4">
              <QuotaIndicator
                used={used}
                quota={quota}
                remaining={remaining}
                theme="red"
                expiresAt={subscriptionStatus.trialEnd}
              />
            </div>
          ) : null;
        })()}

        {/* Prompt to upgrade for expired users - keep padding */}
        {subscriptionStatus && (subscriptionStatus.status === "expired" || subscriptionStatus.status === "payment_failed") && (
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-yellow-200 dark:border-yellow-900/30 p-4 m-4">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-yellow-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-base font-medium text-gray-900 dark:text-white">
                  {subscriptionStatus.status === "payment_failed" ? "Payment Failed" : "Your free quota is depleted"}
                </h3>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                  {subscriptionStatus.status === "payment_failed"
                    ? "Your payment could not be processed. Please update your payment method to continue using the extension."
                    : `You've used all ${subscriptionStatus.quota} units from your free quota. Upgrade to Pro to continue using the extension.`
                  }
                </p>
                <button
                  onClick={() => setShowSubscriptionModal(true)}
                  className="mt-3 px-4 py-2 bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] text-white rounded-lg text-sm font-medium hover:opacity-90 transition-opacity flex items-center"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 mr-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  {subscriptionStatus.status === "payment_failed" ? "Update Payment Method" : "View Upgrade Options"}
                </button>
              </div>
            </div>
          </div>
        )}


        {/* Main Kling Dashboard Component - full width without padding */}
        <KlingDashboard
          user={user}
          showSubscriptionModal={showSubscriptionModal}
          setShowSubscriptionModal={setShowSubscriptionModal}
        />
      </div>

      {/* User Profile Modal */}
      <UserProfileModal />

      {/* Subscription Modal */}
      <SubscriptionModal />

      {/* Notification area */}
      <div className="fixed bottom-4 right-4 space-y-2 z-50">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className={`flex items-center px-4 py-2.5 rounded-xl shadow-lg backdrop-filter backdrop-blur-md text-white text-xs max-w-xs transform transition-all duration-300 ease-in-out opacity-100
                      ${notification.isError ? "bg-gradient-to-r from-red-700 to-red-600" : "bg-gradient-to-r from-green-600 to-green-500"}`}
          >
            {notification.isError ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 mr-2 flex-shrink-0"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 mr-2 flex-shrink-0"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            )}
            {notification.message}
          </div>
        ))}
      </div>
    </div>
  )
}

export default UserDashboard

