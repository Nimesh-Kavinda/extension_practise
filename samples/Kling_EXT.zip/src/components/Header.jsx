import React from "react";
import logoImage from "../assets/logo.png";

const Header = ({
  user,
  onLogout,
  darkMode,
  toggleDarkMode,
  subscriptionStatus,
  activeTab,
  setActiveTab,
  showUserProfileModal,
  setShowUserProfileModal,
  showSubscriptionModal,
  setShowSubscriptionModal
}) => {
  // Format subscription status badge
  const SubscriptionBadge = ({ status, small = false, onClick }) => {
    if (!status) return null;

    const statusConfig = {
      active: {
        bgClass: `bg-gradient-to-r ${darkMode ? 'from-[#6EFF00] to-[#C3FF00]' : 'from-[#6EFF00] to-[#C3FF00]'} border ${darkMode ? 'border-[#6EFF00]' : 'border-[#6EFF00]'}`,
        textClass: "text-black",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-black`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        ),
        text: `Pro`,
      },
      active_canceling: {
        bgClass: `bg-gradient-to-r ${darkMode ? 'from-[#C3FF00] to-[#00C3A5]' : 'from-[#C3FF00] to-[#00C3A5]'} border ${darkMode ? 'border-[#C3FF00]' : 'border-[#C3FF00]'}`,
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        ),
        text: `Pro (Canceling)`,
      },
      trial: {
        bgClass: `bg-gradient-to-r ${darkMode ? 'from-[#00A5FF] to-[#00D2FF]' : 'from-[#00A5FF] to-[#00D2FF]'} border ${darkMode ? 'border-[#00A5FF]' : 'border-[#00A5FF]'}`,
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        ),
        text: `Trial`,
      },
      expired: {
        bgClass: `bg-gradient-to-r from-gray-500 to-gray-600 border ${darkMode ? 'border-gray-400' : 'border-gray-400'}`,
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
            />
          </svg>
        ),
        text: "Expired",
      },
      payment_failed: {
        bgClass: `bg-gradient-to-r ${darkMode ? 'from-[#00A5FF] to-[#00D2FF]' : 'from-[#00A5FF] to-[#00D2FF]'} border ${darkMode ? 'border-[#00A5FF]' : 'border-[#00A5FF]'}`,
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
            />
          </svg>
        ),
        text: "Payment Failed",
      },
      default: {
        bgClass: `bg-gradient-to-r from-gray-400 to-gray-500 border ${darkMode ? 'border-gray-300' : 'border-gray-300'}`,
        textClass: "text-white",
        icon: (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`${small ? "h-3 w-3" : "h-4 w-4"} mr-1.5 text-white`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        ),
        text: "Unknown",
      },
    };

    const config = statusConfig[status] || statusConfig.default;
    const sizeClasses = small ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-xs";

    return (
      <button
        onClick={onClick}
        className={`inline-flex items-center ${sizeClasses} rounded-full font-medium cursor-pointer transition-all hover:opacity-90 hover:shadow-md hover:scale-105 shadow-sm backdrop-blur-sm ${config.bgClass} ${config.textClass}`}
      >
        {config.icon}
        {config.text}
      </button>
    );
  };
  
  // User avatar component
  const UserAvatar = ({ onClick, size = "medium", subscriptionStatus = null }) => {
    const sizeClasses = {
      small: "h-8 w-8",
      medium: "h-10 w-10",
      large: "h-12 w-12",
    };
    
    const crownSizeClasses = {
      small: "h-4 w-4 -top-1 -right-1",
      medium: "h-5 w-5 -top-1.5 -right-1.5",
      large: "h-6 w-6 -top-2 -right-2",
    };
    
    // Get user initials for avatar placeholder
    const initials = user?.displayName
      ? user.displayName.split(" ").map((n) => n[0]).join("").toUpperCase().substring(0, 2)
      : user?.email
      ? user.email[0].toUpperCase()
      : "U";
      
    const photoURL = user?.photoURL;
    const isPro = subscriptionStatus === 'active';
    
    return (
      <button
        onClick={onClick}
        className={`relative ${sizeClasses[size]} rounded-full bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] text-white flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-[#00A5FF] focus:ring-offset-2 transition-all hover:shadow-md hover:scale-110`}
      >
        {photoURL ? (
          <img src={photoURL} alt={user?.displayName || "User"} className="h-full w-full object-cover rounded-full" />
        ) : (
          <span className="text-sm font-medium">{initials}</span>
        )}
        
        {/* Crown overlay for Pro users */}
        {isPro && (
          <div className={`absolute ${crownSizeClasses[size]} bg-gradient-to-r from-[#6EFF00] to-[#C3FF00] rounded-full p-0.5 shadow-lg ring-2 ${darkMode ? 'ring-gray-800' : 'ring-white'} flex items-center justify-center z-50`}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-full w-full text-black"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z"/>
            </svg>
          </div>
        )}
      </button>
    );
  };

  return (
    <header className={`
      ${darkMode
        ? 'bg-gray-800/90 text-white'
        : 'bg-white/90 text-gray-800'}
      backdrop-filter backdrop-blur-md shadow-md
      transition-all duration-300 border-b
      ${darkMode ? 'border-gray-700' : 'border-gray-100'}
    `}>
      <div className="max-w-screen-2xl mx-auto">
        {/* Main header area with logo and controls */}
        <div className="px-4 py-3">
          <div className="flex justify-between items-center">
            {/* Logo (free form without container) */}
            <div className="flex-shrink-0 flex items-center">
              <img
                src={logoImage}
                alt="KlingGen Logo"
                className="h-10 transform transition-transform hover:scale-110 mr-3"
              />
              {/* Desktop: Single line text */}
              <h1 className="text-lg font-semibold hidden md:block">
                <span className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] bg-clip-text text-transparent font-bold">KlingGen</span>
                <span>: Kling AI Video Generator</span>
              </h1>
              {/* Mobile/Narrow: Stacked text */}
              <div className="flex flex-col leading-tight md:hidden">
                <span className="text-sm font-bold bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] bg-clip-text text-transparent">KlingGen</span>
                <span className="text-xs font-medium opacity-90">Video Generator</span>
              </div>
            </div>
            
            {/* Right side user controls */}
            {user ? (
              <div className="flex items-center space-x-3">
                {/* Subscription badge - only show for non-active pro users */}
                {subscriptionStatus && subscriptionStatus.status !== 'active' && (
                  <SubscriptionBadge
                    status={subscriptionStatus.status}
                    small={true}
                    onClick={() => setShowSubscriptionModal && setShowSubscriptionModal(true)}
                  />
                )}
                
                {/* User profile */}
                <div className="flex items-center cursor-pointer"
                     onClick={() => setShowUserProfileModal && setShowUserProfileModal(true)}>
                  <UserAvatar
                    size="small"
                    subscriptionStatus={subscriptionStatus?.status}
                  />
                  <div className="ml-2 hidden md:block">
                    <div className={`text-sm font-medium ${darkMode ? 'text-white' : 'text-gray-800'} truncate max-w-[120px]`}>
                      {user.displayName || user.email?.split("@")[0] || "User"}
                    </div>
                  </div>
                </div>
                
                {/* Dark/Light mode toggle button */}
                <button
                  onClick={toggleDarkMode}
                  className={`p-2 rounded-full ${
                    darkMode
                      ? 'text-gray-300 hover:text-white hover:bg-gray-700/50'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
                  } transition-colors`}
                  aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
                  title={darkMode ? "Switch to light mode" : "Switch to dark mode"}
                >
                  {darkMode ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                    </svg>
                  )}
                </button>
              </div>
            ) : (
              // Show dark mode toggle for users who are not logged in
              <button
                onClick={toggleDarkMode}
                className={`p-2 rounded-full ${
                  darkMode
                    ? 'text-gray-300 hover:text-white hover:bg-gray-700/50'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
                } transition-colors`}
                aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
                title={darkMode ? "Switch to light mode" : "Switch to dark mode"}
              >
                {darkMode ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                  </svg>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;