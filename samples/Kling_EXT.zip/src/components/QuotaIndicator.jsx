import React from 'react'

const QuotaIndicator = ({ used, quota, remaining, theme = "blue", expiresAt }) => {
  // Calculate percentage used
  const percentageUsed = Math.min(100, Math.round((used / quota) * 100))
  const percentageRemaining = 100 - percentageUsed
  
  // Only show quota indicator when quota is low (< 20% remaining) or expired
  const shouldShowQuotaDetails = percentageRemaining < 20 || remaining <= 0
  
  // Format expiration date
  const formatExpirationDate = (dateValue) => {
    if (!dateValue) return null
    
    try {
      let date
      if (dateValue instanceof Date) {
        date = dateValue
      } else if (typeof dateValue === 'string') {
        date = new Date(dateValue)
      } else if (dateValue.toDate && typeof dateValue.toDate === 'function') {
        // Firestore timestamp
        date = dateValue.toDate()
      } else {
        return null
      }
      
      if (isNaN(date.getTime())) return null
      
      return date.toLocaleDateString(undefined, {
        year: "numeric",
        month: "short",
        day: "numeric"
      })
    } catch (e) {
      return null
    }
  }
  
  const formattedExpiresAt = formatExpirationDate(expiresAt)
  
  // Determine colors based on theme and percentage
  const getThemeColors = () => {
    if (theme === "blue") {
      return {
        barColor: percentageRemaining < 20
          ? "bg-[#00A5FF]"
          : percentageRemaining < 50
            ? "bg-gradient-to-r from-[#00D2FF] to-[#00A5FF]"
            : "bg-gradient-to-r from-[#6EFF00] to-[#C3FF00]",
        textColor: percentageRemaining < 20 ? "text-[#00A5FF]" : "text-[#6EFF00]"
      }
    }
    
    // Alternative theme
    return {
      barColor: percentageRemaining < 20
        ? "bg-[#00C3A5]"
        : percentageRemaining < 50
          ? "bg-gradient-to-r from-[#00D2FF] to-[#00C3A5]"
          : "bg-gradient-to-r from-[#6EFF00] to-[#C3FF00]",
      textColor: percentageRemaining < 20 ? "text-[#00C3A5]" : "text-[#6EFF00]"
    }
  }
  
  const { barColor, textColor } = getThemeColors()
  
  const getLimitWarning = () => {
    if (percentageRemaining < 10) {
      return (
        <div className="flex items-center mt-2 text-[#C3FF00] dark:text-[#C3FF00]">
          <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <span className="text-xs">Your free quota is almost depleted!</span>
        </div>
      )
    }
    return null
  }

  // Don't render anything if quota details should be hidden
  if (!shouldShowQuotaDetails) {
    return null
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-gray-900 dark:text-white">Free Quota</h3>
        <span className={`text-xs font-medium ${textColor}`}>
          {remaining} remaining
        </span>
      </div>
      
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 overflow-hidden">
        <div
          className={`${barColor} h-2.5 rounded-full transition-all duration-500 ease-out`}
          style={{ width: `${percentageUsed}%` }}
        ></div>
      </div>
      
      <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
        <span>{used} used</span>
        <span>{quota} total</span>
      </div>
      
      {/* Expiration date display */}
      {formattedExpiresAt && (
        <div className="flex items-center justify-center mt-2 text-xs text-gray-600 dark:text-gray-400">
          <svg xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-3.5 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 002 2z" />
          </svg>
          <span>Trial expires: {formattedExpiresAt}</span>
        </div>
      )}
      
      {getLimitWarning()}
    </div>
  )
}

export default QuotaIndicator