"use client"

import { useState, useEffect, useRef } from "react"
import { updateQuotaUsage, checkFirestoreSubscription } from "../utils/subscription"
import PromptCreator from "./PromptCreator"

// Declare chrome globally to avoid undefined errors.  This is necessary because the linter doesn't see it as a global
// even though it is provided by the browser extension environment.
/* global chrome */

const KlingDashboard = ({ user, showSubscriptionModal, setShowSubscriptionModal }) => {
  // State variables
  const [prompts, setPrompts] = useState([])
  const [fileName, setFileName] = useState("No file selected")
  const [isProcessing, setIsProcessing] = useState(false)
  const [klingConnected, setKlingConnected] = useState(false)
  const [status, setStatus] = useState({ text: "", type: "" })
  const [progressStatus, setProgressStatus] = useState("Not started")
  const [currentPrompt, setCurrentPrompt] = useState("-")
  const [processedCount, setProcessedCount] = useState({ processed: 0, total: 0 })
  const [showPromptCreator, setShowPromptCreator] = useState(false)
  
  // Generation mode state
  const [generationMode, setGenerationMode] = useState("text") // "text" or "image"
  const [baseImages, setBaseImages] = useState([]) // For image to video mode - multiple images
  
  // Edit state for individual prompts
  const [editingPromptIndex, setEditingPromptIndex] = useState(null)
  const [editPromptText, setEditPromptText] = useState("")
  
  // Separate edit state for Image Processing Order section
  const [editingImagePromptIndex, setEditingImagePromptIndex] = useState(null)
  const [editImagePromptText, setEditImagePromptText] = useState("")

  // Error modal state
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorModalData, setErrorModalData] = useState({ title: "", message: "" })

  // Settings state (with default values)
  const [settings, setSettings] = useState({
    autoDownload: true,
    delayBetweenPrompts: 5,
    generationMode: "text",
  })

  // Refs
  const fileInputRef = useRef(null)
  const promptListRef = useRef(null)

  // Load settings from storage on component mount
  useEffect(() => {
    chrome.storage.local.get(["autoDownload", "delayBetweenPrompts", "generationMode"], (data) => {
      setSettings((prevSettings) => ({
        ...prevSettings,
        autoDownload: data.autoDownload !== undefined ? data.autoDownload : prevSettings.autoDownload,
        delayBetweenPrompts:
          data.delayBetweenPrompts !== undefined ? data.delayBetweenPrompts : prevSettings.delayBetweenPrompts,
        generationMode: data.generationMode !== undefined ? data.generationMode : prevSettings.generationMode,
      }))
      
      // Update local generation mode state
      if (data.generationMode) {
        setGenerationMode(data.generationMode)
      }
    })
  }, [])

  // Check if we're on the Kling page and sync mode with URL
  const [isOnKlingPage, setIsOnKlingPage] = useState(false)

  useEffect(() => {
    const checkIfOnKlingPage = () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const wasOnKlingPage = isOnKlingPage
        const currentTab = tabs[0]
        const nowOnKlingPage = currentTab && currentTab.url.includes("klingai.com")

        setIsOnKlingPage(nowOnKlingPage)

        if (nowOnKlingPage) {
          // Sync mode based on current URL
          const currentUrl = currentTab.url
          if (currentUrl.includes('/text-to-video')) {
            if (generationMode !== "text") {
              console.log("🔄 URL detected text-to-video, syncing sidepanel mode")
              setGenerationMode("text")
              handleSettingChange("generationMode", "text")
            }
          } else if (currentUrl.includes('/image-to-video')) {
            if (generationMode !== "image") {
              console.log("🔄 URL detected image-to-video, syncing sidepanel mode")
              setGenerationMode("image")
              handleSettingChange("generationMode", "image")
            }
          }

          if (!wasOnKlingPage) {
            checkKlingStatus()
          }
        }
      })
    }

    // Check immediately and then every 2 seconds
    checkIfOnKlingPage()
    const interval = setInterval(checkIfOnKlingPage, 2000)

    return () => clearInterval(interval)
  }, [isOnKlingPage, generationMode])

  // Listen for messages from content script
  useEffect(() => {
    const messageListener = (message) => {
      if (message.action === "updateProgress") {
        setCurrentPrompt(message.currentPrompt || "-");

        // Track the previously processed count to only update quota when new items are processed
        setProcessedCount((prevCounts) => {
          // If more items have been processed since last update and user is logged in
          if (message.processed > prevCounts.processed && user?.uid) {
            // First check if this is a paid user by getting the latest quota status
            chrome.storage.local.get('quotaStatus', async (data) => {
              const quotaStatus = data.quotaStatus || { isPaid: false };
              
              // Skip quota updates for paid users - they have unlimited usage
              if (quotaStatus.isPaid) {
                console.log("Paid user: Skipping quota update");
                return;
              }
              
              // Only update quota for trial users
              console.log("Trial user: Updating quota usage");
              
              // Calculate how many new items were processed in this update
              const newlyProcessed = message.processed - prevCounts.processed;

              // Update quota usage in Firestore
              try {
                const newSubscriptionData = await updateQuotaUsage(user.uid, newlyProcessed);
                
                // If we got updated subscription data, we can use it to update the UI
                if (newSubscriptionData) {
                  console.log("Quota updated, remaining:", newSubscriptionData.remaining);

                  // Store quota status in chrome.storage for other components to access
                  const updatedQuotaStatus = {
                    canContinue: newSubscriptionData.status !== "expired" && newSubscriptionData.status !== "payment_failed" && newSubscriptionData.remaining > 0,
                    isPaid: false,
                    remaining: newSubscriptionData.remaining,
                    status: newSubscriptionData.status,
                  };

                  chrome.storage.local.set({ quotaStatus: updatedQuotaStatus });

                  // Also inform background script about the update
                  chrome.runtime.sendMessage({
                    action: "updateQuotaStatus",
                    quotaStatus: updatedQuotaStatus,
                  });

                  // If quota is depleted, stop processing
                  if (newSubscriptionData.status === "expired" || newSubscriptionData.status === "payment_failed" || newSubscriptionData.remaining <= 0) {
                    stopProcessing();
                    showStatus("Your free quota has been depleted. Please upgrade to continue.", "error");
                  }
                }
              } catch (error) {
                console.error("Error updating quota:", error);
              }
            });
          }

          return {
            processed: message.processed,
            total: message.total,
          };
        });

        // Update the prompt list to show processed items
        updatePromptListWithProgress(message.processed);

        if (message.processed === message.total) {
          showStatus("All prompts processed successfully!", "success");
          resetUI();
        }
      } else if (message.action === "error") {
        showStatus(message.error, "error");
        resetUI();
      } else if (message.action === "updateStatus") {
        showStatus(message.status, "info");
      } else if (message.action === "klingStatus") {
        // Update UI based on Kling connection status
        updateKlingUI(message.connected);
      }
    };

    // Add listener for messages
    chrome.runtime.onMessage.addListener(messageListener);

    // Clean up
    return () => {
      chrome.runtime.onMessage.removeListener(messageListener);
    };
  }, [prompts, user]);

  // Check Kling status
  const checkKlingStatus = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && (tabs[0].url.includes("app.klingai.com/global/text-to-video") || tabs[0].url.includes("app.klingai.com/global/image-to-video"))) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "checkKlingStatus" }).catch((err) => {
          console.log("Could not check Kling status:", err)
        })
      }
    })
  }

  // Initial check for Kling status
  useEffect(() => {
    if (isOnKlingPage) {
      setTimeout(checkKlingStatus, 1000)
    }
  }, [isOnKlingPage])

  // Update prompt list to show processing progress
  const updatePromptListWithProgress = (processedIndex) => {
    // For text mode, update prompts as before
    if (generationMode === "text") {
      setPrompts((currentPrompts) =>
        currentPrompts.map((prompt, index) => ({
          ...prompt,
          status: index < processedIndex ? "processed" : index === processedIndex ? "current" : "pending",
        })),
      )
    }
    // For image mode, we don't need to update prompts since we show the image list
    // The image processing status is handled in the image-to-prompt mapping section
  }

  // Update UI based on Kling connection status
  const updateKlingUI = (isConnected) => {
    setKlingConnected(isConnected);

    if (isConnected) {
      showStatus("Connected to Kling platform.", "info");
    } else {
      showStatus("Not connected to Kling platform.", "info");
    }
  }

  // Reset UI state
  const resetUI = () => {
    setIsProcessing(false)
    setProgressStatus("Not running")
  }

  // Show error modal for error messages, inline status for others
  const showStatus = (message, type) => {
    if (type === "error") {
      // Show error messages as modal popup
      const title = getErrorTitle(message)
      setErrorModalData({ title, message })
      setShowErrorModal(true)
    } else {
      // Show success/info messages inline as before
      setStatus({ text: message, type })
      // Auto-hide after 5 seconds for non-error messages
      setTimeout(() => {
        setStatus((prevStatus) => (prevStatus.text === message ? { text: "", type: "" } : prevStatus))
      }, 5000)
    }
  }

  // Get appropriate error title based on error message content
  const getErrorTitle = (message) => {
    if (message.includes("quota") || message.includes("credits")) {
      return "Quota Limit Reached"
    }
    if (message.includes("expired") || message.includes("subscription")) {
      return "Subscription Issue"
    }
    if (message.includes("payment")) {
      return "Payment Problem"
    }
    if (message.includes("authentication") || message.includes("sign in")) {
      return "Authentication Required"
    }
    if (message.includes("connection") || message.includes("network")) {
      return "Connection Error"
    }
    if (message.includes("file") || message.includes("upload")) {
      return "File Error"
    }
    return "Error"
  }

  // Close error modal
  const closeErrorModal = () => {
    setShowErrorModal(false)
    setErrorModalData({ title: "", message: "" })
  }

  // Handle file import
  const handleFileImport = (event) => {
    const file = event.target.files[0]
    if (file) {
      setFileName(file.name)

      const reader = new FileReader()
      reader.onload = (e) => {
        processFileContent(e.target.result)
      }
      reader.onerror = () => {
        showStatus("Error reading file!", "error")
      }
      reader.readAsText(file)
    } else {
      setFileName("No file selected")
      setPrompts([])
      showStatus("No file selected", "info")
    }
  }

  // Process file content
  const processFileContent = (content) => {
    const processedPrompts = content
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 0)
      .map((text, index) => ({
        id: index,
        text,
        status: "pending", // 'pending', 'current', or 'processed'
      }))

    setPrompts(processedPrompts)

    // Show status message
    showStatus(`Loaded ${processedPrompts.length} prompts from file`, "success")
  }

  // Save settings
  const saveSettings = (newSettings) => {
    // Update local state
    setSettings(newSettings)

    // Save to Chrome storage
    chrome.storage.local.set({
      autoDownload: newSettings.autoDownload,
      delayBetweenPrompts: newSettings.delayBetweenPrompts,
      generationMode: newSettings.generationMode,
    })
  }

  // Handle settings change
  const handleSettingChange = (settingName, value) => {
    const newSettings = {
      ...settings,
      [settingName]: value,
    }

    saveSettings(newSettings)
  }

  // Handle multiple image uploads for Image to Video mode
  const handleImageUpload = (event) => {
    const files = Array.from(event.target.files)
    const imageFiles = files.filter(file => file.type.startsWith('image/'))
    
    if (imageFiles.length === 0) {
      showStatus("Please select valid image files.", "error")
      return
    }
    
    const imagePromises = imageFiles.map(file => {
      return new Promise((resolve) => {
        const reader = new FileReader()
        reader.onload = (e) => {
          resolve({
            name: file.name,
            data: e.target.result,
            file: file
          })
        }
        reader.readAsDataURL(file)
      })
    })
    
    Promise.all(imagePromises).then(images => {
      setBaseImages(images)
      showStatus(`${images.length} image(s) uploaded successfully!`, "success")
    })
  }

  // Handle generation mode change
  const handleGenerationModeChange = (mode) => {
    setGenerationMode(mode)
    handleSettingChange("generationMode", mode)
    
    // Reset base images when switching to text mode
    if (mode === "text") {
      setBaseImages([])
    }
    
    // Navigate to appropriate URL based on mode
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs[0]
      if (currentTab && currentTab.url.includes("klingai.com")) {
        const targetUrl = mode === "text"
          ? "https://app.klingai.com/global/text-to-video"
          : "https://app.klingai.com/global/image-to-video"
        
        // Only navigate if we're not already on the correct URL
        if (!currentTab.url.includes(mode === "text" ? "/text-to-video" : "/image-to-video")) {
          console.log(`🔄 Sidepanel mode changed to ${mode}, navigating to: ${targetUrl}`)
          chrome.tabs.update(currentTab.id, { url: targetUrl })
        }
      }
    })
  }

  // Handle editing individual prompts
  const startEditingPrompt = (index, currentText) => {
    setEditingPromptIndex(index)
    setEditPromptText(currentText)
  }

  const savePromptEdit = (index) => {
    setPrompts((currentPrompts) => {
      // If we're editing beyond the current prompts array length, extend it
      if (index >= currentPrompts.length) {
        const newPrompts = [...currentPrompts]
        // Fill any gaps with empty prompts
        while (newPrompts.length <= index) {
          newPrompts.push({
            id: newPrompts.length,
            text: newPrompts.length === index ? editPromptText : "",
            status: "pending"
          })
        }
        return newPrompts
      } else {
        // Update existing prompt
        return currentPrompts.map((prompt, i) =>
          i === index ? { ...prompt, text: editPromptText } : prompt
        )
      }
    })
    setEditingPromptIndex(null)
    setEditPromptText("")
    showStatus("Prompt updated successfully!", "success")
  }

  const cancelPromptEdit = () => {
    setEditingPromptIndex(null)
    setEditPromptText("")
  }

  // Handle editing individual prompts in Image Processing Order section
  const startEditingImagePrompt = (index, currentText) => {
    setEditingImagePromptIndex(index)
    setEditImagePromptText(currentText)
  }

  const saveImagePromptEdit = (index) => {
    setPrompts((currentPrompts) => {
      // If we're editing beyond the current prompts array length, extend it
      if (index >= currentPrompts.length) {
        const newPrompts = [...currentPrompts]
        // Fill any gaps with empty prompts
        while (newPrompts.length <= index) {
          newPrompts.push({
            id: newPrompts.length,
            text: newPrompts.length === index ? editImagePromptText : "",
            status: "pending"
          })
        }
        return newPrompts
      } else {
        // Update existing prompt
        return currentPrompts.map((prompt, i) =>
          i === index ? { ...prompt, text: editImagePromptText } : prompt
        )
      }
    })
    setEditingImagePromptIndex(null)
    setEditImagePromptText("")
    showStatus("Prompt updated successfully!", "success")
  }

  const cancelImagePromptEdit = () => {
    setEditingImagePromptIndex(null)
    setEditImagePromptText("")
  }

  // Start processing prompts
  const startProcessing = async () => {
    // For text mode, prompts are required
    if (generationMode === "text" && prompts.length === 0) {
      showStatus("Please select a file with at least one prompt!", "error")
      return
    }

    // For image mode, images are required, prompts are optional
    if (generationMode === "image" && baseImages.length === 0) {
      showStatus("Please upload at least one image for Image to Video mode!", "error")
      return
    }

    // Check if user is logged in
    if (!user || !user.uid) {
      showStatus("Please sign in to use this feature.", "error")
      return
    }

    // For image mode, create prompts from images if no text prompts provided
    let processItems = []
    if (generationMode === "image") {
      if (prompts.length === 0) {
        // No text prompts, just use images with empty prompts
        processItems = baseImages.map((img, index) => ({
          text: "", // Empty prompt
          image: img,
          id: index,
          status: "pending"
        }))
      } else {
        // Combine images with prompts (repeat prompts if fewer than images)
        processItems = baseImages.map((img, index) => ({
          text: prompts[index % prompts.length]?.text || "", // Cycle through prompts
          image: img,
          id: index,
          status: "pending"
        }))
      }
    } else {
      // Text mode - use prompts as before
      processItems = prompts
    }

    // Check subscription status and remaining quota
    try {
      // Always get the latest subscription data from Firestore
      const subscriptionData = await checkFirestoreSubscription(user.uid)
      console.log("Current subscription status:", subscriptionData.status, "Plan:", subscriptionData.plan)

      // Different handling based on subscription type
      if (subscriptionData.status === "active" || subscriptionData.status === "active_canceling") {
        // PAID USER: No quota restrictions for paid users with active subscriptions
        console.log("Paid subscriber: Bypassing quota check")
        
        // Just set a quotaStatus that always allows processing
        const quotaStatus = {
          canContinue: true, // Always allow paid users to continue
          isPaid: true,      // Flag to identify paid users
          status: "active",
          plan: subscriptionData.plan
        }
        
        chrome.storage.local.set({ quotaStatus })
        
        // Inform background script
        chrome.runtime.sendMessage({
          action: "updateQuotaStatus",
          quotaStatus,
        })
      } 
      else if (subscriptionData.status === "trial") {
        // TRIAL USER: Check if they have enough quota
        console.log("Trial user: Checking quota", subscriptionData.remaining, "remaining")
        
        const hasEnoughQuota = subscriptionData.remaining >= processItems.length
        
        // Store quota status
        const quotaStatus = {
          canContinue: hasEnoughQuota,
          isPaid: false,
          remaining: subscriptionData.remaining,
          status: "trial",
          requiredQuota: processItems.length,
        }
        
        chrome.storage.local.set({ quotaStatus })
        
        // Inform background script
        chrome.runtime.sendMessage({
          action: "updateQuotaStatus",
          quotaStatus,
        })
        
        // If not enough quota, show error and stop
        if (!hasEnoughQuota) {
          showStatus(
            `Not enough quota. You have ${subscriptionData.remaining} credits but need ${processItems.length}.`,
            "error",
          )
          return
        }
      }
      else {
        // EXPIRED or other status: Can't process
        console.log("Expired or invalid subscription status:", subscriptionData.status)
        
        // Store quota status
        const quotaStatus = {
          canContinue: false,
          isPaid: false,
          status: subscriptionData.status
        }
        
        chrome.storage.local.set({ quotaStatus })
        
        // Inform background script
        chrome.runtime.sendMessage({
          action: "updateQuotaStatus",
          quotaStatus,
        })
        
        showStatus(
          subscriptionData.status === "payment_failed"
            ? "Payment failed. Please update your payment method to continue."
            : "Your subscription has expired. Please upgrade to continue.",
          "error"
        )
        return
      }
    } catch (error) {
      console.error("Error checking subscription:", error)
      showStatus("Could not verify subscription status. Please try again.", "error")
      return
    }

    if (!isOnKlingPage) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          const targetUrl = generationMode === "text"
            ? "https://app.klingai.com/global/text-to-video"
            : "https://app.klingai.com/global/image-to-video"
          chrome.tabs.update(tabs[0].id, { url: targetUrl })
        }
      })
      return
    }

    // Update UI
    setIsProcessing(true)
    setProgressStatus("Processing...")
    setProcessedCount({ processed: 0, total: processItems.length })

    // Send message to content script to start processing
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && (tabs[0].url.includes("app.klingai.com/global/text-to-video") || tabs[0].url.includes("app.klingai.com/global/image-to-video"))) {
        chrome.tabs
          .sendMessage(tabs[0].id, {
            action: "startProcessing",
            prompts: generationMode === "text" ? prompts.map((p) => p.text) : processItems.map((item) => item.text),
            settings: {
              autoDownload: settings.autoDownload,
              delayBetweenPrompts: Number.parseInt(settings.delayBetweenPrompts, 10) * 1000,
              generationMode: generationMode,
              baseImages: generationMode === "image" ? processItems.map((item) => item.image) : [], // Include multiple images
            },
          })
          .catch((err) => {
            console.error("Error starting processing:", err)
            showStatus("Could not start processing. Please refresh the page and try again.", "error")
            resetUI()
          })
        showStatus("Processing started!", "success")
      } else {
        resetUI()
      }
    })
  }

  // Stop processing prompts
  const stopProcessing = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && (tabs[0].url.includes("app.klingai.com/global/text-to-video") || tabs[0].url.includes("app.klingai.com/global/image-to-video"))) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "stopProcessing" }).catch((err) => {
          console.log("Error stopping processing:", err)
        })
        showStatus("Processing stopped!", "info")
        resetUI()
      }
    })
  }

  // Array of promotional messages and tips for processing state
  const promotionalMessages = [
    "⭐ Rate us 5 stars on the Chrome Web Store!",
    "💡 Tip: Use descriptive prompts for better video results",
    "🚀 Need custom solutions? Contact us for development!",
    "💼 Want bulk processing for your business? Let's talk!",
    "🛠️ Need integration with your existing workflow? We can help!",
    "💎 Love KlingGen? Leave us a review and help others discover it!"
  ]

  // Get random promotional message
  const getRandomPromotionalMessage = () => {
    return promotionalMessages[Math.floor(Math.random() * promotionalMessages.length)]
  }

  // State for current promotional message (updates during processing)
  const [currentPromoMessage, setCurrentPromoMessage] = useState(getRandomPromotionalMessage())

  // Rotate promotional message every 5 seconds during processing
  useEffect(() => {
    let interval
    if (isProcessing) {
      interval = setInterval(() => {
        setCurrentPromoMessage(getRandomPromotionalMessage())
      }, 10000) // Change message every 5 seconds
    }
    return () => {
      if (interval) {
        clearInterval(interval)
      }
    }
  }, [isProcessing])

  // Generate dynamic dashboard title based on current state
  const getDashboardTitle = () => {
    if (isProcessing) {
      return `Processing ${processedCount.processed}/${processedCount.total} ${generationMode === "text" ? "prompts" : "images"}...`
    }
    
    if (processedCount.processed > 0 && !isProcessing) {
      return `Completed ${processedCount.processed}/${processedCount.total} ${generationMode === "text" ? "prompts" : "images"}`
    }
    
    if (!isOnKlingPage) {
      return "Connect to Kling AI Platform"
    }
    
    if (generationMode === "text") {
      if (prompts.length === 0) {
        return "Upload prompts to get started"
      }
      return `${prompts.length} video prompt${prompts.length !== 1 ? 's' : ''} ready`
    } else {
      if (baseImages.length === 0) {
        return "Upload images to convert to video"
      }
      return `${baseImages.length} image${baseImages.length !== 1 ? 's' : ''} ready for processing`
    }
  }

  // Get subtitle for dashboard (only during processing)
  const getDashboardSubtitle = () => {
    if (isProcessing) {
      return currentPromoMessage
    }
    return null
  }

  // If showing prompt creator, render it instead
  if (showPromptCreator) {
    return <PromptCreator onBack={() => setShowPromptCreator(false)} />
  }

  return (
    <div className="flex flex-col bg-gradient-to-br from-white to-gray-50 dark:from-gray-800 dark:to-gray-900 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700 transition-all duration-300">
      {/* Header with Kling styling */}
      <div className="bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] p-3 sm:p-4 text-white">
        <div className="flex flex-col space-y-3 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
          <div className="flex items-center space-x-2 min-w-0 flex-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            <div className="flex flex-col min-w-0 flex-1">
              <h2 className="text-base sm:text-lg font-semibold truncate">{getDashboardTitle()}</h2>
              {getDashboardSubtitle() && (
                <p className="text-xs sm:text-sm text-white/80 mt-0.5 truncate animate-fadeIn">
                  {getDashboardSubtitle()}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center justify-between sm:justify-end space-x-2 sm:space-x-3">
            <div
              className={`px-2 py-0.5 rounded-full text-xs font-medium flex items-center flex-shrink-0 ${
                isOnKlingPage
                  ? "bg-green-500/20 text-white"
                  : "bg-red-500/20 text-white"
              }`}
            >
              <div className={`w-2 h-2 rounded-full mr-1.5 ${isOnKlingPage ? "bg-green-400" : "bg-red-400"} ${isOnKlingPage ? "animate-pulse" : ""}`}></div>
              <span className="hidden xs:inline">{isOnKlingPage ? "Connected" : "Not Connected"}</span>
              <span className="xs:hidden">{isOnKlingPage ? "ON" : "OFF"}</span>
            </div>
            {!isOnKlingPage && (
              <button
                onClick={() => {
                  const targetUrl = generationMode === "text"
                    ? "https://app.klingai.com/global/text-to-video"
                    : "https://app.klingai.com/global/image-to-video"
                  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    if (tabs[0]) {
                      chrome.tabs.update(tabs[0].id, { url: targetUrl })
                    }
                  })
                }}
                className="text-sm font-medium text-white hover:text-white flex items-center transition-all duration-200 bg-white/20 hover:bg-white/30 rounded-lg px-4 py-2 shadow-sm hover:shadow-md transform hover:scale-105 active:scale-95 border border-white/20 hover:border-white/30"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 mr-2 flex-shrink-0"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                  />
                </svg>
                <span className="whitespace-nowrap">Open Kling</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Status message */}
        {status.text && (
          <div 
            className={`mb-4 p-3 rounded-lg text-sm border backdrop-blur-sm shadow-sm ${
              status.type === "success" 
                ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800/30 text-green-700 dark:text-green-400' 
                : status.type === "error" 
                  ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800/30 text-red-700 dark:text-red-400' 
                  : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30 text-blue-700 dark:text-blue-400'
            } animate-fadeIn`}
          >
            {status.text}
          </div>
        )}

        {/* Generation Mode Selection */}
        <div className="mb-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-700">
            <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#6EFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              Generation Mode
            </h3>
            
            {/* Mode Toggle Buttons */}
            <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
              <button
                onClick={() => handleGenerationModeChange("text")}
                className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 flex items-center justify-center ${
                  generationMode === "text"
                    ? "bg-[#00A5FF] text-white shadow-sm"
                    : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Text to Video
              </button>
              <button
                onClick={() => handleGenerationModeChange("image")}
                className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 flex items-center justify-center ${
                  generationMode === "image"
                    ? "bg-[#00A5FF] text-white shadow-sm"
                    : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                Image to Video
              </button>
            </div>
          </div>
        </div>

        {/* Multiple Images Upload (for Image to Video mode) */}
        {generationMode === "image" && (
          <div className="mb-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#00C3A5]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  Images to Convert
                  {baseImages.length > 0 && (
                    <span className="ml-2 text-xs text-[#00C3A5] dark:text-[#00C3A5] font-medium px-2 py-0.5 bg-[#00C3A5]/10 dark:bg-[#00C3A5]/20 rounded-full">
                      {baseImages.length} image{baseImages.length !== 1 ? 's' : ''}
                    </span>
                  )}
                </h3>
                
                {/* Clear All Images Button */}
                {baseImages.length > 0 && (
                  <button
                    onClick={() => {
                      setBaseImages([])
                      showStatus("All images removed", "info", 2000)
                    }}
                    className="flex items-center space-x-1 px-2 py-1 text-xs font-medium text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-md border border-red-200 dark:border-red-800/30 transition-colors"
                    title="Remove all images"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                    <span>Clear All</span>
                  </button>
                )}
              </div>
            </div>
            <div className="p-4">
              <div className="relative border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-[#6EFF00] dark:hover:border-[#6EFF00] rounded-lg p-4 text-center transition-colors duration-200 bg-gray-50 dark:bg-gray-800/50">
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                {baseImages.length > 0 ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {baseImages.slice(0, 6).map((img, index) => (
                        <div key={index} className="relative">
                          <img src={img.data} alt={img.name} className="w-full h-20 object-cover rounded-lg shadow-sm" />
                          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs p-1 rounded-b-lg truncate">
                            {img.name}
                          </div>
                        </div>
                      ))}
                      {baseImages.length > 6 && (
                        <div className="w-full h-20 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center text-gray-500 dark:text-gray-400 text-sm">
                          +{baseImages.length - 6} more
                        </div>
                      )}
                    </div>
                    <span className="text-sm text-green-600 dark:text-green-400 font-medium">✓ {baseImages.length} image{baseImages.length !== 1 ? 's' : ''} uploaded</span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400 dark:text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <span className="text-sm text-gray-600 dark:text-gray-400">Upload multiple images for video generation</span>
                    <span className="text-xs text-gray-500 dark:text-gray-500">Select multiple JPG, PNG, GIF files</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Image to Prompt Mapping (for Image to Video mode) */}
        {generationMode === "image" && baseImages.length > 0 && (
          <div className="mb-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700">
            <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-700">
              <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#00D2FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Image Processing Order
                <span className="ml-2 text-xs text-[#00D2FF] dark:text-[#00D2FF] font-medium px-2 py-0.5 bg-[#00D2FF]/10 dark:bg-[#00D2FF]/20 rounded-full">
                  {baseImages.length} image{baseImages.length !== 1 ? 's' : ''}
                </span>
              </h3>
            </div>
            <div className="p-4">
              <div className="space-y-3 max-h-64 overflow-y-auto custom-purple-scrollbar">
                {baseImages.map((img, index) => {
                  const correspondingPrompt = prompts.length > 0 ? prompts[index % prompts.length]?.text || "" : "";
                  const processItem = generationMode === "image" ? {
                    text: correspondingPrompt,
                    image: img,
                    id: index,
                    status: processedCount.processed > index ? "processed" :
                             processedCount.processed === index ? "current" : "pending"
                  } : null;
                  
                  return (
                    <div key={index} className={`flex items-start space-x-3 p-3 rounded-lg border transition-all ${
                      processItem?.status === "processed"
                        ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800/30"
                        : processItem?.status === "current"
                          ? "bg-[#00D2FF]/10 dark:bg-[#00D2FF]/20 border-[#00D2FF]/30 dark:border-[#00D2FF]/40"
                          : "bg-gray-50 dark:bg-gray-900/30 border-gray-200 dark:border-gray-700"
                    }`}>
                      {/* Image thumbnail */}
                      <div className="flex-shrink-0 relative">
                        <img
                          src={img.data}
                          alt={img.name}
                          className="w-16 h-16 object-cover rounded-lg shadow-sm"
                        />
                        {/* Status indicator */}
                        <div className={`absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                          processItem?.status === "processed"
                            ? "bg-green-500 text-white"
                            : processItem?.status === "current"
                              ? "bg-[#00D2FF] text-white animate-pulse"
                              : "bg-gray-400 text-white"
                        }`}>
                          {processItem?.status === "processed"
                            ? "✓"
                            : processItem?.status === "current"
                              ? "●"
                              : index + 1}
                        </div>
                      </div>
                      
                      {/* Image info and prompt */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                            {index + 1}. {img.name}
                          </h4>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            processItem?.status === "processed"
                              ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400"
                              : processItem?.status === "current"
                                ? "bg-[#00D2FF]/20 dark:bg-[#00D2FF]/30 text-[#00D2FF] dark:text-[#00D2FF]"
                                : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400"
                          }`}>
                            {processItem?.status === "processed"
                              ? "Completed"
                              : processItem?.status === "current"
                                ? "Processing..."
                                : "Pending"}
                          </span>
                        </div>
                        
                        {/* Prompt text with edit functionality */}
                        <div className="text-sm text-gray-600 dark:text-gray-400 group">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-gray-800 dark:text-gray-300">Prompt:</span>
                            {!isProcessing && correspondingPrompt && editingImagePromptIndex !== index && (
                              <button
                                onClick={() => startEditingImagePrompt(index, correspondingPrompt)}
                                className="opacity-0 group-hover:opacity-100 w-5 h-5 flex items-center justify-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-all"
                                title="Edit this prompt"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                </svg>
                              </button>
                            )}
                          </div>
                          
                          {editingImagePromptIndex === index ? (
                            /* Edit mode */
                            <div className="space-y-2">
                              <textarea
                                value={editImagePromptText}
                                onChange={(e) => setEditImagePromptText(e.target.value)}
                                className="w-full p-2 bg-white dark:bg-gray-800 rounded border border-gray-300 dark:border-gray-600 text-xs resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                rows="3"
                                placeholder="Enter prompt for this image..."
                                autoFocus
                              />
                              <div className="flex items-center justify-end space-x-2">
                                <button
                                  onClick={cancelImagePromptEdit}
                                  className="px-2 py-1 text-xs font-medium text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded border transition-colors"
                                >
                                  Cancel
                                </button>
                                <button
                                  onClick={() => saveImagePromptEdit(index)}
                                  className="px-2 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors"
                                >
                                  Save
                                </button>
                              </div>
                            </div>
                          ) : (
                            /* Display mode */
                            <div className="mt-1 p-2 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-600 text-xs relative group">
                              {correspondingPrompt ? (
                                <span className="text-gray-700 dark:text-gray-300">{correspondingPrompt}</span>
                              ) : (
                                <div className="flex items-center justify-between">
                                  <span className="text-gray-400 dark:text-gray-500 italic">
                                    No specific prompt - using image alone
                                  </span>
                                  {!isProcessing && (
                                    <button
                                      onClick={() => startEditingImagePrompt(index, "")}
                                      className="opacity-0 group-hover:opacity-100 w-4 h-4 flex items-center justify-center text-blue-500 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-all ml-2"
                                      title="Add prompt"
                                    >
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                      </svg>
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              {/* Processing info */}
              <div className="mt-3 p-3 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-gray-800 dark:to-gray-700 rounded-lg border border-blue-200 dark:border-gray-600 shadow-sm">
                <div className="flex items-start space-x-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#00A5FF] dark:text-[#00D2FF] mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div className="text-xs text-gray-700 dark:text-gray-200">
                    <div className="font-semibold mb-1 text-[#00A5FF] dark:text-[#00D2FF]">Processing Order:</div>
                    <div className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      Images will be processed in the order shown above.
                      {prompts.length > 0 ? (
                        prompts.length < baseImages.length ? (
                          <span className="font-medium text-gray-800 dark:text-gray-100"> Prompts will cycle through your {prompts.length} loaded prompt{prompts.length !== 1 ? 's' : ''} for all {baseImages.length} images.</span>
                        ) : (
                          <span className="font-medium text-gray-800 dark:text-gray-100"> Each image will use its corresponding prompt from your loaded file.</span>
                        )
                      ) : (
                        <span className="font-medium text-gray-800 dark:text-gray-100"> Images will be processed without additional text prompts.</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* File Upload Container - Enhanced */}
        <div className="mb-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700 transition-all hover:shadow-md">
          {/* Header with count */}
          <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gradient-to-r from-gray-50 to-white dark:from-gray-800 dark:to-gray-700">
            <div className="flex items-center">
              <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#C3FF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                {generationMode === "text" ? "Video Prompts" : "Image Enhancement Prompts"}
              </h3>
              {fileName !== "No file selected" && (
                <span className="ml-2 text-xs text-[#C3FF00] dark:text-[#C3FF00] font-medium px-2 py-0.5 bg-[#C3FF00]/10 dark:bg-[#C3FF00]/20 rounded-full">
                  {prompts.length} prompts
                </span>
              )}
            </div>
            
            {/* Clear All Prompts Button */}
            {prompts.length > 0 && (
              <button
                onClick={() => {
                  setPrompts([])
                  setFileName("No file selected")
                  showStatus("All prompts removed", "info", 2000)
                }}
                className="flex items-center space-x-1 px-2 py-1 text-xs font-medium text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-md border border-red-200 dark:border-red-800/30 transition-colors"
                title="Remove all prompts"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                <span>Clear All</span>
              </button>
            )}
          </div>

          {/* Upload Area */}
          <div className="p-4">
            <div className="mb-3 group">
              <div className="relative border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-[#C3FF00] dark:hover:border-[#C3FF00] rounded-lg p-4 text-center transition-colors duration-200 bg-gray-50 dark:bg-gray-800/50">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileImport}
                  accept=".txt"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <div className="flex flex-col items-center justify-center space-y-2 group-hover:scale-105 transition-transform duration-200">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-gray-400 dark:text-gray-500 group-hover:text-[#C3FF00] dark:group-hover:text-[#C3FF00] transition-colors duration-200"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                    />
                  </svg>
                  <span className="text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white transition-colors duration-200">
                    {prompts.length > 0
                      ? `${fileName} • ${prompts.length} ${generationMode === "text" ? "video prompts" : "enhancement prompts"} loaded`
                      : `${generationMode === "text" ? "Select or Drop a .txt file with video prompts" : "Optionally select a .txt file with enhancement prompts"}`}
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-500">
                    {generationMode === "text"
                      ? "One video prompt per line"
                      : "Optional: One enhancement prompt per line (will cycle through images)"}
                  </span>
                </div>
              </div>
            </div>

            {/* Processing Status - With animations */}
            {(isProcessing || processedCount.processed > 0) && (
              <div className="mb-3 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden shadow-sm">
                {/* Progress Bar and Stats */}
                <div className="p-3">
                  <div className="flex items-center justify-between mb-1.5 text-xs">
                    <div className="flex items-center">
                      <span
                        className={`inline-flex w-2 h-2 rounded-full mr-1.5 ${isProcessing ? "bg-purple-500 animate-pulse" : "bg-green-500"}`}
                      ></span>
                      <span className="text-gray-700 dark:text-gray-300 font-medium">
                        {progressStatus}
                      </span>
                    </div>
                    <span className="text-[#00D2FF] dark:text-[#00D2FF] font-medium bg-[#00D2FF]/10 dark:bg-[#00D2FF]/20 px-2 py-0.5 rounded-full">
                      {processedCount.processed}/{processedCount.total} • {Math.round((processedCount.processed / processedCount.total) * 100)}%
                    </span>
                  </div>

                  {/* Progress Bar with shine effect */}
                  <div className="overflow-hidden h-3 rounded-full bg-gray-200 dark:bg-gray-700 relative border border-gray-300/20 dark:border-gray-600/20 shadow-inner">
                    <div
                      className={`bg-gradient-to-r from-[#00A5FF] via-[#00D2FF] to-[#00A5FF] h-full rounded-full transition-all duration-300 ease-out relative ${isProcessing ? "animate-pulse-subtle" : ""}`}
                      style={{
                        width: `${Math.round((processedCount.processed / processedCount.total) * 100)}%`,
                      }}
                    >
                      {isProcessing && (
                        <>
                          <div className="absolute inset-0 overflow-hidden">
                            <div className="h-full w-24 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-15 animate-wave"></div>
                          </div>
                          <div className="absolute top-0 bottom-0 right-0 w-2 bg-white/30 rounded-full animate-pulse-fast"></div>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Current Prompt (if available) */}
                  {currentPrompt !== "-" && (
                    <div className="mt-2 text-xs text-gray-600 dark:text-gray-400 truncate bg-gray-50 dark:bg-gray-900/30 p-2 rounded border border-gray-100 dark:border-gray-700" title={currentPrompt}>
                      <span className="font-medium text-[#6EFF00] dark:text-[#6EFF00]">Current:</span> {currentPrompt}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Prompt List with hover effects */}
            {prompts.length > 0 && (
              <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden max-h-48 shadow-inner bg-gray-50 dark:bg-gray-900/30">
                <div ref={promptListRef} className="overflow-y-auto max-h-48 custom-purple-scrollbar">
                  {prompts.map((prompt, index) => (
                    <div
                      key={prompt.id}
                      className={`px-3 py-1.5 text-xs border-b border-gray-100 dark:border-gray-800 last:border-0 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors ${
                        prompt.status === "processed"
                          ? "text-[#6EFF00] dark:text-[#6EFF00]"
                          : prompt.status === "current"
                            ? "text-[#00D2FF] dark:text-[#00D2FF] font-semibold bg-[#00D2FF]/10 dark:bg-[#00D2FF]/20"
                            : "text-gray-800 dark:text-gray-300"
                      }`}
                    >
                      {editingPromptIndex === index ? (
                        /* Edit mode for text prompts */
                        <div className="space-y-2">
                          <textarea
                            value={editPromptText}
                            onChange={(e) => setEditPromptText(e.target.value)}
                            className="w-full p-2 bg-white dark:bg-gray-800 rounded border border-gray-300 dark:border-gray-600 text-xs resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            rows="2"
                            placeholder="Enter prompt..."
                            autoFocus
                          />
                          <div className="flex items-center justify-end space-x-2">
                            <button
                              onClick={cancelPromptEdit}
                              className="px-2 py-1 text-xs font-medium text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded border transition-colors"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={() => savePromptEdit(index)}
                              className="px-2 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ) : (
                        /* Display mode for text prompts */
                        <div className="flex items-center justify-between group">
                          <div className="flex-1 truncate" title={prompt.text}>
                            <span className="font-medium mr-1.5 text-gray-500 dark:text-gray-500">{index + 1}.</span> {prompt.text}
                          </div>
                          {!isProcessing && (
                            <button
                              onClick={() => startEditingPrompt(index, prompt.text)}
                              className="ml-2 opacity-0 group-hover:opacity-100 w-5 h-5 flex items-center justify-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-all"
                              title="Edit this prompt"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                              </svg>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Settings Section with better separation */}
        <div className="mb-4 p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 transition-all hover:shadow-md">
          <h3 className="text-sm font-medium text-gray-900 dark:text-white flex items-center mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-[#00C3A5]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            Settings
          </h3>

          {/* Kling Connection Status */}
          <div className="mb-3 pb-3 border-b border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-gray-900/30">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 text-[#00A5FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                <span className="text-sm text-gray-700 dark:text-gray-300">Kling Platform</span>
                <div className="relative ml-1 group">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-4 w-4 text-purple-500 animate-pulse cursor-help" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" 
                    />
                  </svg>
                  <div className="absolute left-0 bottom-6 w-60 p-2 bg-white dark:bg-gray-800 rounded shadow-lg border border-gray-200 dark:border-gray-700 text-xs text-gray-600 dark:text-gray-300 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity z-10">
                    <p className="mb-1"><strong>Kling Video Generation:</strong></p>
                    <p className="mb-1">• Connect to Kling platform to generate videos</p>
                    <p className="mb-1">• Automatically downloads generated videos</p>
                    <p className="text-green-500 font-medium">Make sure you're logged into Kling AI platform.</p>
                  </div>
                </div>
              </div>
              <span
                className={`text-sm font-medium px-2 py-0.5 rounded-full ${
                  klingConnected 
                    ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400" 
                    : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-400"
                }`}
              >
                {klingConnected ? "Connected" : "Disconnected"}
              </span>
            </div>
          </div>

          {/* Settings toggles with consistent styling */}
          <div className="space-y-4">
            {/* Auto Download Setting - Modern Toggle */}
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 text-[#00D2FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                <span className="text-sm text-gray-700 dark:text-gray-300">Auto-download videos</span>
              </div>

              <label className="relative inline-flex cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only"
                  checked={settings.autoDownload}
                  onChange={(e) => handleSettingChange("autoDownload", e.target.checked)}
                />

                <div
                  className={`w-10 h-5 rounded-full transition-all duration-300 ease-in-out relative
                            ${
                              settings.autoDownload
                                ? "bg-gradient-to-r from-[#00C3A5] to-[#00D2FF] dark:from-[#00C3A5] dark:to-[#00D2FF]"
                                : "bg-gray-300 dark:bg-gray-600"
                            }`}
                >
                  {/* Toggle Thumb */}
                  <div
                    className={`absolute top-0.5 left-0.5 transform transition-all duration-300 ease-in-out 
                             h-4 w-4 rounded-full bg-white shadow-md 
                             ${settings.autoDownload ? "translate-x-5" : "translate-x-0"}`}
                  ></div>
                </div>
              </label>
            </div>


            {/* Delay Between Prompts Setting - Modern Slider */}
            <div className="pt-2 px-2">
              <div className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 text-[#C3FF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-sm text-gray-700 dark:text-gray-300">Delay between prompts</span>
                  </div>
                  <span className="text-sm font-medium px-2 py-0.5 rounded-full bg-[#C3FF00]/10 dark:bg-[#C3FF00]/20 text-[#C3FF00] dark:text-[#C3FF00]">
                    {settings.delayBetweenPrompts} {settings.delayBetweenPrompts === 1 ? "second" : "seconds"}
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-xs text-gray-500 dark:text-gray-400">1s</span>
                  <div className="relative flex-1 h-7">
                    <input
                      type="range"
                      className="absolute w-full h-1 top-3 bg-gray-300 dark:bg-gray-600 rounded-full appearance-none cursor-pointer"
                      min="1"
                      max="30"
                      value={settings.delayBetweenPrompts}
                      onChange={(e) => handleSettingChange("delayBetweenPrompts", Number.parseInt(e.target.value, 10))}
                      style={{
                        // Custom styling for the range track
                        background: `linear-gradient(to right,
                          rgb(0, 195, 165) 0%,
                          rgb(0, 195, 165) ${(settings.delayBetweenPrompts - 1) * (100 / 29)}%,
                          rgb(209, 213, 219) ${(settings.delayBetweenPrompts - 1) * (100 / 29)}%,
                          rgb(209, 213, 219) 100%)`,
                      }}
                    />
                    <style jsx>{`
                      /* Custom styling for the range thumb */
                      input[type=range]::-webkit-slider-thumb {
                        -webkit-appearance: none;
                        appearance: none;
                        width: 16px;
                        height: 16px;
                        border-radius: 50%;
                        background: white;
                        box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                        cursor: pointer;
                        transition: all 0.15s ease;
                      }
                      input[type=range]::-webkit-slider-thumb:hover {
                        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                        transform: scale(1.1);
                      }
                      input[type=range]::-moz-range-thumb {
                        width: 16px;
                        height: 16px;
                        border-radius: 50%;
                        background: white;
                        box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                        cursor: pointer;
                        border: none;
                        transition: all 0.15s ease;
                      }
                      input[type=range]::-moz-range-thumb:hover {
                        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                        transform: scale(1.1);
                      }
                      
                      /* For dark mode */
                      @media (prefers-color-scheme: dark) {
                        input[type=range] {
                          background: linear-gradient(to right,
                            rgb(0, 210, 255) 0%,
                            rgb(0, 210, 255) ${(settings.delayBetweenPrompts - 1) * (100 / 29)}%,
                            rgb(75, 85, 99) ${(settings.delayBetweenPrompts - 1) * (100 / 29)}%,
                            rgb(75, 85, 99) 100%);
                        }
                      }
                    `}</style>
                  </div>
                  <span className="text-xs text-gray-500 dark:text-gray-400">30s</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Prompt Creator Button */}
        <div className="mb-4">
          <button
            onClick={() => setShowPromptCreator(true)}
            className="w-full py-3 rounded-lg bg-gradient-to-r from-[#6EFF00] to-[#C3FF00] text-black font-medium shadow-sm hover:shadow-md transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            AI Prompt Creator
          </button>
        </div>

        {/* Action Buttons - More attractive */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={startProcessing}
            disabled={
              (generationMode === "text" && prompts.length === 0) ||
              (generationMode === "image" && baseImages.length === 0) ||
              isProcessing ||
              !isOnKlingPage ||
              !user?.uid
            }
            className="py-3 rounded-lg bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] text-white font-medium shadow-sm hover:shadow-md transition-all transform hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 disabled:shadow-none flex items-center justify-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Start Processing
          </button>

          <button
            onClick={stopProcessing}
            disabled={!isProcessing}
            className="py-3 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-all shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-gray-100 disabled:shadow-none flex items-center justify-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
            </svg>
            Stop Processing
          </button>
        </div>
      </div>

      {/* Error Modal */}
      {showErrorModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-red-500 to-red-600 p-4 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <h3 className="text-lg font-semibold">{errorModalData.title}</h3>
                </div>
                <button
                  onClick={closeErrorModal}
                  className="text-white hover:text-red-200 rounded-full p-1 hover:bg-red-600 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6">
              <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed mb-6">
                {errorModalData.message}
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 sm:justify-end">
                {(errorModalData.message.includes("quota") || errorModalData.message.includes("expired") || errorModalData.message.includes("payment")) && setShowSubscriptionModal && (
                  <button
                    onClick={() => {
                      closeErrorModal()
                      setShowSubscriptionModal(true)
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-[#00A5FF] to-[#00D2FF] text-white rounded-lg text-sm font-medium hover:opacity-90 transition-opacity flex items-center justify-center"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    View Plans
                  </button>
                )}
                <button
                  onClick={closeErrorModal}
                  className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Add necessary styles for animations */}
      <style jsx>{`
        @keyframes shine {
          100% {
            transform: translateX(100%);
          }
        }
        
        @keyframes wave {
          0% {
            transform: translateX(-100%) skewX(15deg);
          }
          100% {
            transform: translateX(200%) skewX(15deg);
          }
        }
        
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes pulse-subtle {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.85; }
        }
        
        @keyframes pulse-fast {
          0%, 100% { opacity: 0.7; }
          50% { opacity: 0.3; }
        }
        
        .animate-shine {
          animation: shine 1.5s infinite;
        }
        
        .animate-wave {
          animation: wave 2s ease-in-out infinite;
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-in-out;
        }
        
        .animate-pulse-subtle {
          animation: pulse-subtle 2s ease-in-out infinite;
        }
        
        .animate-pulse-fast {
          animation: pulse-fast 1s ease-in-out infinite;
        }
        
        .skew-x-30 {
          transform: skewX(30deg);
        }
        
        .skew-x-15 {
          transform: skewX(15deg);
        }
        
        /* Custom Cool Purple Scrollbar Styles - Targeted to specific container */
        .custom-purple-scrollbar {
          scrollbar-width: thin;
          scrollbar-color: #00C3A5 #e9d5ff;
        }
        
        .dark .custom-purple-scrollbar {
          scrollbar-color: #00D2FF #374151;
        }
        
        /* Webkit Scrollbar Styles for custom-purple-scrollbar */
        .custom-purple-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        
        .custom-purple-scrollbar::-webkit-scrollbar-track {
          background: linear-gradient(180deg, #e0f7fa 0%, #b2ebf2 100%);
          border-radius: 10px;
          box-shadow: inset 0 0 3px rgba(0, 195, 165, 0.1);
        }
        
        .custom-purple-scrollbar::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #00C3A5 0%, #00A5FF 50%, #00D2FF 100%);
          border-radius: 10px;
          box-shadow:
            inset 0 1px 0px rgba(0, 210, 255, 0.5),
            inset 0 -1px 0px rgba(0, 165, 255, 0.5),
            0 0 4px rgba(0, 195, 165, 0.3);
          transition: all 0.3s ease;
        }
        
        .custom-purple-scrollbar::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #00D2FF 0%, #00C3A5 50%, #00A5FF 100%);
          box-shadow:
            inset 0 1px 0px rgba(0, 210, 255, 0.7),
            inset 0 -1px 0px rgba(0, 165, 255, 0.7),
            0 0 8px rgba(0, 195, 165, 0.5);
          transform: scale(1.05);
        }
        
        .custom-purple-scrollbar::-webkit-scrollbar-thumb:active {
          background: linear-gradient(180deg, #00A5FF 0%, #0080CC 50%, #006699 100%);
          box-shadow:
            inset 0 1px 0px rgba(0, 210, 255, 0.3),
            inset 0 -1px 0px rgba(0, 102, 153, 0.8),
            0 0 12px rgba(0, 165, 255, 0.6);
        }
        
        /* Dark mode scrollbar for custom-purple-scrollbar */
        .dark .custom-purple-scrollbar::-webkit-scrollbar-track {
          background: linear-gradient(180deg, #374151 0%, #4b5563 100%);
          box-shadow: inset 0 0 3px rgba(196, 181, 253, 0.1);
        }
        
        .dark .custom-purple-scrollbar::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #00D2FF 0%, #00C3A5 50%, #00A5FF 100%);
          box-shadow:
            inset 0 1px 0px rgba(0, 210, 255, 0.4),
            inset 0 -1px 0px rgba(0, 165, 255, 0.6),
            0 0 4px rgba(0, 210, 255, 0.4);
        }
        
        .dark .custom-purple-scrollbar::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #6EFF00 0%, #00D2FF 50%, #00C3A5 100%);
          box-shadow:
            inset 0 1px 0px rgba(110, 255, 0, 0.6),
            inset 0 -1px 0px rgba(0, 165, 255, 0.8),
            0 0 8px rgba(0, 210, 255, 0.6);
          transform: scale(1.05);
        }
        
        .dark .custom-purple-scrollbar::-webkit-scrollbar-thumb:active {
          background: linear-gradient(180deg, #00C3A5 0%, #00A5FF 50%, #0080CC 100%);
          box-shadow:
            inset 0 1px 0px rgba(0, 195, 165, 0.4),
            inset 0 -1px 0px rgba(0, 102, 153, 0.9),
            0 0 12px rgba(0, 165, 255, 0.7);
        }
        
        /* Corner styling for custom-purple-scrollbar */
        .custom-purple-scrollbar::-webkit-scrollbar-corner {
          background: #e0f7fa;
        }
        
        .dark .custom-purple-scrollbar::-webkit-scrollbar-corner {
          background: #374151;
        }
      `}</style>
    </div>
  )
}

export default KlingDashboard