// Step 1: Inject Image 

(async () => {
  const base64Data = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA..."; // Replace with your base64 string

  // Convert base64 → Blob → File
  const response = await fetch(base64Data);
  const blob = await response.blob();
  const file = new File([blob], "pasted-image.png", { type: blob.type });

  // Find the nearest input[type="file"] (update selector if needed)
  const fileInput = document.querySelector('input[type="file"]');
  if (!fileInput) {
    console.error("No file input found near the clickable element.");
    return;
  }

  // Use DataTransfer to fake file selection
  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(file);
  fileInput.files = dataTransfer.files;

  // Dispatch change event
  fileInput.dispatchEvent(new Event('change', { bubbles: true }));

  console.log("✅ Image injected as file input selection.");
})();


// Step 2: Add Text Prompt (Optional)

const el = document.querySelector('.tiptap.ProseMirror');
el.focus();

// Replace content with text
el.innerHTML = 'Hello, this is injected text!';
el.dispatchEvent(new Event('input', { bubbles: true }));



// Step 3: Click Genarate Button

[...document.querySelectorAll('button')].find(btn => btn.textContent.trim().includes('Generate'))?.click();


// Step 4: Watch for the Processing or not 

let lastSeen = null;

const observer = new MutationObserver(() => {
  const current = document.querySelector('.progress-box.vertical-center');

  if (current && !lastSeen) {
    console.log('✅ Progress box appeared:', current);
    lastSeen = current;
  } else if (!current && lastSeen) {
    console.log('❌ Progress box disappeared');
    lastSeen = null;
  }
});

// Start observing DOM
observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Optional: immediately check current state on script load
const initial = document.querySelector('.progress-box.vertical-center');
if (initial) {
  console.log('✅ Progress box already present:', initial);
  lastSeen = initial;
}


// Step 5: Click Download button

const downloadButton = [...document.querySelectorAll('button')].find(btn => 
  btn.querySelector('use')?.getAttribute('xlink:href') === '#icon-download'
);

downloadButton?.click();



// Repeat

