"use client"

import React, { useState, useEffect } from "react"
import ReactDOM from "react-dom/client"
import { onAuthStateChanged } from "firebase/auth"
import { auth, storeUserData, EXTENSION_ID } from "./firebase"
import { checkFirestoreSubscription, subscribeToSubscriptionChanges } from "./utils/subscription"
import Login from "./components/Login"
import UserDashboard from "./components/UserDashboard"
import Header from "./components/Header"
import "./index.css"

// Declare chrome as a global variable to avoid undefined errors.
// This is necessary because the chrome API is only available in the extension's context.
// We check if it exists before using it to avoid errors in other environments.
const chrome = typeof window !== "undefined" && typeof window.chrome !== "undefined" ? window.chrome : undefined

const SidePanel = () => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [darkMode, setDarkMode] = useState(false)
  const [subscriptionStatus, setSubscriptionStatus] = useState(null)
  // Add state for modals and tab navigation
  const [showUserProfileModal, setShowUserProfileModal] = useState(false)
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false)
  const [activeTab, setActiveTab] = useState('dashboard')

  useEffect(() => {
    // Check if user prefers dark mode
    const userPrefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches

    // First check extension storage for saved preference
    if (typeof chrome !== "undefined" && chrome.storage) {
      chrome.storage.local.get(["darkMode"], (result) => {
        if (result.darkMode !== undefined) {
          // Use the value from extension storage
          setDarkMode(result.darkMode)
          if (result.darkMode) {
            document.documentElement.classList.add("dark")
            localStorage.setItem("theme", "dark")
          } else {
            document.documentElement.classList.remove("dark")
            localStorage.setItem("theme", "light")
          }
        } else {
          // Fall back to localStorage or system preference
          const savedTheme = localStorage.getItem("theme")
          if (savedTheme === "dark" || (!savedTheme && userPrefersDark)) {
            setDarkMode(true)
            document.documentElement.classList.add("dark")
          } else {
            setDarkMode(false)
            document.documentElement.classList.remove("dark")
          }
        }
      })
    } else {
      // Fallback if chrome.storage isn't available
      const savedTheme = localStorage.getItem("theme")
      if (savedTheme === "dark" || (!savedTheme && userPrefersDark)) {
        setDarkMode(true)
        document.documentElement.classList.add("dark")
      } else {
        setDarkMode(false)
        document.documentElement.classList.remove("dark")
      }
    }

    // Auth state listener
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      try {
        if (currentUser) {
          console.log("Auth state changed: User logged in", currentUser.uid)

          const isGoogleUser = currentUser.providerData?.[0]?.providerId === "google.com"

          // Verified or Google users can proceed
          if (isGoogleUser || currentUser.emailVerified) {
            console.log("User is verified or Google sign-in user")

            // IMPORTANT: Always ensure this extension has subscription data
            // This handles cases where a user is logging in from another extension
            try {
              console.log("Ensuring subscription data exists for this extension")
              await storeUserData(currentUser, EXTENSION_ID)
            } catch (storeError) {
              console.error("Error ensuring extension subscription data:", storeError)
              // Continue with login anyway, since this is just a safety measure
            }

            // Now we can set the user state and continue
            setUser(currentUser)

            // Notify background script about login
            if (typeof chrome !== "undefined" && chrome.runtime) {
              chrome.runtime.sendMessage({
                action: "authStateChanged",
                isLoggedIn: true,
                userId: currentUser.uid,
              })
            }
          } else {
            // Unverified user detected
            console.log("Unverified user detected in auth state change")
            setUser(null)

            // Notify background script about logout
            if (typeof chrome !== "undefined" && chrome.runtime) {
              chrome.runtime.sendMessage({ action: "authStateChanged", isLoggedIn: false })
            }
          }
        } else {
          console.log("Auth state changed: No user logged in")
          setUser(null)

          // Notify background script about logout
          if (typeof chrome !== "undefined" && chrome.runtime) {
            chrome.runtime.sendMessage({ action: "authStateChanged", isLoggedIn: false })
          }
        }
      } catch (error) {
        console.error("Error in auth state handler:", error)
        setUser(null)

        // Notify background script about error/logout
        if (typeof chrome !== "undefined" && chrome.runtime) {
          chrome.runtime.sendMessage({ action: "authStateChanged", isLoggedIn: false })
        }
      } finally {
        setLoading(false)
      }
    })

    return () => unsubscribe()
  }, [])

  // Subscribe to subscription changes
  useEffect(() => {
    let unsubscribe

    const checkSubscription = async () => {
      if (!user?.uid) return
      try {
        // Always specify the current extension ID to get the correct subscription data
        const subscriptionData = await checkFirestoreSubscription(user.uid, EXTENSION_ID)
        setSubscriptionStatus(subscriptionData)
      } catch (error) {
        console.error("Error checking subscription:", error)
      }
    }

    if (user?.uid) {
      // Initial check
      checkSubscription()

      // Set up real-time listener for THIS extension's subscription data
      unsubscribe = subscribeToSubscriptionChanges(user.uid, EXTENSION_ID, (data) => {
        setSubscriptionStatus(data)

        // Notify background script of subscription change
        if (typeof chrome !== "undefined" && chrome.runtime) {
          chrome.runtime.sendMessage({
            action: "authStateChanged",
            isLoggedIn: true,
            subscriptionStatus: data.status,
          })
        }
      })
    }

    return () => {
      if (unsubscribe) unsubscribe()
    }
  }, [user])

  // Function to handle logout
  const handleLogout = () => {
    // First notify the background script that user is logging out
    if (typeof chrome !== "undefined" && chrome.runtime) {
      chrome.runtime.sendMessage(
        {
          action: "authStateChanged",
          isLoggedIn: false,
          subscriptionStatus: null,
        },
        () => {
          // Then sign out from Firebase
          auth.signOut()
        },
      )
    } else {
      // If chrome runtime isn't available, just sign out
      auth.signOut()
    }
  }

  // Toggle dark mode function
  const toggleDarkMode = () => {
    const newDarkMode = !darkMode
    setDarkMode(newDarkMode)

    if (newDarkMode) {
      document.documentElement.classList.add("dark")
      localStorage.setItem("theme", "dark")
    } else {
      document.documentElement.classList.remove("dark")
      localStorage.setItem("theme", "light")
    }

    // Save to extension storage
    if (typeof chrome !== "undefined" && chrome.storage) {
      chrome.storage.local.set({ darkMode: newDarkMode })
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white dark:bg-gray-900">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-[#6EFF00]"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-white w-full transition-colors duration-200 flex flex-col">
      {/* Use the new Header component with all the required props */}
      <Header 
        user={user} 
        onLogout={handleLogout} 
        darkMode={darkMode} 
        toggleDarkMode={toggleDarkMode} 
        subscriptionStatus={subscriptionStatus}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        showUserProfileModal={showUserProfileModal}
        setShowUserProfileModal={setShowUserProfileModal}
        showSubscriptionModal={showSubscriptionModal}
        setShowSubscriptionModal={setShowSubscriptionModal}
      />

      {/* Main content */}
      <main className="flex-1 px-4 py-6 overflow-y-auto">
        {user ? (
          <UserDashboard 
            user={user} 
            darkMode={darkMode} 
            toggleDarkMode={toggleDarkMode}
            subscriptionStatus={subscriptionStatus}
            showUserProfileModal={showUserProfileModal}
            setShowUserProfileModal={setShowUserProfileModal}
            showSubscriptionModal={showSubscriptionModal}
            setShowSubscriptionModal={setShowSubscriptionModal}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onLogout={handleLogout}
          />
        ) : (
          <Login />
        )}
      </main>

      {/* Footer with copyright and support links */}
      <footer className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-t border-gray-200 dark:border-gray-700 py-4 px-4 sm:px-6 mt-auto">
        <div className="max-w-screen-md mx-auto">
          <div className="flex flex-wrap justify-center items-center gap-4 mb-3">
            <a 
              href="https://intercom.help/connectautoplaylabs/en" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm font-medium text-[#00A5FF] hover:text-[#00D2FF] dark:text-[#00D2FF] dark:hover:text-[#00A5FF] flex items-center transition-all duration-200 hover:scale-105"
            >
              <span className="bg-[#00A5FF]/10 p-1.5 rounded-full mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#00A5FF]" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                </svg>
              </span>
              Support
            </a>
            
            <div className="h-4 w-px bg-gray-300 dark:bg-gray-600 mx-1 hidden sm:block"></div>
            
            <a 
              href="https://autoflytuto.web.app/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm font-medium text-[#00A5FF] hover:text-[#00D2FF] dark:text-[#00D2FF] dark:hover:text-[#00A5FF] flex items-center transition-all duration-200 hover:scale-105"
            >
              <span className="bg-[#00A5FF]/10 p-1.5 rounded-full mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#00A5FF]" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                </svg>
              </span>
              Tutorials
            </a>
          </div>
          <div className="text-center text-xs text-gray-500 dark:text-gray-400 font-medium">
            © {new Date().getFullYear()} AutoPlay Labs. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}

// Initialize the React app
const init = () => {
  const root = ReactDOM.createRoot(document.getElementById("app"))
  root.render(
    <React.StrictMode>
      <SidePanel />
    </React.StrictMode>,
  )
}

// Wait for DOM to be ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init)
} else {
  init()
}

export default SidePanel

