// Script to encrypt Firebase configuration before build
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { encrypt } from '../src/utils/encryption.js';

// Get the directory name properly in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from both .env and .env.local
dotenv.config({ path: path.resolve(__dirname, '../.env') });
// Try to load .env.local if it exists (this will override values from .env)
try {
  const localEnvPath = path.resolve(__dirname, '../.env.local');
  if (fs.existsSync(localEnvPath)) {
    const localEnvConfig = dotenv.config({ path: localEnvPath });
    console.log("Loaded .env.local for enhanced configuration");
  }
} catch (error) {
  console.log("No .env.local file found, using only .env values");
}

// Get Firebase config from environment variables
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.VITE_FIREBASE_APP_ID,
};

// Verify that we have all the required config values
const missingValues = Object.entries(firebaseConfig)
  .filter(([key, value]) => !value)
  .map(([key]) => key);

if (missingValues.length > 0) {
  console.error(`Error: Missing Firebase configuration values: ${missingValues.join(', ')}`);
  console.error('Make sure all Firebase configuration values are set in your .env or .env.local file');
  process.exit(1);
}

// Convert to JSON string
const configString = JSON.stringify(firebaseConfig);

// Get the passphrase from environment or use a default secure one
const passphrase = process.env.ENCRYPTION_PASSPHRASE || 
  Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

// Encrypt the configuration
const encryptedConfig = encrypt(configString, passphrase);

// Create or update the .env.production file with the encrypted config and keep other env variables
// First, collect all VITE_ variables except Firebase config
const otherEnvVars = Object.entries(process.env)
  .filter(([key]) => key.startsWith('VITE_') && 
          !key.startsWith('VITE_FIREBASE_') && 
          key !== 'VITE_ENCRYPTED_FIREBASE_CONFIG' &&
          key !== 'VITE_DECRYPT_PASSPHRASE')
  .map(([key, value]) => `${key}=${value}`)
  .join('\n');

// Create the final content with encrypted config and other variables
const envContent = `# This file is auto-generated during the build process - DO NOT EDIT MANUALLY
# Encrypted Firebase configuration
VITE_ENCRYPTED_FIREBASE_CONFIG=${encryptedConfig}
VITE_DECRYPT_PASSPHRASE=${passphrase}

# Other environment variables
${otherEnvVars}
`;

// Write to .env.production
const envFilePath = path.resolve(__dirname, '../.env.production');
fs.writeFileSync(envFilePath, envContent);

console.log('Firebase configuration encrypted and saved to .env.production');
console.log(`Config length: ${configString.length} chars, Encrypted: ${encryptedConfig.length} chars`);