import React from "react";
import { HashRouter, Routes, Route, Link } from "react-router-dom";
import ReactDOM from "react-dom/client";
import { Check, Copy, X } from "lucide-react";
import { useState, useEffect } from "react";

import "./index.css";

import Header from "./components/Header";
import Urlinput from "./components/Urlinput";
import Allcolors from "./components/Allcolors";
import Instructions from "./components/Instructions";
import ColorPalettes from "./components/ColorPalettes";
import { extractColorsFromPage, convertColor } from "./extractColors";
import { saveAllToStorage, loadAllFromStorage } from "./saveStorage";
import ColorPicker from "./components/ColorPicker";
import SavedPalettes from "./components/SavedPalettes";
import ColorScreenshot from "./components/ColorScreenshot";
import ColorExtract from "./components/ColorExtract";

const Sidepanel = () => {
  const [url, setUrl] = useState("");
  const [colorFormat, setColorFormat] = useState("HEX");
  const [allColors, setAllColors] = useState([]);
  const [textColors, setTextColors] = useState([]);
  const [backgroundColors, setBackgroundColors] = useState([]);
  const [mostUsedColors, setMostUsedColors] = useState([]);
  const [palettes, setPalettes] = useState([]);
  const [palettesLoading, setPalettesLoading] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [error, setError] = useState(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [buttonText, setButtonText] = useState("Save Storage");
  const [showButton, setShowButton] = useState(false);

  // On URL change, check if already saved and update button text
  useEffect(() => {
    if (!url) {
      setShowButton(false);
      setButtonText("Save Storage");
      return;
    }

    setShowButton(false);

    // delay before showing button (2s here)
    const timer = setTimeout(() => {
      setShowButton(true);
    }, 2000);

    const savedData = loadAllFromStorage();
    const exists = savedData.some((item) => item.url === url);
    if (exists) {
      setButtonText("Saved");
    } else {
      setButtonText("Save Storage");
    }
    // cleanup on url change
    return () => clearTimeout(timer);
  }, [url]);

  // Toggle color picker visibility
  const toggleColorPicker = () => {
    setShowColorPicker(!showColorPicker);
  };

  // Close color picker
  const closeColorPicker = () => {
    setShowColorPicker(false);
  };

  useEffect(() => {
    console.log("colorFormat changed to:", colorFormat);
  }, [colorFormat]);

  // Auto-close error message after 8 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        setError(null);
      }, 8000); // 8 seconds

      return () => clearTimeout(timer);
    }
  }, [error]);

  const handleCloseError = () => {
    setError(null);
  };

  const handleExtractColors = () => {
    setIsExtracting(true);
    setError(null);
    setPalettesLoading(true);
    setPalettes([]);

    extractColorsFromPage((response) => {
      setIsExtracting(false);

      if (!response) {
        // Check current tab URL to provide specific error messages
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const currentUrl = tabs[0]?.url || "";

          if (
            currentUrl.startsWith("chrome://") ||
            currentUrl.startsWith("chrome-extension://")
          ) {
            setError(
              "ERROR: Cannot extract web color palette from chrome:// pages. Please try a different webpage."
            );
          } else if (
            currentUrl.startsWith("about:") ||
            currentUrl.startsWith("moz-extension://")
          ) {
            setError(
              "ERROR: Cannot extract colors from browser internal pages. Please navigate to a regular website."
            );
          } else if (!currentUrl || currentUrl === "about:blank") {
            setError(
              "ERROR: No webpage detected. Please navigate to a website and try again."
            );
          } else {
            setError(
              "ERROR: Unable to extract colors from this page. The site may have restricted access or contain no extractable colors."
            );
          }
        });
        // stop palettes loading when extraction failed
        setPalettesLoading(false);
        return;
      }

      if (response) {
        console.log("Colors extracted from URL:", response.url);
        console.log("Text Colors:", response.colors);
        console.log("Background Colors:", response.backgroundColors);
        console.log("Most Used Colors:", response.mostUsedAllColors);

        const textConverted = (response.colors || [])
          .map((c) => convertColor(c, colorFormat))
          .filter(Boolean)
          .map((c) => ({ colorcode: c }));

        const backgroundConverted = (response.backgroundColors || [])
          .map((c) => convertColor(c, colorFormat))
          .filter(Boolean)
          .map((c) => ({ colorcode: c }));

        const mostUsedConverted = (response.mostUsedAllColors || [])
          .map((c) => convertColor(c.color, "HEX")) // take only c.color
          .filter(Boolean) // remove null/invalid
          .map((hex) => ({ colors: hex })); // keep same structure as others

        console.log("C colors:", textConverted);
        console.log("C backColors:", backgroundConverted);
        console.log("C most colors:", mostUsedConverted);

        setTextColors(textConverted);
        setBackgroundColors(backgroundConverted);

        // Merge text and background colors, ensuring uniqueness
        const mergedColors = [...textConverted, ...backgroundConverted];
        const uniqueColors = mergedColors.filter(
          (color, index, self) =>
            index === self.findIndex((c) => c.colorcode === color.colorcode)
        );

        setAllColors(uniqueColors);
        setUrl(response.url || "");
        setMostUsedColors(mostUsedConverted || []);

        // Save most used colors to backend
        if (mostUsedConverted && mostUsedConverted.length > 0) {
          handleSaveMostUsed(response.url, mostUsedConverted);
        }
      }
    });
  };

  // Accept palette array and store in state for ColorPalettes to render
  const showColorPalettes = (incomingPalettes) => {
    try {
      if (!Array.isArray(incomingPalettes)) return;

      // Normalize incoming palettes: convert colorCodes -> colors
      const normalized = incomingPalettes
        .map((p) => {
          if (!p) return null;
          const colors = p.colorCodes || p.colors || [];
          // normalize tags to array of strings if present
          const tags = Array.isArray(p.tags)
            ? p.tags
            : p.tags
            ? [String(p.tags)]
            : [];

          return { ...p, colors, tags };
        })
        .filter(Boolean);

      setPalettes(normalized);
    } catch (e) {
      console.error("showColorPalettes error:", e);
      setPalettesLoading(false);
    }
  };

  // Send most used colors to backend server
  const handleSaveMostUsed = async (url, mostUsedColors) => {
    try {
      if (!url || !mostUsedColors || mostUsedColors.length === 0) {
        console.log("No data to save - missing URL or colors");
        return;
      }

      setPalettesLoading(true);
      // Extract only the color codes from objects
      const colorCodes = mostUsedColors.map((c) => c.colors);

      const payload = {
        url: url,
        mostUsedColors: colorCodes, // now only strings
      };

      console.log("Saving most used colors:", payload);

      const res = await fetch("http://localhost:3000/send-most-used", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      const data = await res.json();
      showColorPalettes(data.palettes || []);

      console.log("✅ Most used colors saved successfully:", data);
    } catch (err) {
      console.log("❌ Failed to send most used colors:", err);
      setPalettesLoading(false);
    } finally {
      setPalettesLoading(false);
    }
  };

  // Save current URL and colors to localStorage
  const saveColorStorage = () => {
    if (!url) return; // prevent saving if URL is empty

    const didSave = saveAllToStorage({
      url,
      allColors,
      textColors,
      backgroundColors,
      palettes,
    });

    if (didSave) {
      setButtonText("Saved");
    }
  };

  return (
    <div className="min-h-screen transition-colors dark:bg-gray-900 bg-gray-200">
      {/* Header */}
      <Header
        error={error}
        showColorPicker={toggleColorPicker}
      />

      <ColorExtract
        onExtractColors={handleExtractColors}
        colorFormat={colorFormat}
        setColorFormat={setColorFormat}
        allColors={allColors}
        textColors={textColors}
        backgroundColors={backgroundColors}
        isExtracting={isExtracting}
        error={error}
        onSavedClick={saveColorStorage}
        showButton={showButton}
        buttonText={buttonText}
      />

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-4 space-y-6">
        {/* Error Message */}
        {error && (
          <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-700 rounded-lg p-4 mb-6 relative transform transition-all duration-300 ease-out animate-in slide-in-from-top-2 fade-in">
            <div className="flex items-start gap-3 pr-8">
              <div className="text-sm text-red-800 dark:text-red-200 font-medium leading-relaxed">
                {error}
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={handleCloseError}
              className="absolute top-3 right-3 p-1 rounded-full hover:bg-red-100 dark:hover:bg-red-800/50 transition-colors duration-200 group focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
              aria-label="Close error message"
            >
              <X
                size={16}
                className="text-red-600 dark:text-red-400 group-hover:text-red-800 dark:group-hover:text-red-200 transition-colors duration-200"
              />
            </button>

            {/* Auto-close progress indicator - Pure Tailwind */}
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-red-200 dark:bg-red-800 rounded-b-lg overflow-hidden">
              <div className="h-full bg-red-500 dark:bg-red-400 animate-pulse"></div>
            </div>
          </div>
        )}

        {showColorPicker && <ColorPicker onClose={closeColorPicker} />}
        <Urlinput url={url} />
        <Allcolors
          allColors={allColors}
          textColors={textColors}
          backgroundColors={backgroundColors}
          // colorFormat={colorFormat}
        />
        <ColorPalettes palettes={palettes} palettesLoading={palettesLoading} />
        <Instructions />
      </div>
    </div>
  );
};

// Initialize the React app
const init = () => {
  const root = ReactDOM.createRoot(document.getElementById("app"));
  root.render(
    <React.StrictMode>
      <HashRouter>
        <Routes>
          <Route path="/" element={<Sidepanel />}></Route>
          <Route path="/saved" element={<SavedPalettes />}></Route>
          <Route path="/screen" element={<ColorScreenshot />}></Route>
        </Routes>
      </HashRouter>
    </React.StrictMode>
  );
};

// Wait for DOM to be ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
export default Sidepanel;
