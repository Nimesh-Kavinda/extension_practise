function getBrowserUrl() {
  return window.location.href;
}

function extractColors() {
  const elements = document.querySelectorAll("*");

  const colors = [];
  const backgroundColors = [];

  const colorCount = new Map();
  const bgColorCount = new Map();
  const allColorCount = new Map();

  elements.forEach((el) => {
    const style = window.getComputedStyle(el);

    // text colors
    if (
      style.color &&
      style.color !== "rgba(0, 0, 0, 0)" &&
      style.color !== "transparent"
    ) {
      const c = style.color;
      colors.push(c);
      colorCount.set(c, (colorCount.get(c) || 0) + 1);
      allColorCount.set(c, (allColorCount.get(c) || 0) + 1);
    }

    // background colors
    if (
      style.backgroundColor &&
      style.backgroundColor !== "rgba(0, 0, 0, 0)" &&
      style.backgroundColor !== "transparent"
    ) {
      const bg = style.backgroundColor;
      backgroundColors.push(bg);
      bgColorCount.set(bg, (bgColorCount.get(bg) || 0) + 1);
      allColorCount.set(bg, (allColorCount.get(bg) || 0) + 1);
    }
  });

  return {
    colors: Array.from(new Set(colors)),
    backgroundColors: Array.from(new Set(backgroundColors)),
    colorCount: Object.fromEntries(colorCount),
    bgColorCount: Object.fromEntries(bgColorCount),
    allColorCount: Object.fromEntries(allColorCount),
  };
}

function getMostUsedColors(colorMap, limit = 10) {
  return Object.entries(colorMap)
    .sort((a, b) => b[1] - a[1]) // sort by count desc
    .slice(0, limit) // top N
    .map(([color, count]) => ({ color, count }));
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getColors") {
    const {
      colors,
      backgroundColors,
      colorCount,
      bgColorCount,
      allColorCount,
    } = extractColors();
    const url = getBrowserUrl();

    sendResponse({
      url,
      colors,
      backgroundColors,
      mostUsedColors: getMostUsedColors(colorCount, 5),
      mostUsedBackgrounds: getMostUsedColors(bgColorCount, 5),
      mostUsedAllColors: getMostUsedColors(allColorCount, 10),
    });
  }
});

//image

// 🧩 define the function globally
async function captureFullPage() {
  // reentrancy guard: prevent overlapping captures
  if (window.__cpf_isCapturing) return;
  window.__cpf_isCapturing = true;

  const initialTotalHeight = document.body.scrollHeight;
  const viewportHeight = window.innerHeight;
  const screenshots = [];

  const steps = Math.max(1, Math.ceil(initialTotalHeight / viewportHeight));

  for (let i = 0; i < steps; i++) {
    const y = i * viewportHeight;
    window.scrollTo(0, y);
    await new Promise((r) => setTimeout(r, 700)); // wait for scroll to render

    // request capture and handle transient errors by retrying a few times
    const MAX_RETRIES = 3;
    let attempt = 0;
    let captured = null;
    while (attempt < MAX_RETRIES && !captured) {
      // background now returns { success, dataUrl, error }
      const res = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ todo: "captureViewport" }, resolve);
      });

      if (res && res.success && res.dataUrl) {
        captured = res.dataUrl;
        break;
      }

      attempt++;
      // small backoff before retrying
      await new Promise((r) => setTimeout(r, 500 * attempt));
    }

    if (!captured) {
      // push an empty placeholder to keep stitching indices consistent
      console.warn("captureFullPage: failed to capture viewport at y=", y);
      captured = null;
    }

    screenshots.push(captured);
  }

  // keep the page at the bottom (or last viewport used) after capture
  try {
    const finalY = Math.max(0, (steps - 1) * viewportHeight);
    window.scrollTo(0, finalY);
  } catch (e) {
    // fallback: do nothing
  }

  const fullImage = await stitchImages(screenshots);
  chrome.runtime.sendMessage({ todo: "fullPageDone", imageData: fullImage });
  // clear capture guard after done
  window.__cpf_isCapturing = false;
}

// 🧩 same stitch function
async function stitchImages(images) {
  const imgElements = await Promise.all(
    images.map(
      (src) =>
        new Promise((res) => {
          if (!src) {
            // placeholder blank image for failed captures
            const canvas = document.createElement("canvas");
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            const ctx = canvas.getContext("2d");
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            const img = new Image();
            img.onload = () => res(img);
            img.src = canvas.toDataURL("image/png");
            return;
          }

          const img = new Image();
          img.onload = () => res(img);
          img.src = src;
        })
    )
  );

  const width = imgElements[0].width;
  const height = imgElements.reduce((sum, img) => sum + img.height, 0);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");

  let y = 20;
  for (const img of imgElements) {
    ctx.drawImage(img, 0, y);
    y += img.height;
  }

  return canvas.toDataURL("image/png");
}

// ✅ listen for background message to trigger capture
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "startFullCapture") {
    captureFullPage();
  }
});
