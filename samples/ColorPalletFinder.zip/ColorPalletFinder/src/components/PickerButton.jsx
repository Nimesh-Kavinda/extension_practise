import React from "react";
import { useState } from "react";
import { Brush } from "lucide-react";

const PickerButton = (
    {onToggle}
) => {
  return (
    <button
      title="Color Picker"
      onClick={onToggle}
      className="cursor-pointer border border-gray-300 dark:border-gray-600 rounded-lg dark:text-white text-gray-800 font-normal py-1 px-2 transition-colors flex items-center gap-1 hover:bg-gray-100 dark:hover:bg-gray-700"
    >
      <Brush size={22} />
    </button>
  );
};

export default PickerButton;
