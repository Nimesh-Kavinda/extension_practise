import { useState } from "react";
import { Check } from "lucide-react";

const ColorGrid = ({ colors, type, showMoreState, onShowMore }) => {
  const [copiedColor, setCopiedColor] = useState(null);

  const handleCopyColor = (colorcode) => {
    navigator.clipboard.writeText(colorcode);
    setCopiedColor(colorcode);
    setTimeout(() => setCopiedColor(null), 1500);
  };

const safeColors = Array.isArray(colors) ? colors : [];
const displayColors = showMoreState ? safeColors : safeColors.slice(0, 6);
const remainingCount = safeColors.length - 6;


  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
        {displayColors.map((color, index) => (
          <div key={index} className="text-center">
            <div
              className="w-full h-16 sm:h-20 rounded-lg border border-gray-200 dark:border-gray-600 cursor-pointer hover:scale-105 transition-transform shadow-sm"
              style={{ backgroundColor: color.colorcode }}
              onClick={() => handleCopyColor(color.colorcode)}
            />
            <div className="mt-2 text-xs font-mono text-gray-700 dark:text-gray-300">
              {copiedColor === color.colorcode ? (
                <span className="text-green-600 dark:text-green-400 flex items-center justify-center gap-1">
                  <Check size={12} />
                  Copied!
                </span>
              ) : (
                color.colorcode
              )}
            </div>
          </div>
        ))}
      </div>

      {/* View More/Less Buttons */}
      <div className="flex gap-2">
        {!showMoreState && remainingCount > 0 && (
          <button
            onClick={onShowMore}
            className="flex-1 py-2 text-sm text-gray-600 dark:text-gray-400 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            View More ({remainingCount} more colors)
          </button>
        )}

        {showMoreState && (
          <button
            onClick={() => onShowMore(false)}
            className="flex-1 py-2 text-sm text-gray-600 dark:text-gray-400 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            View Less (showing {colors.length} colors)
          </button>
        )}
      </div>
    </div>
  );
};

export default ColorGrid;
