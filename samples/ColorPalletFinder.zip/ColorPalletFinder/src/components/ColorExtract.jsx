import React from "react";
import ExportButton from "./ExportButton";
import { CheckCircle, Star } from "lucide-react";

const ColorExtract = ({
  onExtractColors,
  colorFormat,
  setColorFormat,
  allColors,
  textColors,
  backgroundColors,
  isExtracting,
  onSavedClick,
  showButton,
  buttonText,
}) => {
  const handleExtractColors = () => {
    onExtractColors();
  };

  const saveColorStorage = () => {
    onSavedClick();
  };
  return (
    <div className="flex items-center justify-between gap-4 bg-white dark:bg-gray-900 shadow-sm max-w-6xl mx-auto px-4 py-4">
      <div className="flex items-center gap-2">
        <button
          onClick={handleExtractColors}
          disabled={isExtracting}
          className="
                relative inline-flex items-center justify-center p-0.5 
                overflow-hidden text-sm font-medium text-gray-900 rounded-md group 
                bg-gradient-to-br from-purple-600 to-blue-500 
                group-hover:from-purple-600 group-hover:to-blue-500 
                hover:text-white dark:text-white 
                focus:ring-2 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800
                disabled:opacity-50 disabled:cursor-not-allowed
              "
        >
          <span
            className="
                relative px-3 py-1.5 transition-all ease-in duration-75 
                bg-white dark:bg-gray-900 rounded 
                group-hover:bg-transparent group-hover:dark:bg-transparent
              "
          >
            {isExtracting ? "Extracting..." : "Extract"}
          </span>
        </button>
      </div>

      <div className="text-sm text-gray-600 dark:text-gray-400">
        <div className="flex items-center gap-2">
          {showButton && (
            <button
              onClick={saveColorStorage}
              className="
                      flex items-center gap-2
                      bg-blue-100 hover:bg-blue-600 
                      dark:bg-blue-500/20 dark:hover:bg-blue-400/50 
                      text-white px-2 py-1.5 rounded-md 
                      text-xs font-medium
                      transition-colors duration-200
                    "
            >
              {buttonText === "Saved" ? (
                <>
                  <CheckCircle
                    size={18}
                    className="text-green-500 dark:text-green-400"
                  />
                </>
              ) : (
                <>
                  <Star size={18} className="text-white dark:text-gray-200" />
                </>
              )}
            </button>
          )}
          <select
            className="
                px-3 py-1.5 
                text-xs font-medium 
                text-gray-900 dark:text-gray-200 
                bg-transparent 
                border border-gray-300 dark:border-gray-600 
                rounded-md 
                focus:outline-none focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-800
                disabled:opacity-50 disabled:cursor-not-allowed
              "
            value={colorFormat}
            onChange={(e) => setColorFormat(e.target.value)}
          >
            <option
              className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-200"
              value="HEX"
            >
              Hex
            </option>
            <option
              className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-200"
              value="RGB"
            >
              RGB
            </option>
            <option
              className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-200"
              value="HSL"
            >
              HSL
            </option>
          </select>
          {/* Right Side - Export Button */}
          <ExportButton
            allColors={allColors}
            textColors={textColors}
            backgroundColors={backgroundColors}
          />
        </div>
      </div>
    </div>
  );
};

export default ColorExtract;
