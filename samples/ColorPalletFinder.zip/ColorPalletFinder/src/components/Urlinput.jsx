import React from 'react'
import { useState } from 'react';

const Urlinput = ({ url }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
        Site URL:
      </label>
      <input
        type="url"
        value={url || ""}
        readOnly
        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 dark:text-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
        placeholder="No valid Url"
      />
    </div>
  );
};

export default Urlinput;
