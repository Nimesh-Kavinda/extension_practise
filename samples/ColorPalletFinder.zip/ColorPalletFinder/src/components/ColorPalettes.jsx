import React from "react";
import { Check, Copy } from "lucide-react";
import { useState } from "react";

const ColorPalettes = ({ palettes, palettesLoading }) => {
  const [copiedColor, setCopiedColor] = useState(null);
  const [showColorPalettes, setShowColorPalettes] = useState(true);

  const [copiedPalette, setCopiedPalette] = useState(null);
  const [expandedPalettes, setExpandedPalettes] = useState(new Set());

  const togglePaletteTags = (key) => {
    setExpandedPalettes((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const handleCopyPalette = (palette, idx) => {
    const colorsArr = palette.colors || palette.colorCodes || [];
    const colorsText = (colorsArr || []).join(", ");
    navigator.clipboard.writeText(colorsText);
    setCopiedPalette(idx);
    setTimeout(() => setCopiedPalette(null), 2000);
  };

  const handleCopyColor = (hex) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(hex);
    setTimeout(() => setCopiedColor(null), 1500);
  };

  const toRender = palettes && palettes.length ? palettes : [];

  return (
    <>
      <div className="flex justify-center">
        <span className="text-base font-semibold text-gray-700 dark:text-gray-300 mr-2">
          Suggest for you
        </span>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">
          Color Palettes
        </h2>
        {toRender.length === 0 ? (
          palettesLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="mr-3 h-5 w-5 border-3 border-t-3 border-gray-300 dark:border-gray-600 border-t-gray-700 dark:border-t-gray-300 rounded-full animate-spin"></div>
              <span className="text-gray-600 dark:text-gray-300">
                Loading palettes...
              </span>
            </div>
          ) : (
            <p className="text-gray-600">No palettes available.</p>
          )
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {toRender.map((palette, index) => (
              <div
                key={index}
                className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-3">
                  {/* Tags (small badges) */}
                  <div className="ml-2 flex flex-wrap items-center gap-1">
                    {(() => {
                      const tags = palette.tags || [];
                      const paletteKey = palette.id || index;
                      const isExpanded = expandedPalettes.has(paletteKey);
                      const visible = isExpanded ? tags : tags.slice(0, 3);

                      return (
                        <>
                          {visible.map((tag, ti) => (
                            <span
                              key={`${paletteKey}-tag-${ti}`}
                              className="text-xs bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-200 px-2 py-0.5 rounded-full"
                            >
                              {tag}
                            </span>
                          ))}

                          {tags.length > 3 && (
                            <button
                              type="button"
                              onClick={() => togglePaletteTags(paletteKey)}
                              aria-expanded={isExpanded}
                              className="text-xs text-gray-500 dark:text-gray-300 px-2 py-0.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-600"
                              title={
                                isExpanded
                                  ? "Show less tags"
                                  : `Show ${tags.length - 3} more tags`
                              }
                            >
                              {isExpanded ? "−" : `+${tags.length - 3}`}
                            </button>
                          )}
                        </>
                      );
                    })()}
                  </div>
                  <button
                    onClick={() => handleCopyPalette(palette, index)}
                    className="p-1.5 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors group"
                    title="Copy all colors"
                  >
                    {copiedPalette === index ? (
                      <Check
                        size={14}
                        className="text-green-600 dark:text-green-400"
                      />
                    ) : (
                      <Copy
                        size={14}
                        className="text-gray-500 dark:text-gray-400 group-hover:text-gray-700 dark:group-hover:text-gray-300 cursor-pointer"
                      />
                    )}
                  </button>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {(palette.colors || palette.colorCodes || []).map(
                    (color, colorIndex) => (
                      <div key={colorIndex} className="text-center">
                        <div
                          className="w-full h-12 rounded-md border border-gray-200 dark:border-gray-600 cursor-pointer hover:scale-105 transition-transform shadow-sm"
                          style={{ backgroundColor: color }}
                          onClick={() => handleCopyColor(color)}
                        />
                        <div className="mt-1 text-xs font-mono text-gray-600 dark:text-gray-400">
                          {copiedColor === color ? (
                            <span className="text-green-600 dark:text-green-400 flex items-center justify-center gap-1">
                              <Check size={14} />
                            </span>
                          ) : (
                            <span className="text-xs">
                              {(color || "").replace(/^#/, "")}
                            </span>
                          )}
                        </div>
                      </div>
                    )
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default ColorPalettes;
