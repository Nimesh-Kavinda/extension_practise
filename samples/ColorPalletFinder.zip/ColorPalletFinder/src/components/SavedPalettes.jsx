import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Palette, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import DarkModeToggle from "./DarkModeToggle";
import { loadAllFromStorage, clearStorage } from "../saveStorage";
import ColorPalettes from "./ColorPalettes";

import Allcolors from "./Allcolors";
import Header from "./Header";
import ColorPicker from "./ColorPicker";

const SavedPalettes = () => {
  const [savedData, setSavedData] = useState([]);
  const [expandedItems, setExpandedItems] = useState({});
  const [palettesLoading, setPalettesLoading] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);

  // Toggle color picker visibility
  const toggleColorPicker = () => {
    setShowColorPicker(!showColorPicker);
  };

  // Close color picker
  const closeColorPicker = () => {
    setShowColorPicker(false);
  };
  

  useEffect(() => {
    // Load all saved data from storage
    const data = loadAllFromStorage();
    setSavedData(data);
  }, []);

  const toggleItem = (index) => {
    setExpandedItems((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const getPreviewColors = (item) => {
    // Show first 4-5 colors as preview
    const allColors = item.allColors || [];
    return allColors.slice(0, 5);
  };

  const deletePalette = (indexToDelete, event) => {
    // Stop event propagation to prevent toggle
    event.stopPropagation();

    if (window.confirm("Are you sure you want to delete this palette?")) {
      const updatedData = savedData.filter(
        (_, index) => index !== indexToDelete
      );
      setSavedData(updatedData);

      // Update localStorage
      localStorage.setItem("colorsDataAll", JSON.stringify(updatedData));

      // Close expanded item if it was open
      setExpandedItems((prev) => {
        const newExpanded = { ...prev };
        delete newExpanded[indexToDelete];
        // Adjust indices for remaining items
        const adjustedExpanded = {};
        Object.keys(newExpanded).forEach((key) => {
          const numKey = parseInt(key);
          if (numKey > indexToDelete) {
            adjustedExpanded[numKey - 1] = newExpanded[key];
          } else {
            adjustedExpanded[key] = newExpanded[key];
          }
        });
        return adjustedExpanded;
      });
    }
  };

  return (
    <>
      <div className="min-h-screen transition-colors dark:bg-gray-900 bg-gray-200">
        {/* Header */}
      <Header
        showColorPicker={toggleColorPicker}
      />

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between gap-4 bg-white dark:bg-gray-900 shadow-sm max-w-6xl mx-auto px-4 py-4">
          
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {savedData.length} saved palette{savedData.length !== 1 ? "s" : ""}
          </div>
          <button
            onClick={() => {
              if (
                window.confirm(
                  "Are you sure you want to clear all saved palettes?"
                )
              ) {
                clearStorage();
                setSavedData([]);
              }
            }}
            className="cursor-pointer dark:text-red-500/80 text-gray-800 font-medium py-1 px-2 rounded-lg transition-colors flex items-center gap-1"
          >
            <Trash2 size={22} />
          </button>
        </div>

        {/* Main Content - Palette List */}
        <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 sm:py-6 space-y-3 sm:space-y-4">
          
          {showColorPicker && <ColorPicker onClose={closeColorPicker} />}

          {savedData.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-8 text-center shadow-sm">
              <p className="text-gray-500 dark:text-gray-400 text-lg">
                No saved palettes found.
              </p>
              <p className="text-gray-400 dark:text-gray-500 text-sm mt-2">
                Extract colors from websites to see them here!
              </p>
              <Link
                to="/"
                className="inline-block mt-4 px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
              >
                Start Extracting Colors
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {savedData.map((item, index) => (
                <div
                  key={index}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden"
                >
                  {/* Palette Header with Preview */}
                  <div className="p-3 sm:p-4 border-b border-gray-200 dark:border-gray-700">
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleItem(index)}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1 min-w-0">
                          <h3 className="text-base sm:text-lg font-semibold text-gray-800 dark:text-gray-200 mb-1">
                            Palette {index + 1}
                          </h3>
                          <p className="text-xs sm:text-sm text-blue-600 dark:text-blue-400 truncate">
                            {new URL(item.url).hostname}
                          </p>
                        </div>

                        <div className="flex items-center gap-1 ml-2">
                          <button
                            onClick={(e) => deletePalette(index, e)}
                            className="p-1.5 sm:p-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900 transition-colors flex-shrink-0 group"
                            title="Delete palette"
                          >
                            <Trash2
                              size={16}
                              className="text-gray-500 dark:text-gray-400 group-hover:text-red-600 dark:group-hover:text-red-400"
                            />
                          </button>
                          <button className="p-1.5 sm:p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex-shrink-0">
                            {expandedItems[index] ? (
                              <ChevronUp
                                size={18}
                                className="text-gray-600 dark:text-gray-400"
                              />
                            ) : (
                              <ChevronDown
                                size={18}
                                className="text-gray-600 dark:text-gray-400"
                              />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Color Preview */}
                      <div className="flex gap-1.5 sm:gap-2 mb-3">
                        {getPreviewColors(item).map((colorObj, colorIndex) => (
                          <div
                            key={colorIndex}
                            className="w-6 h-6 sm:w-8 sm:h-8 rounded border border-gray-300 dark:border-gray-600 flex-shrink-0"
                            style={{ backgroundColor: colorObj.colorcode }}
                            title={colorObj.colorcode}
                          />
                        ))}
                        {item.allColors && item.allColors.length > 5 && (
                          <div className="w-6 h-6 sm:w-8 sm:h-8 rounded border border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs text-gray-600 dark:text-gray-400">
                              +{item.allColors.length - 5}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2 sm:gap-4 text-xs sm:text-sm text-gray-600 dark:text-gray-400">
                        <span>All: {item.allColors?.length || 0}</span>
                        <span>Text: {item.textColors?.length || 0}</span>
                        <span>
                          Background: {item.backgroundColors?.length || 0}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Content */}
                  {expandedItems[index] && (
                    <div className="p-3 sm:p-4 space-y-4 sm:space-y-6">
                      {/* All Colors Section */}
                      <div>
                        <Allcolors
                          allColors={item.allColors || []}
                          textColors={item.textColors}
                          backgroundColors={item.backgroundColors}
                        />

                        <ColorPalettes
                          palettes={item.palettes}
                          
                        />
                      </div>

                      {/* Bottom Collapse Button */}
                      <div className="flex justify-center pt-2 border-t border-gray-200 dark:border-gray-700">
                        <button
                          onClick={() => toggleItem(index)}
                          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        >
                          <ChevronUp
                            size={18}
                            className="text-gray-600 dark:text-gray-400"
                          />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default SavedPalettes;
