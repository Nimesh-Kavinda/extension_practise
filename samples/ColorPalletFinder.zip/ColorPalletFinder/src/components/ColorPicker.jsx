import React, { useRef, useState } from "react";
import { parse, formatHex, formatRgb, formatHsl } from "culori";
import { X } from "lucide-react";

const ColorPicker = ({ onClose }) => {
  const [color, setColor] = useState("#4A90E2");
  const [rgb, setRgb] = useState("rgb(74, 144, 226)");
  const [hsl, setHsl] = useState("hsl(215, 73%, 59%)");
  const [copied, setCopied] = useState("");
  const inputRef = useRef(null);

  const updateColor = (hex) => {
    const c = parse(hex);
    if (!c) return;
    setColor(formatHex(c));
    setRgb(formatRgb(c));
    setHsl(formatHsl(c));
  };

  const handleChange = (e) => {
    updateColor(e.target.value);
  };

  // Eye dropper
  const pickFromScreen = async () => {
    try {
      if (!window.EyeDropper) {
        alert("EyeDropper API not supported in this browser.");
        return;
      }
      const eyeDropper = new EyeDropper();
      const { sRGBHex } = await eyeDropper.open();
      updateColor(sRGBHex);
    } catch (err) {
      console.error("Color picking failed:", err);
    }
  };

  const copyToClipboard = async (text, label) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(""), 1500);
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm relative">
      <div className="flex flex-col gap-6">
        {/* Color Input Section */}
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <input
              ref={inputRef}
              type="color"
              value={color}
              onChange={handleChange}
              className="w-20 h-20 sm:w-24 sm:h-24 border-2 border-gray-300 dark:border-gray-600 rounded-xl cursor-pointer shadow-md hover:shadow-lg transition-all duration-200 hover:scale-105 bg-transparent"
              style={{ padding: "2px" }}
              aria-label="Pick a color"
            />
            <div className="absolute -inset-1 bg-gradient-to-r from-pink-500 to-blue-500 rounded-xl opacity-10 pointer-events-none transition-opacity"></div>
          </div>

          {/* EyeDropper Button */}
          <button
            onClick={pickFromScreen}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-4 py-2.5 rounded-lg shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 font-medium"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"
              />
            </svg>
            Pick From Screen
          </button>
        </div>

        {/* Color Values Display */}
        <div className="grid gap-3">
          <div
            className="group cursor-pointer p-3 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg border border-gray-200 dark:border-gray-600 transition-all duration-200 hover:shadow-md"
            onClick={() => copyToClipboard(color, "HEX")}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                  HEX
                </span>
                <span className="font-mono text-sm sm:text-base text-gray-900 dark:text-gray-100">
                  {color}
                </span>
              </div>
              {copied === "HEX" ? (
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              ) : (
                <svg
                  className="w-5 h-5 text-gray-400 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                  />
                </svg>
              )}
            </div>
          </div>

          <div
            className="group cursor-pointer p-3 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg border border-gray-200 dark:border-gray-600 transition-all duration-200 hover:shadow-md"
            onClick={() => copyToClipboard(rgb, "RGB")}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                  RGB
                </span>
                <span className="font-mono text-sm sm:text-base text-gray-900 dark:text-gray-100">
                  {rgb}
                </span>
              </div>
              {copied === "RGB" ? (
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              ) : (
                <svg
                  className="w-5 h-5 text-gray-400 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                  />
                </svg>
              )}
            </div>
          </div>

          <div
            className="group cursor-pointer p-3 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg border border-gray-200 dark:border-gray-600 transition-all duration-200 hover:shadow-md"
            onClick={() => copyToClipboard(hsl, "HSL")}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                  HSL
                </span>
                <span className="font-mono text-sm sm:text-base text-gray-900 dark:text-gray-100">
                  {hsl}
                </span>
              </div>
              {copied === "HSL" ? (
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              ) : (
                <svg
                  className="w-5 h-5 text-gray-400 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                  />
                </svg>
              )}
            </div>
          </div>
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
          aria-label="Close color picker"
        >
          <X
            size={16}
            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors duration-200"
          />
        </button>

        {/* Quick Copy Hint */}
        <p className="text-xs text-center text-gray-500 dark:text-gray-400">
          Click any color value to copy to clipboard
        </p>
      </div>
    </div>
  );
};

export default ColorPicker;
