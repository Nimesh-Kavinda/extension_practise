import React from "react";
import { useState } from "react";
import { FileDown } from "lucide-react";
import { generatePdf } from "../generatePdf";

const ExportButton = ({ allColors, textColors, backgroundColors }) => {

  const handleExport = () => {
  generatePdf({
    url: window.location.href, // or pass stored URL from state
    allColors: allColors,      // your state variable
    textColors: textColors,    // your state variable
    backgroundColors: backgroundColors, // your state variable
  });
};


  return (
    <button
      onClick={handleExport}
      title="Export Colors as PDF"
      className="cursor-pointer border border-gray-300 dark:border-gray-600 dark:text-red-500/80 text-gray-800 font-medium py-1 px-2 rounded-lg transition-colors flex items-center gap-1"
    >
      <FileDown size={22} />
      <span className="hidden sm:inline">Export to PDF</span>
    </button>
  );
};

export default ExportButton;
