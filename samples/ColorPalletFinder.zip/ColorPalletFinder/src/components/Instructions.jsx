import React from "react";
import { Eye } from "lucide-react";

const Instructions = () => {
  return (
    <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-4">
      <div className="flex items-start gap-2">
        <Eye size={16} className="text-blue-500 dark:text-blue-400 mt-0.5 flex-shrink-0" />
        <div className="text-sm text-blue-800 dark:text-blue-200">
          <p className="font-medium mb-1">How to use:</p>
          <ul className="list-decimal ml-4">
            <li>Reload or open the page</li>
            <li>Click "Extract Colors"</li>
            <li>Click a color to copy</li>
            <li>Export palette to PDF</li>
            <li>Find suggested palettes</li>
          </ul>
          <p className="mt-2 italic text-amber-300">
            Note: Extraction may take a few seconds.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Instructions;
