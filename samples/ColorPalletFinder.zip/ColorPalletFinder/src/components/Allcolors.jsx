import React, { useState } from "react";
import { Check } from "lucide-react";
import ColorGrid from "./ColorGrid";

const Allcolors = ({allColors = [], textColors = [], backgroundColors = [] }) => {

  const [showMore, setShowMore] = useState({
    all: false,
    text: false,
    background: false,
  });

  return (
    <div className="space-y-6">
      {/* All Colors */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">
          Colors
        </h2>
        <ColorGrid
          colors={allColors}
          type="all"
          showMoreState={showMore.all}
          onShowMore={(show = true) =>
            setShowMore((prev) => ({ ...prev, all: show }))
          }
        />
      </div>

      {/* Text Colors */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">
          Text Colors
        </h2>
        <ColorGrid
          colors={textColors}
          type="text"
          showMoreState={showMore.text}
          onShowMore={(show = true) =>
            setShowMore((prev) => ({ ...prev, text: show }))
          }
        />
      </div>

      {/* Background Colors */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">
          Background Colors
        </h2>
        <ColorGrid
          colors={backgroundColors}
          type="background"
          showMoreState={showMore.background}
          onShowMore={(show = true) =>
            setShowMore((prev) => ({ ...prev, background: show }))
          }
        />
      </div>
    </div>
  );
};

export default Allcolors;
