import React from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Palette,
  Save,
  CheckCircle,
  House,
  FileDown,
  Brush,
  Star,
} from "lucide-react";
import DarkModeToggle from "./DarkModeToggle";
import PickerButton from "./PickerButton";


const Header = ({
  showColorPicker,
}) => {
  return (
    <>
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-lg flex items-center justify-center">
                <Palette size={12} className="text-white" />
              </div>
              <h1 className="text-base font-semibold text-gray-800 dark:text-gray-200">
                Color Palette Extractor
              </h1>
            </div>

            {/* Dark Mode Toggle */}
            <DarkModeToggle />
          </div>

          {/* Navigation Buttons - First Row */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-1">
              <Link
                title="Home"
                to="/"
                className="cursor-pointer border border-gray-300 dark:border-gray-600 rounded-lg dark:text-white text-gray-800 font-normal py-1 px-2 transition-colors flex items-center gap-1 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <House size={22} />
              </Link>
            </div>
            <div className="flex items-center gap-1">
              <Link
                title="Saved Palettes"
                to="/saved"
                className="cursor-pointer border border-gray-300 dark:border-gray-600 rounded-lg dark:text-white text-gray-800 font-normal py-1 px-2 transition-colors flex items-center gap-1 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Save size={22} />
              </Link>
              <Link
                title="Image Colors Extractor"
                to="/screen"
                className="cursor-pointer border border-gray-300 dark:border-gray-600 rounded-lg dark:text-white text-gray-800 font-normal py-1 px-2 transition-colors flex items-center gap-1 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Palette size={22} />
              </Link>
              <PickerButton onToggle={showColorPicker}/>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;
