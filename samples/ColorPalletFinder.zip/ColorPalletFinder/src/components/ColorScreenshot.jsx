import React, { useState, useEffect } from "react";
import ColorGrid from "./ColorGrid";
import Header from "./Header";
import ColorPicker from "./ColorPicker";

// Libraries
import ColorThief from "colorthief";
import { FastAverageColor } from "fast-average-color";

const ColorScreenshot = () => {
  const [imageData, setImageData] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [colors, setColors] = useState({
    colorThief: [],
    fastAverageColor: [],
  });

  const [showMore, setShowMore] = useState({
    colorThief: false,
  });

  // Toggle color picker visibility
  const toggleColorPicker = () => {
    setShowColorPicker(!showColorPicker);
  };

  // Close color picker
  const closeColorPicker = () => {
    setShowColorPicker(false);
  };

  const handleFullScreenshot = () => {
    setProcessing(true);
    chrome.runtime.sendMessage({ todo: "captureFullPage" });
  };

  // Listen for screenshot result
  useEffect(() => {
    const listener = (msg) => {
      if (msg.todo === "fullPageDone" || msg.todo === "fullPageCaptured") {
        if (msg.imageData) {
          setImageData(msg.imageData);
          extractAllColors(msg.imageData);
        }
        setProcessing(false);
      }
    };
    chrome.runtime.onMessage.addListener(listener);
    return () => chrome.runtime.onMessage.removeListener(listener);
  }, []);

  // Convert [R, G, B] to HEX string
  const rgbToHex = (rgb) => {
    const [r, g, b] = rgb;
    const toHex = (n) => n.toString(16).padStart(2, "0");
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
  };

  // Function to extract colors from PNG using all three libs
  const extractAllColors = async (dataUrl) => {
    const img = new Image();
    img.src = dataUrl;
    img.crossOrigin = "Anonymous";

    img.onload = async () => {
      try {
        // ---- ColorThief ----
        const thief = new ColorThief();
        const thiefColors = thief
          .getPalette(img, 6)
          .map((rgb) => rgbToHex(rgb));

        // ---- FastAverageColor ----
        const fac = new FastAverageColor();
        const facResult = fac.getColor(img); // Returns an object
        const facColor = facResult.hex; // e.g., "#aabbcc"

        setColors({
          colorThief: thiefColors,
          fastAverageColor: [facColor],
        });
      } catch (err) {
        console.error("Color extraction error:", err);
      }
    };
  };

  return (
    <div className="min-h-screen transition-colors dark:bg-gray-900 bg-gray-200">
      {/* Header */}
      <Header showColorPicker={toggleColorPicker} />

      {/* Buttons */}
      <div className="flex items-center justify-between gap-4 bg-white dark:bg-gray-900 shadow-sm max-w-6xl mx-auto px-4 py-4">
        <button
          onClick={handleFullScreenshot}
          disabled={processing}
          className="
              relative inline-flex items-center justify-center p-0.5 
              overflow-hidden text-sm font-medium text-gray-900 rounded-md group 
              bg-gradient-to-br from-purple-600 to-blue-500 
              group-hover:from-purple-600 group-hover:to-blue-500 
              hover:text-white dark:text-white 
              focus:ring-2 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800
              disabled:opacity-50 disabled:cursor-not-allowed
            "
                >
          <span
            className="
              relative px-3 py-1.5 transition-all ease-in duration-75 
              bg-white dark:bg-gray-900 rounded 
              group-hover:bg-transparent group-hover:dark:bg-transparent
            "
                  >
            {processing ? "Processing..." : "Capture Full Page"}
          </span>
        </button>
      </div>

      {/* Screenshot preview (your original CSS) */}
      <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 sm:py-6 space-y-3 sm:space-y-4">
        {showColorPicker && <ColorPicker onClose={closeColorPicker} />}

        {imageData && (
          <div className="mt-4 h-50 overflow-y-auto rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800">
            <img
              src={imageData}
              alt="Screenshot"
              className="w-full rounded-md block"
            />
          </div>
        )}
      </div>

      {/* Extracted Colors using ColorGrid */}
      <div className="space-y-4 mx-2">
        <div className="max-w-6xl mx-auto py-6 bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
          {Object.entries(colors).map(([lib, cols]) => (
            <div key={lib}>
              <h2 className="text-lg font-semibold capitalize text-gray-800 dark:text-gray-100 mb-2">
                {lib} Colors
              </h2>
              <ColorGrid
                colors={cols.map((c) => ({ colorcode: c }))}
                type={lib}
                showMoreState={showMore[lib]}
                onShowMore={(val) =>
                  setShowMore((prev) => ({ ...prev, [lib]: val ?? true }))
                }
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ColorScreenshot;
