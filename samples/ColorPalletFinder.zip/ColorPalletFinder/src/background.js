chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

//CaptureViewport
// implement a simple queue + rate-limit for captureVisibleTab to avoid quota errors
const captureQueue = [];
let captureInProgress = false;
const MIN_CAPTURE_INTERVAL_MS = 1100; // ~1.1s between captures (safe buffer)
let lastCaptureTime = 0;

function processCaptureQueue() {
  if (captureInProgress) return;
  if (captureQueue.length === 0) return;

  const now = Date.now();
  const wait = Math.max(0, MIN_CAPTURE_INTERVAL_MS - (now - lastCaptureTime));
  const req = captureQueue.shift();
  captureInProgress = true;

  setTimeout(() => {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        try {
          req.sendResponse({
            success: false,
            error: chrome.runtime.lastError.message,
          });
        } catch (e) {
          // ignore
        }
      } else {
        try {
          req.sendResponse({ success: true, dataUrl });
        } catch (e) {
          // ignore
        }
      }

      lastCaptureTime = Date.now();
      captureInProgress = false;
      // process next in queue
      processCaptureQueue();
    });
  }, wait);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.todo === "captureViewport") {
    // enqueue the request and ensure we return true to keep the channel open
    captureQueue.push({ sendResponse });
    processCaptureQueue();
    return true; // keep the message channel open for async sendResponse
  }

  if (msg.todo === "captureFullPage") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab?.id) return;

      // inject the content script (if not already)
      chrome.scripting.executeScript(
        {
          target: { tabId: activeTab.id },
          files: ["contentScript.js"],
        },
        () => {
          // AFTER injection, send a message to trigger the function inside contentScript
          chrome.tabs.sendMessage(activeTab.id, { action: "startFullCapture" });
        }
      );
    });
  }

  // keep other messages unchanged
});

// chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
//   if (msg.todo === "captureFullPage") {
//     // Inject script that scrolls and captures
//     chrome.scripting.executeScript({
//       target: { tabId: sender.tab.id },
//       files: ["contentScript.js"]
//     });
//   }

//   if (msg.todo === "captureVisibleTab") {
//     chrome.tabs.captureVisibleTab(null, { format: "png" }, dataUrl => {
//       sendResponse(dataUrl);
//     });
//     return true; // keep connection open
//   }

//   if (msg.todo === "fullPageDone") {
//     // Send stitched image back to React
//     chrome.runtime.sendMessage({
//       todo: "fullPageCaptured",
//       imageData: msg.imageData
//     });
//   }
// });
