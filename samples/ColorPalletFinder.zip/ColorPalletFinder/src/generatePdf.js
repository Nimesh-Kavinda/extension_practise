import jsPDF from "jspdf";
import Color from "color"; // optional, fallback
import * as culori from "culori";

export const generatePdf = ({ url, allColors = [], textColors = [], backgroundColors = [] }) => {
  const doc = new jsPDF();
  let y = 20;

  // Title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("Extracted Colors", 15, y);
  y += 10;

  // Add Site URL
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);

  const splitUrl = doc.splitTextToSize(url || "No URL", 180); 
  doc.text("WebPage URL: " + splitUrl, 15, y);
  y += splitUrl.length * 5 + 5;

  // Sections to render
  const sections = [
    { title: "All Colors", colors: allColors },
    { title: "Text Colors", colors: textColors },
    { title: "Background Colors", colors: backgroundColors },
  ];

  doc.setFont("helvetica", "normal");
  doc.setFontSize(12);

  sections.forEach((section) => {
    const colors = section.colors || [];
    if (colors.length === 0) return;

    // Section title
    doc.setFont("helvetica", "bold");
    doc.text(section.title, 15, y);
    y += 10;
    doc.setFont("helvetica", "normal");

    colors.forEach((colorObj) => {
      const colorText = colorObj.colorcode; // use the already converted color
      if (!colorText) return;

      let rgb = [0, 0, 0]; // default
      try {
        // try Color library first
        rgb = Color(colorText).rgb().array();
      } catch (e) {
        const parsed = culori.parse(colorText);
        if (parsed) {
          const rgbConverted = culori.converter("rgb")(parsed);
          rgb = [
            Math.round(rgbConverted.r * 255),
            Math.round(rgbConverted.g * 255),
            Math.round(rgbConverted.b * 255),
          ];
        }
      }

      // Draw color swatch
      doc.setFillColor(rgb[0], rgb[1], rgb[2]);
      doc.rect(15, y - 4, 5, 5, "F");

      // Draw color code
      doc.text(colorText, 25, y);

      y += 8;

      // Page break
      if (y > 280) {
        doc.addPage();
        y = 20;
      }
    });

    y += 10;
  });

  // Footer
  const pageCount = doc.internal.getNumberOfPages();
  const timestamp = new Date().toLocaleString();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont("helvetica", "italic");
    doc.text(`Generated on: ${timestamp}`, 15, 290);
  }

  doc.save("colors.pdf");
};
