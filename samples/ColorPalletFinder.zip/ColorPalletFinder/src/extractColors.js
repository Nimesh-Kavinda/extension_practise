import chroma from "chroma-js";
import * as culori from "culori";

export const extractColorsFromPage = (callback) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "getColors" }, (response) => {
      if (chrome.runtime.lastError) {
        console.log(
          "No content script found or site not supported:",
          chrome.runtime.lastError.message
        );
        callback && callback(null); // send null if error
      } else if (
        response &&
        response.colors &&
        response.url &&
        response.backgroundColors &&
        response.mostUsedAllColors
      ) {
        callback && callback(response); // pass response to caller
      } else {
        console.log("Unexpected response format:", response);
        callback && callback(response);
      }
    });
  });
};

export const convertToRGB = (color) => {
  try {
    let formattedColor = color.trim();

    // Fix for CSS color spaces with slash alpha
    // e.g., `oklab(0.5 0.3 0.2 / 0.5)` → `oklab(0.5 0.3 0.2 0.5)`
    if (formattedColor.includes("/") && formattedColor.includes("(")) {
      formattedColor = formattedColor.replace(/\s*\/\s*/, " ");
    }

    const parsed = culori.parse(formattedColor);

    if (!parsed) {
      // console.warn("Unable to parse color:", color);
      return null; // skip invalid colors
    }

    const rgb = culori.converter("rgb")(parsed);

    const r = Math.round(rgb.r * 255);
    const g = Math.round(rgb.g * 255);
    const b = Math.round(rgb.b * 255);

    if (rgb.alpha !== undefined && rgb.alpha < 1) {
      return `rgba(${r}, ${g}, ${b}, ${rgb.alpha.toFixed(2)})`;
    }

    return `rgb(${r}, ${g}, ${b})`;
  } catch (err) {
    console.warn("Color conversion failed for:", color, err);
    return null;
  }
};

export const convertColor = (color, format = "HEX") => {
  try {
    let formattedColor = color.trim();

    // Normalize slash alpha for modern CSS colors
    if (formattedColor.includes("/") && formattedColor.includes("(")) {
      formattedColor = formattedColor.replace(/\s*\/\s*/, " ");
    }

    const parsed = culori.parse(formattedColor);
    if (!parsed) {
      // console.warn("Unable to parse color:", color);
      return null;
    }

    switch (format.toUpperCase()) {
      case "HEX":
        return culori.formatHex(parsed); // #RRGGBB
      case "RGB": {
        const rgb = culori.converter("rgb")(parsed);
        const r = Math.round(rgb.r * 255);
        const g = Math.round(rgb.g * 255);
        const b = Math.round(rgb.b * 255);
        if (rgb.alpha !== undefined && rgb.alpha < 1) {
          return `rgba(${r}, ${g}, ${b}, ${rgb.alpha.toFixed(2)})`;
        }
        return `rgb(${r}, ${g}, ${b})`;
      }
      case "HSL": {
        const hsl = culori.converter("hsl")(parsed);

        // Fix NaN by defaulting h to 0
        const h = hsl.h != null ? Math.round(hsl.h) : 0;
        const s = Math.round((hsl.s || 0) * 100);
        const l = Math.round((hsl.l || 0) * 100);

        if (hsl.alpha !== undefined && hsl.alpha < 1) {
          return `hsla(${h}, ${s}%, ${l}%, ${hsl.alpha.toFixed(2)})`;
        }
        return `hsl(${h}, ${s}%, ${l}%)`;
      }
      default:
        console.warn("Unsupported format:", format);
        return null;
    }
  } catch (err) {
    console.warn("Color conversion failed for:", color, err);
    return null;
  }
};
