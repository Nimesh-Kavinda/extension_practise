// storage.js
export const saveAllToStorage = (data) => {
  try {
    const allSaved = JSON.parse(localStorage.getItem("colorsDataAll")) || [];

    const exists = allSaved.some((item) => item.url === data.url);

    if (!exists) {
      allSaved.push(data);
      localStorage.setItem("colorsDataAll", JSON.stringify(allSaved));
    }

    return !exists; // true if new save, false if already exists
  } catch (error) {
    console.error("Error saving to localStorage", error);
    return false;
  }
};

export const loadAllFromStorage = () => {
  try {
    const saved = JSON.parse(localStorage.getItem("colorsDataAll")) || [];
    return saved;
  } catch (error) {
    console.error("Error loading from localStorage", error);
    return [];
  }
};

export const clearStorage = () => {
  localStorage.removeItem("colorsDataAll");
};