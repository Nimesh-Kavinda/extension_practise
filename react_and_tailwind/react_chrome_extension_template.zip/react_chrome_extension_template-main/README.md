# Getting Started with React Chrome Extension

you can customize it as much as you like but make sure the size of the extension isn't to large. Currently i'ts set to 15remx15rem in the App.css

## Add this as a chrome extension
1) run: npm run build ( which creates a new folder called "dist" ).
2) open your browser and paste this url: "chrome://extensions/".
3) enable developer mode if not already enabled.
4) press on load unpacked.
5) find the path to the dist folder from this project and use it as the chrome extension.
6) press on the extension icon on the top right & pin the extension.
7) press on the extension and you should see it.
